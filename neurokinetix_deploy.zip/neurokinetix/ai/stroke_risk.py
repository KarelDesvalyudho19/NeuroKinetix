"""Skrining risiko stroke berulang (pascastrok) berbasis aturan yang transparan.

Skor 0-100 = jumlah poin faktor risiko. Ambang tiap faktor mengacu pada pedoman umum (AHA/ASA pencegahan stroke sekunder,
PERKENI untuk diabetes, kriteria IMT Asia-Pasifik), tetapi BOBOT POIN adalah heuristik tim, BUKAN model prediksi tervalidasi.
Wajib dikalibrasi/divalidasi terhadap data klinis sebelum dipakai klinis. Lihat docs/RISIKO_STROKE.md.
"""
from datetime import datetime
from statistics import pstdev

MAX = dict(bp=25, glucose=18, lipid=14, af=12, smoking=8, bmi=5, age=5, family=2, activity=3, alcohol=2, adherence=4, prior=2)  # total 100
DISCLAIMER = "Skrining ini alat bantu edukasi, bukan diagnosis. Skor dihitung dengan aturan heuristik dan belum divalidasi klinis. Keputusan terapi tetap pada dokter."
ADV = {
    "bp": "Tekanan darah: usahakan <130/80 mmHg. Ukur pagi dan malam dalam posisi duduk, kurangi garam (<5 g atau ±1 sendok teh per hari), dan minum obat sesuai resep.",
    "glucose": "Gula darah: batasi gula dan karbohidrat sederhana, jaga aktivitas, dan diskusikan target HbA1c (umumnya <7%) beserta obatnya dengan dokter.",
    "lipid": "Kolesterol: pada stroke iskemik target LDL umumnya <70 mg/dL. Tanyakan ke dokter tentang terapi penurun kolesterol, kurangi gorengan dan lemak jenuh.",
    "af": "Fibrilasi atrium: pastikan kontrol rutin dan tanyakan ke dokter apakah antikoagulan diperlukan. Jangan mengubah atau menghentikan obat sendiri.",
    "smoking": "Berhenti merokok total, termasuk menghindari asap rokok orang lain. Tanyakan layanan berhenti merokok di puskesmas atau dokter.",
    "bmi": "Berat badan: turunkan perlahan menuju IMT <23 (kriteria Asia-Pasifik) lewat pola makan dan aktivitas yang diizinkan fisioterapis.",
    "activity": "Aktivitas fisik: tingkatkan bertahap sesuai izin fisioterapis. Latihan rehabilitasi di aplikasi ini ikut membantu.",
    "alcohol": "Batasi atau hentikan konsumsi alkohol.",
    "adherence": "Minum obat (antihipertensi, antiplatelet, dll.) teratur sesuai resep. Pasang alarm atau minta keluarga mengingatkan.",
}

def fmt(x, d=0):
    return "–" if x is None else f"{x:.{d}f}".replace(".", ",")

def level_of(score):
    return "sangat tinggi" if score >= 75 else "tinggi" if score >= 50 else "sedang" if score >= 25 else "rendah"

def _factor(key, name, value, pts, note="", nodata=False, fixed=False):
    st = "info" if nodata else "ok" if pts == 0 else "info" if fixed else "warn" if pts / MAX[key] < .5 else "bad"
    return dict(key=key, name=name, value=value, pts=pts, max=MAX[key], status=st, note=note)

def _last(R, key):
    for r in reversed(R):
        if r.get(key) is not None: return r[key]
    return None

def _series(R, key): return [(r["date"], r[key]) for r in R if r.get(key) is not None]

def _slope_month(pairs):
    """Kemiringan regresi linear per 30 hari; None bila data <3 titik atau rentang <20 hari."""
    pts = [(datetime.strptime(d, "%Y-%m-%d").toordinal(), v) for d, v in pairs]; n = len(pts)
    if n < 3 or pts[-1][0] - pts[0][0] < 20: return None
    mx, my = sum(x for x, _ in pts) / n, sum(y for _, y in pts) / n
    den = sum((x - mx) ** 2 for x, _ in pts)
    return sum((x - mx) * (y - my) for x, y in pts) / den * 30 if den else None

def _bp_points(s, d):
    if s >= 160 or d >= 100: return 25, "Hipertensi berat (≥160/100)"
    if s >= 140 or d >= 90: return 19, "Hipertensi (≥140/90)"
    if s >= 130 or d >= 80: return 12, "Di atas target pencegahan stroke (<130/80)"
    if s >= 120: return 4, "Sedikit di atas normal"
    return 0, "Terkendali (<120/80)"

def _glucose_points(a1c, gdp, gds):
    c = []
    if a1c is not None: c.append(0 if a1c < 5.7 else 5 if a1c < 6.5 else 9 if a1c < 7 else 12 if a1c < 8 else 15 if a1c < 9 else 18)
    if gdp is not None: c.append(0 if gdp < 100 else 5 if gdp < 126 else 9 if gdp < 140 else 12 if gdp < 180 else 15 if gdp < 250 else 18)
    if gds is not None: c.append(0 if gds < 140 else 5 if gds < 200 else 12 if gds < 300 else 18)
    return max(c) if c else None

def empty(msg="Belum ada data kesehatan. Isi profil dan minimal satu pengukuran."):
    return dict(score=None, level="belum ada data", potensi="belum", headline=msg, red_flags=[], factors=[], insights=[], recs=[],
                completeness=0, missing=["Tekanan darah", "Gula darah", "Kolesterol", "Berat & tinggi badan", "Profil faktor risiko"],
                n=0, as_of=None, bp=None, disclaimer=DISCLAIMER)

def assess(profile, records, age=None, today=None):
    p = profile or {}
    R = sorted(records or [], key=lambda r: (r["date"], r.get("id") or 0))
    if not p and not R: return empty()
    today = today or datetime.now().date()
    iskemik = p.get("stroke_type", "iskemik") != "hemoragik"; female = p.get("sex") == "P"
    F, ins, flags = [], [], []

    # --- tekanan darah: rata-rata 3 pengukuran terakhir ---
    B = [r for r in R if r.get("sbp") is not None and r.get("dbp") is not None]; bpinfo = None
    if B:
        rec = B[-3:]; s = sum(r["sbp"] for r in rec) / len(rec); d = sum(r["dbp"] for r in rec) / len(rec); pts, lab = _bp_points(s, d)
        F.append(_factor("bp", "Tekanan darah", f"{fmt(s)}/{fmt(d)} mmHg (rata-rata {len(rec)} terakhir)", pts, lab))
        last6 = B[-6:]; okn = sum(1 for r in last6 if r["sbp"] < 130 and r["dbp"] < 80); pct = round(100 * okn / len(last6))
        bpinfo = dict(avg_sbp=round(s), avg_dbp=round(d), control_pct=pct, n=len(last6))
        ins.append(dict(k="ok" if pct >= 70 else "warn" if pct >= 40 else "bad", t="Pencapaian target tekanan darah",
                        d=f"{okn} dari {len(last6)} pengukuran terakhir berada di bawah 130/80 mmHg ({pct}%)."))
        sl = _slope_month(_series(B, "sbp"))
        if sl is not None:
            if sl <= -2: ins.append(dict(k="ok", t="Tekanan darah membaik", d=f"Sistolik turun ±{fmt(abs(sl), 1)} mmHg per bulan."))
            elif sl >= 2: ins.append(dict(k="bad", t="Tekanan darah cenderung naik", d=f"Sistolik naik ±{fmt(sl, 1)} mmHg per bulan. Hubungi dokter untuk evaluasi obat."))
            else: ins.append(dict(k="info", t="Tekanan darah stabil", d="Tidak ada perubahan berarti dalam beberapa bulan terakhir."))
        if len(last6) >= 4 and pstdev([r["sbp"] for r in last6]) >= 15:
            ins.append(dict(k="warn", t="Tekanan darah naik-turun", d="Selisih antar-pengukuran besar. Variabilitas tekanan darah dikaitkan dengan risiko stroke lebih tinggi; ukur dengan cara dan jam yang sama."))
        la = B[-1]
        if la["sbp"] >= 180 or la["dbp"] >= 120:
            flags.append(f"Tekanan darah {fmt(la['sbp'])}/{fmt(la['dbp'])} mmHg ({la['date']}) sangat tinggi. Istirahat, ukur ulang; bila tetap tinggi atau ada gejala stroke, segera ke IGD.")
    else:
        F.append(_factor("bp", "Tekanan darah", "Belum ada data", 0, nodata=True))
        if p.get("dx_hypertension"): ins.append(dict(k="warn", t="Hipertensi tanpa data tekanan darah", d="Pasien terdiagnosis hipertensi, tetapi belum ada pengukuran yang dicatat."))
    pr = [r for r in R if r.get("irregular")][-3:]
    if pr and not p.get("af"): ins.append(dict(k="warn", t="Denyut nadi tidak teratur", d="Dicatat nadi tidak teratur. Periksakan EKG ke dokter untuk menyingkirkan fibrilasi atrium."))

    # --- gula darah: nilai terbaru tiap jenis ---
    a1c, gdp, gds = _last(R, "hba1c"), _last(R, "glucose_fasting"), _last(R, "glucose_random"); gp = _glucose_points(a1c, gdp, gds)
    if gp is not None:
        parts = [x for x in (f"HbA1c {fmt(a1c, 1)}%" if a1c is not None else "", f"GDP {fmt(gdp)} mg/dL" if gdp is not None else "", f"GDS {fmt(gds)} mg/dL" if gds is not None else "") if x]
        lab = "Normal" if gp == 0 else "Di atas normal / prediabetes" if gp <= 5 else "Rentang diabetes"
        if a1c is not None and a1c >= 7 and (p.get("dx_diabetes") or gp >= 9): lab += ", di atas target HbA1c <7%"
        F.append(_factor("glucose", "Gula darah", " · ".join(parts), gp, lab))
        sl = _slope_month(_series(R, "glucose_fasting"))
        if sl is not None:
            if sl <= -3: ins.append(dict(k="ok", t="Gula darah puasa membaik", d=f"Turun ±{fmt(abs(sl), 1)} mg/dL per bulan."))
            elif sl >= 3: ins.append(dict(k="bad", t="Gula darah puasa cenderung naik", d=f"Naik ±{fmt(sl, 1)} mg/dL per bulan. Konsultasikan pola makan dan obat."))
        ha = _series(R, "hba1c")
        if len(ha) >= 2:
            dl = ha[-1][1] - ha[0][1]
            ins.append(dict(k="ok" if dl <= -0.3 else "bad" if dl >= 0.3 else "info", t="Tren HbA1c", d=f"Dari {fmt(ha[0][1], 1)}% ke {fmt(ha[-1][1], 1)}% (selisih {fmt(dl, 1)} poin)."))
        lo = [v for v in (gdp, gds) if v is not None and v < 70]
        if lo: flags.append("Gula darah <70 mg/dL (hipoglikemia). Beri gula/minuman manis bila sadar, lalu hubungi dokter.")
        if (gdp is not None and gdp > 300) or (gds is not None and gds > 300): flags.append("Gula darah >300 mg/dL. Segera hubungi dokter atau ke fasilitas kesehatan.")
    else:
        F.append(_factor("glucose", "Gula darah", "Belum ada data", 0, nodata=True))
        if p.get("dx_diabetes"): ins.append(dict(k="warn", t="Diabetes tanpa data gula darah", d="Pasien terdiagnosis diabetes, tetapi belum ada pengukuran gula darah yang dicatat."))

    # --- lipid ---
    ldl, chol, hdl, tg = (_last(R, k) for k in ("ldl", "chol_total", "hdl", "tg"))
    if any(v is not None for v in (ldl, chol, hdl, tg)):
        lp = 0; lab = []
        if ldl is not None:
            cu = (70, 100, 130, 160) if iskemik else (100, 130, 160, 190)
            lp += 0 if ldl < cu[0] else 4 if ldl < cu[1] else 7 if ldl < cu[2] else 9 if ldl < cu[3] else 10
            lab.append(f"LDL {'di atas' if ldl >= cu[0] else 'mencapai'} target <{cu[0]}")
        elif chol is not None:
            lp += 0 if chol < 200 else 5 if chol < 240 else 9; lab.append("Kolesterol total " + ("normal" if chol < 200 else "tinggi"))
        if hdl is not None and hdl < (50 if female else 40): lp += 2; lab.append("HDL rendah")
        if tg is not None and tg >= 150: lp += 2; lab.append("trigliserida tinggi")
        parts = [x for x in (f"LDL {fmt(ldl)}" if ldl is not None else "", f"HDL {fmt(hdl)}" if hdl is not None else "", f"TG {fmt(tg)}" if tg is not None else "", f"Total {fmt(chol)}" if chol is not None else "") if x]
        F.append(_factor("lipid", "Kolesterol", " · ".join(parts) + " mg/dL", min(lp, MAX["lipid"]), ", ".join(lab)))
        sl = _slope_month(_series(R, "ldl"))
        if sl is not None:
            if sl <= -3: ins.append(dict(k="ok", t="LDL membaik", d=f"Turun ±{fmt(abs(sl), 1)} mg/dL per bulan."))
            elif sl >= 3: ins.append(dict(k="warn", t="LDL cenderung naik", d=f"Naik ±{fmt(sl, 1)} mg/dL per bulan. Tinjau pola makan dan kepatuhan obat."))
    else: F.append(_factor("lipid", "Kolesterol", "Belum ada data", 0, nodata=True))

    # --- fibrilasi atrium ---
    if p.get("af"):
        F.append(_factor("af", "Fibrilasi atrium", "Ya, dengan antikoagulan" if p.get("anticoag") else "Ya, tanpa antikoagulan", 6 if p.get("anticoag") else 12, "Faktor risiko stroke kardioembolik"))
        if not p.get("anticoag"): ins.append(dict(k="bad", t="Fibrilasi atrium tanpa antikoagulan", d="Tanyakan ke dokter apakah antikoagulan diperlukan. Jangan memulai atau menghentikan obat sendiri."))
    else: F.append(_factor("af", "Fibrilasi atrium", "Tidak tercatat", 0))

    sm = p.get("smoking", "tidak"); F.append(_factor("smoking", "Merokok", {"tidak": "Tidak pernah", "mantan": "Mantan perokok", "aktif": "Masih merokok"}.get(sm, "Tidak pernah"), {"aktif": 8, "mantan": 2}.get(sm, 0)))

    wt, ht = _last(R, "weight"), p.get("height")
    if wt and ht:
        b = wt / (ht / 100) ** 2; bp_ = 0 if b < 23 else 1 if b < 25 else 3 if b < 30 else 5
        F.append(_factor("bmi", "Indeks massa tubuh", f"{fmt(b, 1)} kg/m²", bp_, "Normal" if b < 23 else "Lebih" if b < 25 else "Gemuk" if b < 30 else "Obesitas", fixed=False))
    else: F.append(_factor("bmi", "Indeks massa tubuh", "Belum ada data", 0, nodata=True))

    if age: F.append(_factor("age", "Usia", f"{age} tahun", 0 if age < 55 else 2 if age < 65 else 4 if age < 75 else 5, fixed=True))
    else: F.append(_factor("age", "Usia", "Belum diisi", 0, nodata=True))
    F.append(_factor("family", "Riwayat keluarga stroke", "Ada" if p.get("family") else "Tidak ada", 2 if p.get("family") else 0, fixed=True))
    ac = p.get("activity", "sedang"); F.append(_factor("activity", "Aktivitas fisik", {"aktif": "Aktif", "sedang": "Sedang", "jarang": "Jarang bergerak"}.get(ac, "Sedang"), {"jarang": 3, "sedang": 1}.get(ac, 0)))
    al = p.get("alcohol", "tidak"); F.append(_factor("alcohol", "Alkohol", {"tidak": "Tidak", "ringan": "Ringan", "berat": "Berat / sering"}.get(al, "Tidak"), 2 if al == "berat" else 0))
    ad = p.get("med_adherence", "rutin"); F.append(_factor("adherence", "Kepatuhan minum obat", {"rutin": "Rutin", "kadang": "Kadang lupa", "jarang": "Jarang"}.get(ad, "Rutin"), {"jarang": 4, "kadang": 2}.get(ad, 0)))
    pe = int(p.get("prior_events") or 0); F.append(_factor("prior", "Stroke/TIA sebelumnya", "Tidak ada" if pe == 0 else f"{pe} kali" if pe == 1 else "2 kali atau lebih", 2 if pe else 0, fixed=True))

    score = min(100, sum(f["pts"] for f in F)); level = level_of(score)
    if flags and level in ("rendah", "sedang"): level = "tinggi"; ins.insert(0, dict(k="bad", t="Level dinaikkan karena tanda bahaya", d="Nilai pengukuran terbaru masuk rentang berbahaya (lihat peringatan di atas)."))

    miss = [n for n, ok in (("Tekanan darah", bool(B)), ("Gula darah", gp is not None), ("Kolesterol", any(v is not None for v in (ldl, chol))), ("Berat & tinggi badan", bool(wt and ht)), ("Profil faktor risiko", bool(p))) if not ok]
    comp = round(100 * (5 - len(miss)) / 5)
    if miss: ins.append(dict(k="info", t="Data belum lengkap", d=f"Belum ada: {', '.join(miss)}. Skor dapat lebih rendah dari kondisi sebenarnya."))
    if R:
        gap = (today - datetime.strptime(R[-1]["date"], "%Y-%m-%d").date()).days
        if gap > 45: ins.append(dict(k="warn", t="Data pengukuran sudah lama", d=f"Pengukuran terakhir {gap} hari lalu. Perbarui agar analisis mencerminkan kondisi sekarang."))

    head = {"rendah": "Potensi stroke berulang tampak rendah. Tetap kontrol rutin, karena penyintas stroke selalu memiliki risiko dasar.",
            "sedang": "Potensi stroke berulang sedang. Ada faktor risiko yang perlu dikendalikan.",
            "tinggi": "Berpotensi TINGGI mengalami stroke berulang. Segera konsultasikan faktor risiko di bawah ke dokter.",
            "sangat tinggi": "Berpotensi SANGAT TINGGI mengalami stroke berulang. Perlu evaluasi dokter secepatnya."}[level]
    recs = [ADV[f["key"]] for f in sorted(F, key=lambda f: -f["pts"]) if f["pts"] > 0 and ADV.get(f["key"])][:5] or ["Pertahankan kebiasaan sehat dan kontrol rutin sesuai jadwal dokter."]
    recs.append("Kenali tanda stroke (SeGeRa): Senyum tidak simetris, Gerak separuh tubuh melemah, bicaRa pelo, Kebas separuh tubuh, Rabun mendadak, Sakit kepala hebat mendadak. Bila muncul, segera ke IGD.")
    return dict(score=score, level=level, potensi="ya" if level in ("tinggi", "sangat tinggi") else "waspada" if level == "sedang" else "tidak", headline=head,
                red_flags=flags, factors=F, insights=ins, recs=recs, completeness=comp, missing=miss, n=len(R), as_of=R[-1]["date"] if R else None, bp=bpinfo, disclaimer=DISCLAIMER)
