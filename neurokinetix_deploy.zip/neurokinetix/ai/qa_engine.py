"""Mesin tanya-jawab AI Coach NeuroKinetix.

Pencarian jawaban berbasis dataset (ai/dataset_qa.json): TF-IDF unigram+bigram + kemiripan n-gram karakter (tahan typo),
tanpa pustaka tambahan. Urutan pemrosesan: (1) deteksi krisis jiwa, (2) deteksi gejala darurat, (3) pertanyaan tentang data
pribadi pasien, (4) pencarian dataset, (5) saran pertanyaan bila tidak yakin. Tidak ada generatif/LLM, sehingga jawaban
hanya berasal dari teks yang sudah ditinjau. Batasan: jawaban edukasi umum, bukan diagnosis; tanpa dosis obat."""
import json, math, os, re
from collections import Counter

DIR = os.path.dirname(os.path.abspath(__file__))
SYN = [(r"\b(gak|ga|nggak|ngga|enggak|engga|tak|tdk)\b", "tidak"), (r"\btensi(ku)?\b", "tekanan darah"), (r"\bdarah tinggi\b", "hipertensi"),
       (r"\b(gimana|bgmn|gmn)\b", "bagaimana"), (r"\b(knp|kenapa)\b", "mengapa"), (r"\bkolestrol\b", "kolesterol"), (r"\bkencing manis\b", "diabetes"),
       (r"\b(diabet|dm)\b", "diabetes"), (r"\bdgn\b", "dengan"), (r"\byg\b", "yang"), (r"\bsy\b", "saya"), (r"\b(bgt|banget)\b", "sekali"),
       (r"\b(aja|doang)\b", ""), (r"\b(terkena|kena)\s+stroke\b", "stroke"), (r"\bngopi\b", "kopi"), (r"\bvape\b", "rokok elektrik"),
       (r"\bmindahin\b", "memindahkan"), (r"\bnyala\b", "menyala"), (r"\bdiagnosa\b", "mendiagnosis"), (r"\blumpuh\b", "lemah"), (r"\bnangis\b", "menangis"), (r"\bgampang\b", "mudah"), (r"\bcapek\b", "lelah"), (r"\bngerawat\b", "merawat"),
       (r"\b(bikin|membuat)\b", "menyebabkan"), (r"\bstroke lagi\b", "stroke berulang"), (r"\b(dua kali|kedua kali|kedua|kambuh|terulang)\b", "berulang"), (r"\bnular\b", "menular"),
       (r"\bngomong\b", "bicara"), (r"\bsusah\b", "sulit"), (r"\bcadel\b", "pelo"), (r"\bturunin\b", "menurunkan"), (r"\b(tersumbat|sumbatan|penyumbatan)\b", "iskemik"),
       (r"\b(pecah|perdarahan|pendarahan)\b", "hemoragik"), (r"\bramadhan\b", "ramadan"), (r"\bwifi\b", "internet"), (r"\bnyetir\b", "mengemudi")]
STOP = set("yang dan di ke dari untuk pada dengan itu ini saya aku kah ya dong sih deh nih lah adalah agar supaya jika kalau atau juga sudah masih akan pak bu mau ingin tidak buat bagi tiap".split())
HIGH, MID = 0.50, 0.33
UNK_F, IDF_P, BI_W, UNK_MAX = 0.55, 1.0, 0.6, 0.5   # bobot kata tak dikenal, pangkat idf, bobot bigram, batas porsi kata tak dikenal   # bobot kata tak dikenal (pecahan idf maks) dan pangkat idf   # ambang skor: >=HIGH jawab langsung; MID..HIGH jawab dengan penanda "terdekat"; <MID saran pertanyaan

def norm(t):
    t = t.lower()
    for p, r in SYN: t = re.sub(p, r, t)
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9/ ]+", " ", t)).strip()

def tokens(t):
    out = []
    for w in norm(t).split():
        for suf in ("nya", "kah", "lah"):
            if w.endswith(suf) and len(w) - len(suf) >= 4: w = w[: -len(suf)]; break
        if w not in STOP: out.append(w)
    return out

def feats(tk): return Counter(tk) + Counter({a + "_" + b: BI_W for a, b in zip(tk, tk[1:])})
def tri(tk):
    s = " " + " ".join(tk) + " "; return {s[i:i + 3] for i in range(len(s) - 2)}

class Index:
    def __init__(self, data):
        self.data = data; self.forms = []                    # (idx, fitur, trigram)
        for i, e in enumerate(data):
            for f in [e["q"]] + e["v"]:
                tk = tokens(f); self.forms.append((i, feats(tk), tri(tk)))
        df = Counter(k for _, c, _ in self.forms for k in c); n = len(self.forms)
        self.idf = {k: math.log((n + 1) / (v + 1)) + 1 for k, v in df.items()}; self.unk = UNK_F * (math.log(n + 1) + 1)
        self.vocab = sorted({w for _, c, _ in self.forms for w in c if "_" not in w and len(w) >= 4}); self.bg = {w: self._bi(w) for w in self.vocab}
        self.vecs = [(i, self._vec(c), t) for i, c, t in self.forms]

    @staticmethod
    def _bi(w): return {w[i:i + 2] for i in range(len(w) - 1)}

    def fix(self, tk):
        """Koreksi kata tak dikenal ke kata terdekat di kosakata (typo, singkatan, awalan me-/pe-)."""
        out = []
        for w in tk:
            if len(w) < 5 or w in self.idf: out.append(w); continue
            b = self._bi(w); best, bs = None, 0
            for v, vb in self.bg.items():
                if abs(len(v) - len(w)) > 4: continue
                inter = len(b & vb); sc = 2 * inter / (len(b) + len(vb))
                if sc > bs: best, bs = v, sc
            out.append(best if best and bs >= 0.8 else w)
        return out

    def _vec(self, c):
        v = {k: (1 + math.log(max(n, 1)) if n >= 1 else n) * self.idf.get(k, self.unk) ** IDF_P for k, n in c.items()}; z = math.sqrt(sum(x * x for x in v.values())) or 1
        return {k: x / z for k, x in v.items()}

    def search(self, query, k=5):
        tk = tokens(query)
        if not tk: return []
        tk = self.fix(tk)
        if sum(1 for w in tk if w not in self.idf) / len(tk) >= UNK_MAX: return []
        qv, qt = self._vec(feats(tk)), tri(tk); best = {}
        for i, v, t in self.vecs:
            cos = sum(w * v.get(f, 0) for f, w in qv.items()); dice = 2 * len(qt & t) / (len(qt) + len(t)) if qt and t else 0
            sc = 0.8 * cos + 0.2 * dice
            if sc > best.get(i, 0): best[i] = sc
        return sorted(((s, i) for i, s in best.items()), reverse=True)[:k]

def load(path=None):
    with open(path or os.path.join(DIR, "dataset_qa.json"), encoding="utf-8") as f: return json.load(f)["data"]
_DATA = load(); _IDX = Index(_DATA)

# ---------- keselamatan ----------
SELFHARM = re.compile(r"bunuh diri|(meng)?akhiri hidup|menyakiti diri|melukai diri|\b(ingin|pengen|pingin|mau|lebih baik|rasanya)( \w+){0,2} (mati|menghilang selamanya)\b|"
                      r"tidak (ingin|mau|kuat|sanggup|sanggup lagi)( \w+)? hidup|\b(lelah|bosan|muak) hidup|hidup (ini )?(tidak|tak) (ada )?(arti|guna|berguna)")
SELFHARM_TEXT = ("Saya sangat prihatin Anda merasa seberat ini, dan Anda tidak sendirian. Mohon sekarang juga hubungi keluarga atau orang terdekat dan minta mereka menemani Anda. "
                 "Jika ada dorongan untuk menyakiti diri, segera hubungi 112 atau datang ke IGD terdekat. Setelah itu, sampaikan perasaan ini kepada dokter atau psikolog, karena depresi setelah stroke dapat diobati.")
SYMPTOM = re.compile(r"mencong|pelo|bicara (kacau|tidak jelas|tidak nyambung)|tidak bisa bicara|tidak bisa (menggerakkan|digerakkan|digerakan)|lemah|separuh|sebelah|pingsan|tidak sadar|kejang|nyeri dada|sakit dada|sesak|"
                     r"(sakit kepala|kepala sakit) (hebat|sekali|parah)|(pandangan|penglihatan|mata) (gelap|kabur|ganda|hilang)")
SUDDEN = re.compile(r"mendadak|tiba tiba|barusan|baru saja|baru mulai")
INFO_Q = re.compile(r"^(apa itu|apakah|apa bedanya|apa saja|mengapa|bagaimana cara)\b"); PERSON = re.compile(r"\b(saya|ayah|ibu|bapak|pasien|dia|beliau|suami|istri|kakek|nenek|mama|papa)\b")
EMERG_TEXT = ("⚠ Ini bisa tanda stroke atau kondisi darurat. Segera hubungi 112 atau bawa ke IGD terdekat sekarang. Catat jam gejala mulai. "
              "Jangan beri makan, minum, atau obat (termasuk aspirin) sebelum diperiksa tenaga medis, dan jangan menunggu gejala hilang sendiri.")

def is_emergency(t): return bool(SYMPTOM.search(t) and SUDDEN.search(t) and not (INFO_Q.search(t) and not PERSON.search(t)))

# ---------- data pribadi ----------
SELF = re.compile(r"\b(saya|aku|pasien|bapak|ibu|ayah|beliau|dia|kami)\b|\b\w+ku\b")
GENERIC = re.compile(r"\b(normal|target|batas|seharusnya|idealnya|ideal|bahaya|boleh|cara|ukur|mengukur|apa itu|artinya|arti|menurunkan|supaya|agar|makanan|obat|siapa|kapan|keluarga|pernah|ikut|diturunkan|dilihat|disimpan)\b")
STATUS = re.compile(r"\b(berapa|bagaimana|apakah|terkendali|bagus|terakhir|sekarang|kondisi|hasil|mengapa|status|perkembangan|kemajuan|berpotensi)\b")
TOPICS = [("bp", r"tekanan darah|hipertensi"), ("glucose", r"gula|diabetes|hba1c"), ("lipid", r"kolesterol|ldl|trigliserida"),
          ("fma", r"\bfma\b|fugl"), ("risk", r"\b(risiko|resiko)\b|berpotensi|stroke berulang|\bberulang\b"), ("progress", r"kemajuan|progress|perkembangan|kepatuhan|latihan saya")]

def personal_intent(t):
    if not SELF.search(t) or GENERIC.search(t) or not STATUS.search(t): return None
    for k, p in TOPICS:
        if re.search(p, t): return k

def _f(r, key): return next((f for f in (r or {}).get("factors", []) if f["key"] == key), None)

def personal_line(kind, ctx):
    r = ctx.get("risk") or {}
    if kind in ("bp", "glucose", "lipid"):
        f = _f(r, kind)
        if not f or f["value"].startswith("Belum"): return None
        s = f"Data Anda: {f['value']}" + (f", penilaian: {f['note']}" if f.get("note") else "") + "."
        if kind == "bp" and r.get("bp"): s += f" Pengukuran yang mencapai target di bawah 130/80 mmHg: {r['bp']['control_pct']}% dari {r['bp']['n']} terakhir."
        return s
    if kind == "risk":
        return None if r.get("score") is None else f"Data Anda: skor risiko stroke berulang {r['score']}/100 (kategori {r['level']})."
    if kind == "progress": return None if ctx.get("adh") is None else f"Data Anda: kepatuhan latihan {ctx['adh']:.0f}% (target {ctx.get('tpw', 5)} hari per minggu)."
    if kind == "fma": return f"Data Anda: estimasi FMA-UE {ctx['fma']:.0f}/66 (dari ROM kamera, bukan skor klinis resmi)." if ctx.get("fma") else None

NODATA = {"bp": "tekanan darah", "glucose": "gula darah", "lipid": "kolesterol", "risk": "kesehatan", "progress": "latihan", "fma": "latihan kamera"}
TAIL = {"bp": "Target pencegahan stroke umumnya di bawah 130/80 mmHg; target pastinya ditentukan dokter.", "glucose": "Target HbA1c umumnya di bawah 7%; dokter menentukan target pribadi.",
        "lipid": "Pada stroke iskemik, target LDL umumnya di bawah 70 mg/dL; dokter menentukan target pribadi.", "fma": "Penilaian klinis resmi tetap dilakukan fisioterapis.", "progress": "", "risk": ""}

def personal_answer(kind, ctx):
    line = personal_line(kind, ctx)
    if not line: return f"Belum ada data {NODATA[kind]} yang bisa dianalisis. " + ("Masukkan di halaman Risiko Stroke." if kind in ("bp", "glucose", "lipid", "risk") else "Lakukan latihan terlebih dahulu.")
    extra = ""
    if kind == "risk":
        top = sorted([f for f in (ctx.get("risk") or {}).get("factors", []) if f["pts"] > 0], key=lambda f: -f["pts"])[:3]
        extra = (" Faktor penyumbang terbesar: " + ", ".join(f"{f['name']} ({f['pts']} poin)" for f in top) + ".") if top else ""
        extra += " " + (ctx["risk"].get("headline") or "")
    return (line + extra + " " + TAIL[kind] + " Ini skrining, bukan diagnosis.").replace("  ", " ").strip()

# ---------- jawaban ----------
def _resp(answer, kind, e=None, score=0.0, sugg=None, intent=None):
    return dict(answer=answer, kind=kind, id=e["id"] if e else None, cat=e["kategori"] if e else None, urgency=e["urgensi"] if e else None,
                matched=e["q"] if e else None, score=round(score, 3), suggestions=sugg or [], intent=intent)

STARTERS = ["Apa saja tanda-tanda stroke?", "Bagaimana cara mencegah stroke berulang?", "Berapa tekanan darah normal?"]
def _sugg(hits, skip=None, n=3):
    out = [_DATA[i]["q"] for s, i in hits if i != skip and s > 0.2][:n]
    return out or [q for q in STARTERS][:n]
SMALL = re.compile(r"^(halo|hai|hi|selamat (pagi|siang|sore|malam)|terima kasih|makasih|thanks|oke|ok)\b")

def answer(question, ctx=None):
    ctx = ctx or {}; raw = (question or "").strip()[:500]
    if not raw: return _resp("Silakan tulis pertanyaan Anda, misalnya: Apa tanda-tanda stroke?", "kosong")
    t = norm(raw)
    if SELFHARM.search(t): return _resp(SELFHARM_TEXT, "krisis")
    if is_emergency(t): return _resp(EMERG_TEXT, "darurat")
    if SMALL.match(t) and len(t.split()) <= 4: return _resp("Halo! Saya AI Coach NeuroKinetix. Tanyakan seputar stroke, tanda darurat, tekanan darah, gula darah, kolesterol, makanan, obat, latihan, atau cara memakai aplikasi.", "smalltalk")
    k = personal_intent(t)
    if k: return _resp(personal_answer(k, ctx), "personal", intent=k)
    hits = _IDX.search(raw)
    if not hits or hits[0][0] < MID:
        return _resp("Maaf, saya belum menemukan jawaban yang tepat. Coba tanyakan dengan kata lain, atau pilih salah satu pertanyaan di bawah. Untuk keluhan khusus, hubungi dokter atau fisioterapis.", "fallback", sugg=_sugg(hits))
    sc, i = hits[0]; e = _DATA[i]; a = e["a"]
    if e["urgensi"] == "darurat": a = "⚠ " + a
    if e.get("pers"):
        line = personal_line(e["pers"], ctx)
        if line: a += "\n\n" + line
    if sc < HIGH: a = f"Jawaban terdekat yang saya punya, untuk pertanyaan “{e['q']}”:\n\n" + a
    return _resp(a, "dataset" if sc >= HIGH else "mirip", e, sc, _sugg(hits, i))

def topics():
    out = {}
    for e in _DATA: out.setdefault(e["kategori"], []).append(e["q"])
    return [dict(name=k, count=len(v), questions=v) for k, v in out.items()]
