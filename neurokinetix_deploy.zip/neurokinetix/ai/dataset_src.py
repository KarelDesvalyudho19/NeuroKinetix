"""Sumber dataset tanya-jawab AI Coach NeuroKinetix (bahasa Indonesia).
Tiap entri: pertanyaan utama + 2 variasi (gaya bahasa pasien/keluarga) + jawaban + urgensi + perlu_dokter + personalisasi.
Jalankan `python tools/build_dataset.py` setelah mengubah file ini untuk membuat ulang ai/dataset_qa.json dan Excel.
PENTING: konten bersifat edukasi umum, tanpa dosis obat. Wajib ditinjau dokter/fisioterapis sebelum dipakai nyata."""
DATA, _cat = [], [""]
REF = {
 "Dasar Stroke": "AHA/ASA (pedoman stroke); Kemenkes RI & PERDOSSI",
 "Gejala & Tanda Darurat": "Kampanye SeGeRa Kemenkes RI; AHA/ASA (BE-FAST)",
 "Faktor Risiko & Penyebab": "AHA/ASA pencegahan primer & sekunder; WHO",
 "Pencegahan Stroke Berulang": "AHA/ASA 2021 pencegahan sekunder stroke; PERDOSSI",
 "Tekanan Darah": "AHA/ACC 2017; PERHI (hipertensi); WHO (garam)",
 "Gula Darah & Diabetes": "PERKENI; ADA Standards of Care",
 "Kolesterol": "AHA/ASA 2021; PERKI (dislipidemia)",
 "Pola Makan & Gizi": "Pedoman Gizi Seimbang Kemenkes (Isi Piringku); pola DASH; WHO",
 "Obat & Kepatuhan": "Informasi umum edukasi; selalu ikuti dokter/apoteker",
 "Rehabilitasi & Latihan": "AHA/ASA Adult Stroke Rehabilitation; PERDOSSI/PERDOSRI",
 "Komplikasi Pasca Stroke": "AHA/ASA Adult Stroke Rehabilitation; PERDOSSI",
 "Emosi & Kesehatan Jiwa": "AHA/ASA; Kemenkes RI (kesehatan jiwa)",
 "Perawatan di Rumah": "AHA/ASA rehabilitasi; panduan perawatan keluarga umum",
 "Gaya Hidup": "AHA/ASA; WHO",
 "Pemeriksaan & Kontrol": "AHA/ASA; PERDOSSI",
 "Penggunaan Aplikasi": "Dokumentasi internal NeuroKinetix (README, docs/)",
}
def C(name): _cat[0] = name
def A(q, v1, v2, ans, urg="info", dok=0, pers=""):
    DATA.append(dict(kategori=_cat[0], urgensi=urg, dokter=dok, pers=pers, q=q, v=[v1, v2], a=ans))

# ===================== 1. DASAR STROKE =====================
C("Dasar Stroke")
A("Apa itu stroke?", "stroke itu penyakit apa", "tolong jelaskan pengertian stroke",
  "Stroke adalah gangguan aliran darah ke otak, entah karena pembuluh darah tersumbat (stroke iskemik) atau pecah (stroke hemoragik). Sel otak yang kekurangan darah dan oksigen cepat rusak, sehingga muncul kelemahan, bicara pelo, atau gangguan lain.")
A("Apa bedanya stroke iskemik dan stroke hemoragik?", "bedanya stroke sumbatan sama stroke perdarahan apa", "stroke iskemik vs hemoragik",
  "Stroke iskemik disebabkan sumbatan pembuluh darah otak dan merupakan jenis yang paling sering. Stroke hemoragik disebabkan pembuluh darah pecah sehingga terjadi perdarahan. Penanganannya berbeda, karena itu jenisnya harus dipastikan dokter lewat CT scan atau MRI.")
A("Apa itu stroke iskemik?", "stroke sumbatan itu bagaimana", "stroke iskemik disebabkan apa",
  "Stroke iskemik terjadi saat bekuan darah atau plak menyumbat pembuluh darah yang mengalirkan darah ke otak. Faktor yang sering mendasarinya adalah hipertensi, diabetes, kolesterol tinggi, merokok, dan gangguan irama jantung.")
A("Apa itu stroke hemoragik?", "stroke perdarahan otak itu apa", "kenapa pembuluh darah otak bisa pecah",
  "Stroke hemoragik adalah perdarahan di dalam atau sekitar otak akibat pembuluh darah pecah. Penyebab tersering adalah tekanan darah tinggi yang tidak terkontrol. Karena itu menjaga tekanan darah sangat penting pada jenis stroke ini.")
A("Apa itu TIA atau stroke ringan sementara?", "tia itu apa", "gejala stroke hilang sendiri itu apa namanya",
  "TIA (transient ischemic attack) adalah gejala mirip stroke yang hilang sendiri dalam menit hingga jam karena sumbatan sementara. TIA adalah peringatan keras akan stroke yang lebih besar, jadi tetap harus segera diperiksa di IGD.", "waspada", 1)
A("Apakah stroke bisa sembuh total?", "stroke bisa pulih seperti semula tidak", "apakah penderita stroke bisa normal lagi",
  "Tingkat pemulihan berbeda pada tiap orang. Banyak pasien membaik, terutama dengan rehabilitasi dini dan rutin, tetapi kesembuhan total tidak bisa dijanjikan. Perbaikan sering berlanjut berbulan-bulan jika latihan dilakukan konsisten.")
A("Berapa lama pemulihan stroke?", "stroke sembuh dalam berapa bulan", "kapan lengan yang lemah bisa kembali normal",
  "Perbaikan paling cepat umumnya terjadi pada 3 sampai 6 bulan pertama, namun kemajuan dapat berlanjut lebih lama dengan latihan. Kecepatannya bergantung pada luas kerusakan otak, usia, penyakit penyerta, dan kedisiplinan rehabilitasi.")
A("Apakah stroke menular?", "stroke bisa menular ke keluarga tidak", "apakah aman dekat dengan penderita stroke",
  "Tidak. Stroke bukan penyakit menular. Anggota keluarga aman mendampingi pasien. Yang perlu diperhatikan keluarga adalah faktor risiko bersama seperti pola makan dan kebiasaan merokok.")
A("Apakah stroke bisa kambuh lagi?", "stroke bisa terulang tidak", "kenapa penderita stroke bisa kena stroke kedua",
  "Ya, stroke dapat berulang, terutama bila faktor risikonya tidak terkendali. Risiko ditekan dengan menjaga tekanan darah, gula darah, dan kolesterol, berhenti merokok, rutin minum obat, serta kontrol berkala.", "info", 1, "risk")
A("Apakah stroke bisa terjadi pada usia muda?", "anak muda bisa kena stroke tidak", "stroke di usia 30 an mungkin tidak",
  "Bisa, walau lebih jarang. Pada usia muda penyebabnya dapat berupa hipertensi, kelainan jantung, kelainan pembuluh darah, gangguan pembekuan darah, merokok, atau penyalahgunaan zat. Gejala yang muncul tetap harus ditangani sebagai darurat.")
A("Apa itu waktu emas penanganan stroke?", "kenapa stroke harus cepat dibawa ke rumah sakit", "golden period stroke berapa jam",
  "Pada stroke iskemik, terapi pembuka sumbatan hanya efektif dalam jendela waktu terbatas, umumnya beberapa jam sejak gejala mulai. Semakin cepat tiba di rumah sakit, semakin besar peluang menyelamatkan jaringan otak. Karena itu catat jam gejala pertama muncul.", "darurat", 1)
A("Apa itu hemiparesis?", "kelemahan separuh badan itu apa namanya", "kenapa stroke bikin satu sisi tubuh lemah",
  "Hemiparesis adalah kelemahan pada satu sisi tubuh. Sisi yang lemah berlawanan dengan sisi otak yang terkena, misalnya kerusakan otak kiri menyebabkan kelemahan tubuh sisi kanan. Latihan rehabilitasi membantu melatih ulang gerakan sisi yang lemah.")
A("Apa itu afasia?", "kenapa pasien stroke sulit bicara atau memahami kata", "afasia itu apa artinya",
  "Afasia adalah gangguan bahasa akibat kerusakan area bahasa di otak: pasien bisa sulit mengucapkan kata, memahami ucapan, membaca, atau menulis. Afasia bukan berarti kecerdasan hilang. Terapi wicara sangat membantu.")
A("Apa itu disartria atau bicara pelo?", "bicara pelo itu kenapa", "disartria apa bedanya dengan afasia",
  "Disartria adalah bicara pelo karena otot yang mengatur ucapan lemah. Isi pikiran dan pilihan katanya benar, hanya pengucapannya tidak jelas. Pada afasia, yang terganggu adalah kemampuan bahasanya sendiri. Keduanya dapat diperbaiki dengan terapi wicara.")
A("Apa itu neglect atau mengabaikan satu sisi tubuh?", "pasien tidak menyadari sisi tubuh yang lemah", "kenapa pasien stroke seperti lupa sisi kirinya",
  "Neglect adalah kondisi saat pasien tidak menyadari sisi tubuh atau ruang di satu sisi akibat kerusakan otak, bukan karena malas. Keluarga dapat membantu dengan mengajak pasien menoleh ke sisi tersebut, meletakkan benda di sisi itu, dan berbicara dari sisi tersebut.")
A("Apakah stroke sama dengan serangan jantung?", "bedanya stroke dan serangan jantung apa", "stroke itu penyakit jantung bukan",
  "Bukan. Stroke terjadi di otak, serangan jantung terjadi di jantung. Keduanya sama-sama berkaitan dengan pembuluh darah dan berbagi faktor risiko seperti hipertensi, kolesterol tinggi, diabetes, dan merokok.")
A("Apakah semua penderita stroke mengalami kelumpuhan?", "tidak semua stroke lumpuh kan", "gejala stroke tergantung apa",
  "Tidak semua. Gejala bergantung pada bagian otak yang terkena. Ada pasien yang hanya mengalami bicara pelo, gangguan penglihatan, atau gangguan keseimbangan tanpa kelumpuhan berat.")
A("Apakah stroke bisa terjadi saat tidur?", "stroke bisa muncul waktu tidur", "bangun tidur tiba tiba lemah separuh badan",
  "Bisa. Stroke dapat terjadi kapan saja termasuk saat tidur, dan gejalanya baru terlihat saat bangun. Jika terjadi, waktu yang dihitung adalah saat terakhir pasien terlihat normal. Segera ke IGD.", "darurat", 1)

# ===================== 2. GEJALA & DARURAT =====================
C("Gejala & Tanda Darurat")
A("Apa saja tanda-tanda stroke?", "gejala stroke apa saja", "ciri ciri orang mau kena stroke",
  "Kenali SeGeRa: Senyum tidak simetris (wajah mencong), Gerak separuh anggota tubuh melemah, bicaRa pelo atau tidak nyambung, Kebas atau baal separuh tubuh, Rabun atau gangguan penglihatan mendadak, dan Sakit kepala hebat mendadak. Bila muncul, segera ke IGD.", "darurat", 1)
A("Apa arti SeGeRa ke RS?", "singkatan segera ke rs untuk stroke", "kampanye segera ke rumah sakit stroke maksudnya apa",
  "SeGeRa ke RS adalah panduan mengenali stroke: Senyum tidak simetris, Gerak separuh tubuh melemah, bicaRa pelo, Kebas separuh tubuh, Rabun mendadak, Sakit kepala hebat mendadak. Bila ada salah satu, bawa ke rumah sakit secepatnya.", "darurat", 1)
A("Wajah mencong mendadak, apa yang harus dilakukan?", "mulut saya tiba tiba mencong harus bagaimana", "ayah wajahnya mencong sebelah",
  "Ini tanda darurat stroke. Segera hubungi 112 atau bawa ke IGD terdekat. Catat jam gejala mulai. Jangan menunggu gejala hilang dan jangan memberi makan, minum, atau obat termasuk aspirin sebelum diperiksa tenaga medis.", "darurat", 1)
A("Bicara pelo mendadak, apa yang harus dilakukan?", "ibu tiba tiba bicaranya pelo", "tidak bisa bicara jelas tiba tiba",
  "Bicara pelo atau tidak nyambung yang muncul mendadak adalah tanda darurat stroke. Segera hubungi 112 atau ke IGD, catat jam mulainya, dan jangan memberi makan, minum, atau obat sebelum diperiksa.", "darurat", 1)
A("Lengan atau kaki tiba-tiba lemah, apa yang harus dilakukan?", "tangan tiba tiba lemas tidak bisa mengangkat", "kaki mendadak lumpuh sebelah",
  "Kelemahan mendadak pada lengan, kaki, atau separuh tubuh adalah tanda darurat stroke. Segera ke IGD atau hubungi 112. Jangan menunggu membaik dan jangan memijat atau menarik anggota yang lemah.", "darurat", 1)
A("Sakit kepala hebat mendadak, apakah berbahaya?", "kepala sakit sekali seperti dipukul tiba tiba", "sakit kepala paling parah seumur hidup",
  "Sakit kepala yang sangat hebat dan mendadak, apalagi disertai muntah, kaku leher, atau penurunan kesadaran, dapat menandakan perdarahan otak. Ini darurat: segera ke IGD atau hubungi 112.", "darurat", 1)
A("Pandangan kabur atau ganda mendadak, apakah tanda stroke?", "mata tiba tiba tidak bisa melihat sebelah", "penglihatan gelap mendadak stroke bukan",
  "Gangguan penglihatan mendadak seperti kabur, ganda, atau hilang pada satu sisi dapat merupakan tanda stroke. Segera periksa ke IGD, jangan menunggu hilang sendiri.", "darurat", 1)
A("Pusing berputar mendadak disertai sulit berjalan, apakah stroke?", "pusing berputar dan tidak bisa berdiri tegak", "vertigo tiba tiba disertai bicara pelo",
  "Pusing berputar yang disertai sulit berdiri atau berjalan, bicara pelo, penglihatan ganda, atau lemah anggota badan bisa menandakan stroke di bagian belakang otak. Segera ke IGD. Vertigo ringan tanpa gejala lain tetap perlu diperiksa dokter.", "darurat", 1)
A("Apakah gejala stroke yang hilang sendiri tetap perlu ke dokter?", "gejalanya sudah hilang apakah masih perlu ke rumah sakit", "stroke ringan hilang sendiri aman tidak",
  "Tetap perlu. Gejala yang hilang sendiri bisa berupa TIA, yaitu peringatan stroke yang lebih besar dalam waktu dekat. Segera periksakan ke IGD atau dokter saraf pada hari yang sama.", "darurat", 1)
A("Pasien stroke tidak sadar atau kejang, apa yang harus dilakukan?", "pasien pingsan dan tidak bangun", "pasien kejang setelah stroke harus bagaimana",
  "Hubungi 112 atau bawa ke IGD segera. Baringkan pasien pada sisi tubuhnya, longgarkan pakaian, singkirkan benda berbahaya di sekitar, dan jangan memasukkan apa pun ke mulutnya. Catat lama kejang dan jam kejadian.", "darurat", 1)
A("Apa yang harus dilakukan keluarga saat ada yang terkena stroke?", "pertolongan pertama stroke di rumah", "langkah pertama jika ada yang kena stroke",
  "Tetap tenang, segera hubungi 112 atau bawa ke IGD, dan catat jam gejala mulai. Baringkan atau dudukkan pasien dengan nyaman, longgarkan pakaian, dan jangan beri makan, minum, atau obat. Bawa daftar obat dan hasil pemeriksaan terakhir.", "darurat", 1)
A("Apakah menusuk ujung jari atau kerokan menolong stroke?", "tusuk jarum di jari bisa menyembuhkan stroke", "boleh dikerok dulu sebelum ke rumah sakit",
  "Tidak terbukti menolong dan justru menunda penanganan yang sangat sensitif terhadap waktu. Jangan menunda: langsung bawa ke IGD.", "darurat", 1)
A("Nyeri dada hebat pada pasien stroke, apa yang harus dilakukan?", "dada sakit sekali dan keringat dingin", "nyeri dada menjalar ke lengan saat latihan",
  "Nyeri dada hebat, terutama dengan keringat dingin, sesak, atau menjalar ke lengan atau rahang, bisa menandakan masalah jantung. Hentikan aktivitas, duduk tenang, dan segera hubungi 112 atau ke IGD.", "darurat", 1)
A("Sesak napas berat, apa yang harus dilakukan?", "napas tiba tiba sesak sekali", "pasien sulit bernapas setelah makan",
  "Sesak napas berat atau tiba-tiba membutuhkan pertolongan segera. Dudukkan pasien tegak, longgarkan pakaian, dan hubungi 112 atau bawa ke IGD. Jika terjadi setelah tersedak saat makan, sampaikan hal itu ke petugas.", "darurat", 1)
A("Kapan harus ke IGD dan kapan cukup ke dokter biasa?", "kapan perlu ke igd untuk pasien stroke", "gejala apa yang tidak boleh ditunda",
  "Ke IGD segera bila ada gejala baru SeGeRa, penurunan kesadaran, kejang, nyeri dada, sesak berat, atau tekanan darah sangat tinggi dengan gejala. Hubungi dokter pada hari yang sama untuk demam, tersedak berulang, bengkak satu tungkai, atau obat yang tidak bisa diminum.", "darurat", 1)
A("Tekanan darah sangat tinggi dengan gejala, apa yang harus dilakukan?", "tensi 200 dan pusing hebat bagaimana", "tekanan darah 180/120 apa tindakannya",
  "Tekanan darah 180/120 mmHg atau lebih adalah kondisi berbahaya. Istirahat tenang 5 menit lalu ukur ulang. Bila tetap setinggi itu, atau ada sakit kepala hebat, nyeri dada, sesak, lemah, atau bicara pelo, segera ke IGD atau hubungi 112.", "darurat", 1, "bp")
A("Gula darah sangat rendah dan pasien bingung, apa yang harus dilakukan?", "gula darah turun pasien lemas gemetar keringat dingin", "hipoglikemia pada pasien stroke bagaimana",
  "Jika pasien sadar dan bisa menelan, beri sekitar 15 gram gula (misalnya 3 sendok teh gula atau setengah gelas minuman manis), cek ulang gula darah setelah 15 menit. Jika tidak sadar, jangan beri makan atau minum, segera hubungi 112 atau ke IGD.", "darurat", 1)
A("Apa gejala stroke berulang?", "gejala stroke yang kedua sama tidak", "tanda stroke kambuh apa",
  "Gejalanya sama dengan stroke pertama dan sering tidak persis sama, misalnya bisa muncul di sisi tubuh atau fungsi yang berbeda. Perburukan mendadak pada kelemahan, bicara, atau penglihatan tetap diperlakukan sebagai darurat.", "darurat", 1)

# ===================== 3. FAKTOR RISIKO =====================
C("Faktor Risiko & Penyebab")
A("Apa penyebab stroke?", "kenapa orang bisa kena stroke", "penyebab utama stroke apa",
  "Penyebab utama adalah sumbatan atau pecahnya pembuluh darah otak. Yang mendasarinya antara lain hipertensi, diabetes, kolesterol tinggi, merokok, gangguan irama jantung (fibrilasi atrium), obesitas, kurang gerak, dan faktor usia atau keturunan.")
A("Apa saja faktor risiko stroke?", "faktor yang bikin stroke apa saja", "hal yang meningkatkan risiko stroke",
  "Yang bisa dikendalikan: hipertensi, diabetes, kolesterol tinggi, merokok, alkohol berlebih, obesitas, kurang aktivitas, dan fibrilasi atrium. Yang tidak bisa diubah: usia, jenis kelamin, riwayat keluarga, dan riwayat stroke sebelumnya.", "info", 0, "risk")
A("Mengapa hipertensi bisa menyebabkan stroke?", "darah tinggi kenapa bahaya untuk otak", "hubungan tekanan darah tinggi dan stroke",
  "Tekanan darah tinggi terus-menerus merusak dinding pembuluh darah sehingga mudah menyempit dan tersumbat, atau melemah dan pecah. Hipertensi adalah faktor risiko terpenting stroke, sehingga pengendaliannya menjadi prioritas.", "info", 1, "bp")
A("Mengapa diabetes meningkatkan risiko stroke?", "gula darah tinggi bahaya buat stroke", "hubungan diabetes dan stroke",
  "Gula darah tinggi yang lama merusak pembuluh darah besar maupun kecil dan mempercepat penyempitan, sehingga risiko stroke naik. Gula darah yang terkontrol membantu menurunkan risiko dan menunjang pemulihan.", "info", 1, "glucose")
A("Mengapa kolesterol tinggi berbahaya untuk stroke?", "kolesterol bisa bikin stroke kenapa", "hubungan kolesterol dan sumbatan otak",
  "Kolesterol LDL berlebih membentuk plak di dinding pembuluh darah. Plak yang menebal menyempitkan pembuluh atau pecah dan memicu bekuan, sehingga menyumbat aliran darah ke otak.", "info", 1, "lipid")
A("Bagaimana rokok memengaruhi risiko stroke?", "merokok bikin stroke tidak", "apakah rokok elektrik atau vape aman untuk penderita stroke",
  "Merokok merusak dinding pembuluh darah, membuat darah lebih mudah menggumpal, dan menaikkan tekanan darah. Risiko menurun setelah berhenti. Rokok elektrik atau vape juga tidak dianjurkan karena tetap mengandung nikotin dan zat berbahaya.")
A("Apa itu fibrilasi atrium dan hubungannya dengan stroke?", "irama jantung tidak teratur bisa stroke", "kenapa jantung berdebar tidak teratur berisiko stroke",
  "Fibrilasi atrium adalah gangguan irama jantung sehingga darah di bilik jantung mudah menggumpal. Gumpalan dapat terbawa ke otak dan menyumbat. Kondisi ini perlu diperiksa dengan EKG dan ditangani dokter, sering dengan obat pencegah pembekuan.", "waspada", 1)
A("Apakah obesitas menyebabkan stroke?", "berat badan berlebih berisiko stroke", "gemuk bahaya untuk otak tidak",
  "Obesitas meningkatkan risiko stroke secara tidak langsung, karena memicu hipertensi, diabetes, dan kolesterol tinggi. Menurunkan berat badan bertahap menuju IMT sehat membantu mengendalikan faktor-faktor itu.")
A("Apakah kurang gerak meningkatkan risiko stroke?", "jarang olahraga bisa stroke", "malas bergerak bahaya tidak",
  "Ya. Kurang aktivitas fisik berkaitan dengan hipertensi, diabetes, obesitas, dan kolesterol tinggi. Aktivitas teratur sesuai kemampuan dan izin fisioterapis membantu menurunkan risiko stroke berulang.")
A("Apakah alkohol berbahaya bagi penderita stroke?", "boleh minum alkohol setelah stroke", "alkohol dan stroke hubungannya",
  "Alkohol berlebih menaikkan tekanan darah dan risiko stroke, terutama stroke perdarahan. Bagi penyintas stroke, paling aman menghindarinya atau membatasinya sesuai arahan dokter, apalagi bila minum obat tertentu.")
A("Apakah stroke diturunkan dalam keluarga?", "ada riwayat stroke di keluarga apakah saya berisiko", "stroke turunan tidak",
  "Riwayat keluarga meningkatkan risiko, karena faktor genetik dan kebiasaan hidup yang sama. Ini tidak bisa diubah, namun risikonya bisa ditekan dengan mengendalikan tekanan darah, gula darah, kolesterol, dan gaya hidup.")
A("Apakah stres bisa menyebabkan stroke?", "stres berat bikin stroke tidak", "kecemasan dan stroke hubungannya",
  "Stres berkepanjangan dapat menaikkan tekanan darah dan mendorong kebiasaan tidak sehat seperti merokok dan makan berlebih, sehingga ikut meningkatkan risiko. Kelola stres dengan istirahat cukup, relaksasi napas, ibadah, dan dukungan sosial.")
A("Apakah mendengkur atau henti napas saat tidur berisiko stroke?", "dengkur keras bahaya stroke", "sleep apnea dan stroke",
  "Ya, henti napas saat tidur (sleep apnea) berkaitan dengan hipertensi dan peningkatan risiko stroke. Bila pasien mendengkur keras, sering terbangun tersedak, atau mengantuk berat di siang hari, bicarakan dengan dokter.", "waspada", 1)
A("Apakah pil KB atau obat hormon meningkatkan risiko stroke?", "kontrasepsi hormonal dan stroke", "terapi hormon menopause aman tidak setelah stroke",
  "Sebagian obat hormon dapat meningkatkan risiko pembekuan darah, terutama bila disertai merokok, hipertensi, atau migrain dengan aura. Setelah stroke, jangan menggunakan atau menghentikan obat hormon tanpa berkonsultasi dengan dokter.", "waspada", 1)
A("Apakah garam berlebih memicu stroke?", "makan asin bikin stroke", "kenapa garam harus dibatasi",
  "Garam (natrium) berlebih menaikkan tekanan darah, dan tekanan darah tinggi adalah faktor risiko utama stroke. WHO menyarankan konsumsi garam kurang dari 5 gram atau sekitar 1 sendok teh per hari.")

# ===================== 4. PENCEGAHAN BERULANG =====================
C("Pencegahan Stroke Berulang")
A("Bagaimana cara mencegah stroke berulang?", "cara agar tidak stroke lagi", "apa yang harus dilakukan supaya stroke tidak kambuh",
  "Kendalikan tekanan darah, gula darah, dan kolesterol, minum obat dari dokter secara teratur, berhenti merokok, batasi alkohol dan garam, jaga berat badan, bergerak sesuai kemampuan, kelola stres, dan kontrol berkala. Cek halaman Risiko Stroke untuk melihat faktor mana yang paling berpengaruh pada Anda.", "info", 1, "risk")
A("Berapa target tekanan darah setelah stroke?", "tekanan darah yang ideal untuk penyintas stroke", "tensi harus di bawah berapa setelah stroke",
  "Pada pencegahan stroke berulang, target yang umum dianjurkan adalah di bawah 130/80 mmHg bila ditoleransi. Target pastinya ditentukan dokter sesuai kondisi Anda, jadi tanyakan saat kontrol.", "info", 1, "bp")
A("Berapa target LDL setelah stroke iskemik?", "kolesterol jahat harus berapa setelah stroke", "target ldl pasca stroke",
  "Untuk stroke iskemik dengan penyebab aterosklerosis, pedoman AHA/ASA menganjurkan target LDL sekitar di bawah 70 mg/dL. Dokter akan menentukan target dan terapinya sesuai kondisi Anda.", "info", 1, "lipid")
A("Berapa target HbA1c bagi penyintas stroke dengan diabetes?", "hba1c yang baik berapa", "target gula darah jangka panjang",
  "Target HbA1c umumnya di bawah 7 persen, namun dapat dilonggarkan atau diperketat oleh dokter sesuai usia, penyakit lain, dan risiko gula darah rendah. Diskusikan target pribadi Anda.", "info", 1, "glucose")
A("Apakah perlu minum aspirin atau obat pengencer darah?", "obat pengencer darah setelah stroke perlu tidak", "apakah saya harus minum aspirin sendiri",
  "Obat pencegah penggumpalan darah sering diberikan setelah stroke iskemik, tetapi jenisnya bergantung pada penyebab stroke. Jangan memulai, mengganti, atau menghentikannya sendiri, karena pada stroke perdarahan obat ini bisa berbahaya.", "waspada", 1)
A("Apakah vitamin atau suplemen bisa mencegah stroke?", "suplemen apa yang bagus untuk mencegah stroke", "boleh minum vitamin saja tanpa obat dokter",
  "Suplemen tidak menggantikan obat dan pengendalian faktor risiko. Bukti manfaat sebagian besar suplemen untuk mencegah stroke berulang masih terbatas. Konsultasikan dulu ke dokter agar tidak berinteraksi dengan obat.", "info", 1)
A("Seberapa sering harus kontrol ke dokter setelah stroke?", "jadwal kontrol stroke", "berapa bulan sekali periksa lagi",
  "Mengikuti jadwal dokter, biasanya lebih sering pada bulan-bulan awal lalu berkala. Kontrol juga dibutuhkan saat obat diubah atau muncul keluhan baru. Jangan menunggu obat habis baru kontrol.", "info", 1)
A("Apakah perlu mengukur tekanan darah di rumah?", "perlu punya tensimeter di rumah tidak", "cek tensi sendiri di rumah penting tidak",
  "Sangat dianjurkan. Pengukuran di rumah menunjukkan tren sehari-hari dan membantu dokter menyesuaikan obat. Catat hasilnya, lalu masukkan ke halaman Risiko Stroke agar tren bisa dianalisis.", "info", 0, "bp")
A("Bagaimana cara mendeteksi gangguan irama jantung di rumah?", "cek nadi untuk fibrilasi atrium", "denyut nadi tidak teratur harus bagaimana",
  "Raba nadi di pergelangan tangan selama satu menit. Bila terasa tidak teratur, cepat sekali, atau disertai berdebar, pusing, dan sesak, catat dan periksakan EKG ke dokter. Anda juga dapat menandai nadi tidak teratur saat input data di aplikasi.", "waspada", 1)
A("Diet apa yang baik untuk mencegah stroke berulang?", "pola makan pencegah stroke", "makanan sehat agar tidak stroke lagi",
  "Pola DASH atau mediterania: banyak sayur, buah, biji-bijian utuh, kacang, dan ikan; batasi garam, gula, lemak jenuh, gorengan, dan makanan olahan. Sesuaikan dengan kondisi seperti diabetes atau penyakit ginjal bersama ahli gizi.")
A("Apakah olahraga membantu mencegah stroke berulang?", "olahraga apa yang aman setelah stroke", "berapa lama olahraga yang dianjurkan",
  "Ya. Bagi yang mampu, aktivitas intensitas sedang sekitar 150 menit per minggu dianjurkan, dibagi dalam sesi pendek dan ditingkatkan bertahap. Konsultasikan jenis dan intensitasnya ke dokter atau fisioterapis. Latihan di aplikasi ini ikut dihitung.", "info", 1)
A("Apakah herbal bisa mencegah stroke?", "jamu untuk stroke aman tidak", "obat tradisional untuk menyembuhkan stroke",
  "Belum ada herbal yang terbukti menggantikan pengobatan stroke. Beberapa herbal dapat berinteraksi dengan obat pengencer darah atau obat tekanan darah. Sampaikan semua jamu atau suplemen yang dipakai kepada dokter atau apoteker.", "waspada", 1)
A("Apakah penyempitan pembuluh darah leher perlu tindakan?", "stenosis karotis perlu operasi", "pembuluh darah leher tersumbat bagaimana",
  "Penyempitan arteri karotis dapat menyebabkan stroke iskemik. Dokter menilai derajat penyempitan lewat pemeriksaan seperti Doppler karotis atau CT angiografi, lalu menimbang obat atau tindakan. Keputusannya individual.", "info", 1)
A("Berapa besar kemungkinan stroke berulang pada saya?", "peluang saya kena stroke lagi berapa persen", "apakah saya berpotensi stroke lagi",
  "Tidak ada angka tunggal yang pasti. Aplikasi ini memberi skor skrining 0 sampai 100 dari faktor risiko yang Anda isi, bukan persentase peluang. Lihat halaman Risiko Stroke untuk kategori dan faktor yang paling berperan.", "info", 1, "risk")

# ===================== 5. TEKANAN DARAH =====================
C("Tekanan Darah")
A("Berapa tekanan darah normal?", "tensi normal berapa", "batas tekanan darah yang sehat",
  "Normal bila di bawah 120/80 mmHg. Angka 120 sampai 129 untuk sistolik dengan diastolik di bawah 80 disebut meningkat. Nilai ideal bagi pasien stroke ditentukan dokter.", "info", 0, "bp")
A("Apa itu hipertensi?", "tekanan darah tinggi itu berapa angkanya", "tensi berapa disebut darah tinggi",
  "Hipertensi adalah tekanan darah yang menetap tinggi. Di Indonesia umumnya didefinisikan sebagai 140/90 mmHg atau lebih; pedoman AHA/ACC 2017 memakai batas 130/80 mmHg. Diagnosisnya perlu beberapa kali pengukuran oleh tenaga kesehatan.", "info", 1, "bp")
A("Bagaimana cara mengukur tekanan darah di rumah dengan benar?", "cara pakai tensimeter yang benar", "posisi mengukur tensi yang benar",
  "Duduk tenang 5 menit, punggung bersandar, kaki menapak lantai, lengan rileks setinggi jantung, manset pas di lengan atas. Jangan bicara saat diukur, hindari kopi, rokok, atau olahraga 30 menit sebelumnya. Ukur dua kali berjarak 1 menit dan catat rata-ratanya.")
A("Kapan waktu terbaik mengukur tekanan darah?", "tensi sebaiknya dicek jam berapa", "ukur tensi sebelum atau sesudah minum obat",
  "Cara umum: ukur pagi sebelum minum obat dan malam sebelum tidur, pada jam yang sama setiap hari. Ikuti jadwal yang diberikan dokter Anda.")
A("Di lengan mana tensi sebaiknya diukur pada pasien stroke?", "ukur tensi di tangan yang lemah atau sehat", "boleh tensi di lengan yang lumpuh",
  "Umumnya pengukuran dilakukan di lengan yang tidak lemah. Jika pasien sudah diminta dokter mengukur di lengan tertentu atau kedua lengan, ikuti arahan itu.")
A("Tekanan darah saya 150/90, apakah berbahaya?", "tensi 150/90 bahaya tidak", "tekanan darah 160 berapa bahayanya",
  "Angka itu di atas target pencegahan stroke (di bawah 130/80). Belum tentu darurat bila tanpa gejala, tetapi perlu dikendalikan: ukur ulang dengan benar, minum obat teratur, kurangi garam, dan sampaikan ke dokter pada kontrol terdekat. Jika disertai gejala stroke, segera ke IGD.", "waspada", 1, "bp")
A("Tekanan darah terlalu rendah, apakah berbahaya?", "tensi 90/60 normal tidak", "pusing saat berdiri apakah tensi rendah",
  "Tekanan darah di bawah sekitar 90/60 dengan pusing, lemas, atau hampir pingsan perlu dilaporkan ke dokter, karena obat bisa perlu disesuaikan. Bangun perlahan dari posisi duduk atau berbaring untuk mencegah jatuh.", "waspada", 1)
A("Bolehkah menghentikan obat tekanan darah jika tensi sudah normal?", "tensi sudah normal boleh stop obat", "obat darah tinggi harus diminum seumur hidup",
  "Jangan berhenti sendiri. Tekanan darah normal biasanya karena obat bekerja, dan bila dihentikan tekanan darah dapat naik lagi dan memicu stroke. Dokter yang menentukan apakah dosis bisa diturunkan.", "waspada", 1)
A("Mengapa tekanan darah saya naik turun?", "tensi tidak stabil kenapa", "penyebab tensi tiba tiba naik",
  "Penyebab umum: obat terlewat, makan asin, stres, kurang tidur, nyeri, kopi atau rokok, cara mengukur yang berbeda, dan olahraga. Tekanan darah yang sangat bervariasi dikaitkan dengan risiko stroke lebih tinggi, jadi laporkan ke dokter bila sering terjadi.", "info", 1, "bp")
A("Berapa batas konsumsi garam per hari?", "garam maksimal sehari berapa", "berapa sendok teh garam yang boleh",
  "WHO menyarankan di bawah 5 gram garam per hari, kira-kira 1 sendok teh, termasuk garam tersembunyi pada kecap, saus, mi instan, ikan asin, dan makanan kemasan. Sebagian pasien perlu batas lebih rendah menurut dokter.")
A("Berapa kali sehari tensi perlu diukur?", "seberapa sering cek tekanan darah", "perlu cek tensi tiap hari tidak",
  "Pada awal pengobatan atau saat obat diubah, sering dianjurkan 2 kali sehari selama beberapa hari. Setelah stabil, frekuensinya diatur dokter. Yang penting konsisten dan dicatat.")
A("Berapa denyut nadi normal?", "nadi normal berapa kali per menit", "nadi saya 110 apakah normal",
  "Denyut nadi istirahat orang dewasa umumnya 60 sampai 100 kali per menit. Nadi terus di atas 100, di bawah 50 dengan keluhan, atau tidak teratur perlu diperiksakan ke dokter.", "info", 1)
A("Tensimeter apa yang sebaiknya dipakai di rumah?", "pilih tensimeter digital atau air raksa", "tensimeter pergelangan tangan akurat tidak",
  "Pilih tensimeter digital lengan atas yang sudah tervalidasi dengan ukuran manset sesuai lingkar lengan. Model pergelangan tangan cenderung kurang akurat. Bawa alat ke kontrol untuk dibandingkan dengan alat dokter.")
A("Apakah boleh latihan jika tekanan darah sedang tinggi?", "tensi tinggi boleh olahraga tidak", "tunda latihan kalau tensi berapa",
  "Tekanan darah naik sedikit saat latihan itu wajar. Namun tunda latihan bila tekanan darah istirahat sangat tinggi (misalnya 180/110 atau lebih) atau ada pusing, sakit kepala, atau nyeri dada. Tanyakan batas pastinya kepada dokter atau fisioterapis.", "waspada", 1, "bp")
A("Makanan apa yang membantu menurunkan tekanan darah?", "diet untuk hipertensi", "makanan penurun tensi",
  "Pola DASH: sayur dan buah, biji-bijian utuh, kacang, ikan, susu rendah lemak, serta mengurangi garam dan lemak jenuh. Makanan tidak menggantikan obat dari dokter.")
A("Bagaimana tekanan darah saya sekarang?", "tensi saya terakhir berapa", "apakah tekanan darah saya terkendali",
  "Untuk melihat tekanan darah Anda, saya merujuk pada data yang tercatat di halaman Risiko Stroke.", "info", 0, "bp")

# ===================== 6. GULA DARAH =====================
C("Gula Darah & Diabetes")
A("Berapa gula darah normal?", "kadar gula darah yang sehat", "gula puasa normal berapa",
  "Gula darah puasa (GDP) normal di bawah 100 mg/dL, gula 2 jam setelah makan di bawah 140 mg/dL, dan HbA1c di bawah 5,7 persen. Nilai 100 sampai 125 mg/dL pada puasa disebut prediabetes.", "info", 0, "glucose")
A("Berapa nilai gula darah yang disebut diabetes?", "kriteria diabetes", "gula darah berapa dibilang diabetes",
  "Menurut kriteria PERKENI/ADA: GDP 126 mg/dL atau lebih, gula 2 jam setelah beban glukosa 200 mg/dL atau lebih, HbA1c 6,5 persen atau lebih, atau gula sewaktu 200 mg/dL atau lebih disertai gejala. Diagnosis ditegakkan dokter.", "info", 1)
A("Apa bedanya gula darah puasa dan gula darah sewaktu?", "gdp dan gds itu apa", "perbedaan gula puasa dengan gula sewaktu",
  "Gula darah puasa (GDP) diukur setelah tidak makan minimal 8 jam. Gula darah sewaktu (GDS) diukur kapan saja tanpa memperhatikan jam makan. GDP lebih stabil untuk memantau, GDS berguna saat ada gejala.")
A("Apa itu HbA1c?", "hba1c artinya apa", "tes gula darah 3 bulan",
  "HbA1c menggambarkan rata-rata gula darah sekitar 2 sampai 3 bulan terakhir dan tidak perlu puasa. Nilai ini membantu menilai apakah gula darah terkendali dalam jangka panjang.", "info", 0, "glucose")
A("Mengapa gula darah penting setelah stroke?", "gula darah tinggi memperburuk pemulihan stroke", "hubungan diabetes dengan stroke berulang",
  "Gula darah tinggi menambah kerusakan pembuluh darah dan meningkatkan risiko stroke berulang, sedangkan gula darah terlalu rendah dapat menimbulkan kebingungan dan jatuh. Gula darah yang stabil menunjang pemulihan.", "info", 1, "glucose")
A("Apa gejala gula darah rendah (hipoglikemia)?", "tanda gula darah turun", "gemetar keringat dingin apakah hipoglikemia",
  "Gejala: gemetar, keringat dingin, lapar, berdebar, pusing, lemas, hingga bingung atau pingsan. Jika sadar, beri sekitar 15 gram gula (3 sendok teh atau setengah gelas minuman manis) dan cek ulang 15 menit kemudian. Jika tidak sadar, segera ke IGD.", "waspada", 1)
A("Apa gejala gula darah tinggi (hiperglikemia)?", "tanda gula darah naik", "sering haus dan sering kencing itu kenapa",
  "Gejala: sering haus, sering buang air kecil, mudah lelah, pandangan kabur, dan luka lama sembuh. Gula darah sangat tinggi dengan lemas berat atau napas cepat adalah darurat. Segera hubungi dokter atau ke IGD.", "waspada", 1)
A("Berapa kali harus cek gula darah?", "seberapa sering cek gula", "perlu cek gula darah tiap hari",
  "Frekuensinya ditentukan dokter, bergantung pada obat dan kestabilan gula darah. Pasien dengan insulin atau obat penurun gula tertentu biasanya perlu lebih sering. Catat hasilnya dan masukkan ke aplikasi.")
A("Makanan apa yang baik untuk menjaga gula darah?", "diet diabetes", "boleh makan nasi putih tidak jika gula tinggi",
  "Pilih karbohidrat kompleks dan berserat (nasi dalam porsi terukur, beras merah, oat, sayur, kacang-kacangan), batasi minuman manis, kue, dan gorengan. Atur jam makan teratur dan konsultasikan menu ke ahli gizi.")
A("Bolehkah makan buah jika gula darah tinggi?", "buah apa yang aman untuk diabetes", "boleh minum jus buah tidak",
  "Boleh dalam porsi wajar, utuh lebih baik daripada jus karena seratnya terjaga. Batasi buah sangat manis dan hindari jus kemasan bergula. Atur porsi bersama ahli gizi.")
A("Apakah madu aman bagi penderita diabetes?", "madu boleh tidak untuk gula tinggi", "pemanis alami aman diabetes",
  "Madu tetap mengandung gula dan dapat menaikkan gula darah, jadi tidak otomatis aman. Batasi dan konsultasikan penggunaannya ke dokter atau ahli gizi.")
A("Apa itu prediabetes?", "gula darah agak tinggi tapi belum diabetes", "gdp 110 apakah diabetes",
  "Prediabetes adalah gula darah di atas normal tetapi belum mencapai batas diabetes (GDP 100 sampai 125 mg/dL atau HbA1c 5,7 sampai 6,4 persen). Perubahan gaya hidup dapat mencegahnya menjadi diabetes. Periksa ulang berkala.", "info", 1)
A("Apakah stres setelah stroke bisa menaikkan gula darah?", "gula naik saat sakit kenapa", "kenapa gula darah tidak stabil setelah stroke",
  "Ya, stres fisik akibat penyakit, infeksi, nyeri, perubahan makan, dan obat tertentu dapat menaikkan gula darah. Pantau lebih sering dan beri tahu dokter bila terus tinggi.", "info", 1)
A("Bagaimana gula darah saya?", "gula darah saya terakhir berapa", "apakah gula saya terkendali",
  "Untuk melihat kondisi gula darah Anda, saya merujuk pada data yang tercatat di halaman Risiko Stroke.", "info", 0, "glucose")

# ===================== 7. KOLESTEROL =====================
C("Kolesterol")
A("Apa itu kolesterol LDL, HDL, dan trigliserida?", "bedanya kolesterol jahat dan baik", "ldl hdl trigliserida artinya",
  "LDL disebut kolesterol jahat karena menumpuk di dinding pembuluh darah. HDL disebut kolesterol baik karena membantu membersihkannya. Trigliserida adalah lemak darah lain yang bila tinggi ikut meningkatkan risiko.")
A("Berapa nilai kolesterol yang normal?", "kolesterol total normal berapa", "batas kolesterol yang sehat",
  "Umumnya kolesterol total di bawah 200 mg/dL, LDL di bawah 100 mg/dL (lebih rendah lagi pada pasien stroke), HDL 40 mg/dL atau lebih pada pria dan 50 mg/dL atau lebih pada wanita, dan trigliserida di bawah 150 mg/dL.", "info", 0, "lipid")
A("Apakah statin aman diminum setelah stroke?", "obat kolesterol statin efek sampingnya", "kenapa saya diberi statin setelah stroke",
  "Statin umum diberikan setelah stroke iskemik untuk menurunkan LDL dan risiko stroke berulang. Efek samping yang mungkin adalah nyeri atau lemah otot. Laporkan ke dokter bila terjadi, dan jangan berhenti sendiri.", "waspada", 1)
A("Makanan apa yang membantu menurunkan kolesterol?", "makanan penurun kolesterol", "diet untuk kolesterol tinggi",
  "Perbanyak serat larut (oat, kacang-kacangan, sayur, buah), ikan, dan minyak nabati tak jenuh. Kurangi lemak jenuh dan trans seperti gorengan, jeroan, kulit ayam, santan kental, dan makanan olahan.")
A("Apakah telur boleh dimakan jika kolesterol tinggi?", "boleh makan telur tidak", "kuning telur aman tidak",
  "Telur dapat dimakan dalam jumlah wajar sebagai bagian dari pola makan seimbang, namun batasannya bergantung pada kadar kolesterol dan penyakit penyerta. Tanyakan jumlah yang aman kepada dokter atau ahli gizi.", "info", 1)
A("Apakah harus puasa sebelum cek kolesterol?", "cek lipid perlu puasa tidak", "puasa berapa jam sebelum tes kolesterol",
  "Ikuti instruksi laboratorium. Banyak pemeriksaan lipid kini tidak wajib puasa, namun puasa sering diminta bila trigliserida tinggi atau dicek bersama gula puasa, umumnya sekitar 9 sampai 12 jam, boleh minum air putih.")
A("Bagaimana menurunkan trigliserida yang tinggi?", "trigliserida tinggi harus bagaimana", "makanan yang menaikkan trigliserida",
  "Kurangi gula, minuman manis, alkohol, dan makanan berlemak; turunkan berat badan bila berlebih; perbanyak aktivitas. Bila tetap tinggi, dokter dapat memberikan obat.", "info", 1)
A("Bagaimana cara menaikkan kolesterol HDL?", "hdl rendah bagaimana", "kolesterol baik rendah apa yang harus dilakukan",
  "Berhenti merokok, olahraga teratur, menurunkan berat badan, dan memilih lemak sehat (ikan, kacang, minyak zaitun) dapat membantu. Konsultasikan ke dokter bila tetap rendah.", "info", 1)
A("Seberapa sering kolesterol dicek?", "kapan cek kolesterol ulang", "jadwal cek lipid setelah mulai obat",
  "Setelah memulai atau mengubah obat penurun kolesterol, pengecekan ulang umumnya dilakukan sekitar 4 sampai 12 minggu, lalu berkala sesuai dokter, misalnya setiap 6 sampai 12 bulan bila stabil.", "info", 1)
A("Apakah kolesterol tinggi menimbulkan gejala?", "kolesterol tinggi kerasa tidak", "kenapa saya tidak merasa apa apa padahal kolesterol tinggi",
  "Umumnya tidak ada gejala, sehingga hanya terdeteksi lewat pemeriksaan darah. Karena itu tetap rutin cek meski merasa sehat.")
A("Bagaimana kolesterol saya?", "ldl saya berapa", "apakah kolesterol saya terkendali",
  "Untuk melihat kolesterol Anda, saya merujuk pada data yang tercatat di halaman Risiko Stroke.", "info", 0, "lipid")

# ===================== 8. POLA MAKAN & GIZI =====================
C("Pola Makan & Gizi")
A("Bagaimana pola makan yang baik untuk penderita stroke?", "diet untuk pasien stroke", "menu makan sehat setelah stroke",
  "Prinsipnya gizi seimbang: banyak sayur dan buah, biji-bijian utuh, protein tanpa lemak (ikan, tempe, tahu, ayam tanpa kulit), kacang-kacangan; batasi garam, gula, lemak jenuh, gorengan, dan makanan olahan. Pedoman Isi Piringku Kemenkes dapat menjadi acuan porsi.")
A("Makanan apa yang harus dihindari penderita stroke?", "pantangan makanan stroke", "makanan yang tidak boleh dimakan pasien stroke",
  "Batasi atau hindari: makanan asin (ikan asin, mi instan, makanan kaleng), gorengan, jeroan, lemak daging, santan kental berlebih, minuman manis, dan alkohol. Bukan berarti dilarang total, tetapi dibatasi porsi dan frekuensinya.")
A("Apakah penderita stroke boleh makan daging?", "daging merah aman untuk stroke tidak", "boleh makan ayam dan sapi",
  "Boleh dalam jumlah terbatas. Pilih daging tanpa lemak dan olahan tanpa digoreng; batasi daging merah dan olahan seperti sosis dan kornet. Ikan, tempe, dan tahu adalah pilihan protein yang baik.")
A("Apakah ikan baik untuk penderita stroke?", "ikan apa yang bagus untuk stroke", "berapa kali makan ikan seminggu",
  "Ya. Ikan, terutama yang berlemak sehat seperti salmon, makerel, sarden, atau tongkol, baik untuk jantung dan pembuluh darah. Umumnya dianjurkan sekitar 2 kali seminggu, dipanggang, dikukus, atau direbus.")
A("Bolehkah minum kopi atau teh?", "kopi aman untuk penderita stroke", "teh dan kopi tidak boleh ya",
  "Kopi dan teh dalam jumlah sedang umumnya aman, tetapi kafein dapat menaikkan tekanan darah sementara. Batasi bila tensi tinggi atau jantung berdebar, dan hindari tambahan gula berlebih.")
A("Bagaimana pola makan bagi pasien yang sulit menelan?", "makanan untuk pasien disfagia", "pasien stroke tersedak saat makan harus bagaimana",
  "Pasien sulit menelan perlu dinilai terapis wicara atau dokter untuk menentukan tekstur makanan dan minuman yang aman. Selama itu, dudukkan tegak 90 derajat, beri suapan kecil, dan tunggu pasien menelan sempurna sebelum suapan berikutnya.", "waspada", 1)
A("Berapa banyak air yang perlu diminum?", "minum air putih sehari berapa gelas", "pasien stroke perlu banyak minum air",
  "Cukup minum sepanjang hari, umumnya sekitar 6 sampai 8 gelas, kecuali dokter membatasi cairan karena penyakit jantung atau ginjal. Pada pasien yang sulit menelan, jenis cairan perlu disesuaikan.")
A("Bagaimana mengurangi garam tanpa membuat makanan hambar?", "tips masak rendah garam", "pengganti garam yang aman",
  "Gunakan bumbu alami seperti bawang, jahe, serai, daun salam, jeruk nipis, dan lada. Kurangi kecap, saus, dan penyedap. Hindari garam pengganti berbasis kalium bila ada penyakit ginjal atau obat tertentu, kecuali dokter mengizinkan.")
A("Bolehkah makan santan?", "makanan bersantan boleh tidak", "gulai dan rendang aman tidak",
  "Santan tinggi lemak jenuh, jadi dibatasi dan tidak dimakan sering. Pilih porsi kecil, santan encer, dan perbanyak sayur. Bila kolesterol atau LDL tinggi, batasi lebih ketat.")
A("Buah dan sayur apa yang baik untuk stroke?", "sayur apa yang bagus untuk pembuluh darah", "buah untuk penderita stroke",
  "Semua sayur dan buah berwarna baik, terutama sayur hijau, tomat, wortel, jeruk, apel, pisang, dan beri. Perhatikan porsi buah manis bila gula darah tinggi, dan konsultasikan asupan kalium bila ada penyakit ginjal atau obat tertentu.")
A("Bagaimana menu sehari-hari yang seimbang?", "contoh menu pasien stroke", "isi piringku itu apa",
  "Isi Piringku: sekitar setengah piring sayur dan buah, setengah lainnya karbohidrat dan protein, dengan lauk tanpa digoreng dan sedikit minyak. Contoh: nasi porsi sedang, ikan panggang, tempe, sayur bening, dan potongan buah.")
A("Apakah penderita stroke perlu protein lebih banyak?", "protein untuk pemulihan otot", "makan apa agar otot kuat kembali",
  "Protein cukup membantu pemulihan otot selama rehabilitasi, tetapi jumlahnya individual dan perlu disesuaikan bila ada penyakit ginjal. Sumber baik: ikan, telur secukupnya, tempe, tahu, kacang-kacangan, dan ayam tanpa kulit.", "info", 1)
A("Bolehkah berpuasa bagi penyintas stroke?", "puasa ramadan setelah stroke", "pasien stroke boleh puasa tidak",
  "Tergantung kondisi. Bicarakan dengan dokter sebelum berpuasa karena jadwal dan jenis obat, gula darah, tekanan darah, dan risiko dehidrasi perlu disesuaikan. Jangan melewatkan obat tanpa petunjuk dokter.", "waspada", 1)
A("Bagaimana makan di luar rumah dengan aman?", "makan di restoran untuk pasien stroke", "tips memilih makanan saat acara keluarga",
  "Pilih makanan dikukus, direbus, atau dipanggang, minta saus dan garam dipisah, batasi gorengan dan makanan bersantan, dan pilih air putih daripada minuman manis. Tetap makan sesuai jadwal obat.")

# ===================== 9. OBAT & KEPATUHAN =====================
C("Obat & Kepatuhan")
A("Obat apa saja yang biasa diberikan setelah stroke?", "jenis obat untuk pasien stroke", "kenapa obat saya banyak sekali",
  "Secara umum: obat tekanan darah, obat pencegah penggumpalan darah (antiplatelet atau antikoagulan), obat penurun kolesterol (statin), serta obat diabetes bila perlu. Jenis dan dosis ditentukan dokter sesuai penyebab stroke dan penyakit penyerta. Saya tidak dapat menentukan obat untuk Anda.", "info", 1)
A("Bagaimana jika lupa minum obat?", "kelewatan minum obat harus bagaimana", "apakah boleh minum dua kali kalau lupa",
  "Jangan menggandakan dosis tanpa petunjuk. Aturan tiap obat berbeda, jadi tanyakan kepada apoteker atau dokter apa yang harus dilakukan, dan bacalah petunjuk pada kemasan. Pasang alarm agar tidak terlewat lagi.", "info", 1)
A("Apa efek samping obat tekanan darah?", "obat hipertensi bikin batuk", "obat tensi bikin pusing normal tidak",
  "Efek yang mungkin: pusing, lemas, kaki bengkak, atau batuk kering pada kelompok obat tertentu. Laporkan ke dokter, jangan berhenti sendiri, karena sering cukup dengan penggantian atau penyesuaian dosis.", "info", 1)
A("Apa bahaya obat pengencer darah?", "obat antikoagulan efek sampingnya", "tanda perdarahan akibat obat pengencer",
  "Obat ini meningkatkan risiko perdarahan. Waspadai tinja hitam atau berdarah, muntah darah, mimisan lama, gusi berdarah, memar luas, dan sakit kepala hebat. Segera hubungi dokter atau ke IGD bila muncul, dan jangan berhenti sendiri.", "waspada", 1)
A("Bolehkah minum jamu atau herbal bersama obat dokter?", "jamu dan obat dokter aman tidak", "suplemen herbal dengan obat stroke",
  "Sebagian herbal dan suplemen dapat berinteraksi dengan obat pengencer darah, tekanan darah, atau gula darah. Sampaikan semuanya ke dokter atau apoteker sebelum dipakai.", "waspada", 1)
A("Bolehkah minum obat nyeri seperti ibuprofen?", "obat pereda nyeri aman untuk pasien stroke", "obat anti nyeri dan tekanan darah",
  "Obat antinyeri golongan NSAID seperti ibuprofen dapat menaikkan tekanan darah dan risiko perdarahan, apalagi bersama obat pengencer darah. Tanyakan dokter atau apoteker obat nyeri yang aman untuk Anda.", "waspada", 1)
A("Apakah obat stroke harus diminum seumur hidup?", "kapan obat boleh dihentikan", "lama minum obat setelah stroke",
  "Banyak obat pencegah stroke diminum jangka panjang, bahkan seumur hidup, namun itu keputusan dokter berdasarkan penyebab stroke dan kondisi Anda. Jangan menghentikan sendiri meski merasa sehat.", "info", 1)
A("Bagaimana cara agar tidak lupa minum obat?", "tips disiplin minum obat", "bagaimana mengingatkan orang tua minum obat",
  "Pakai kotak obat harian, pasang alarm, kaitkan dengan kebiasaan (misalnya setelah sarapan), catat dalam kalender, dan minta keluarga membantu mengingatkan. Aplikasi ini bisa dipakai untuk mencatat rutinitas.")
A("Apakah aspirin boleh diberikan saat gejala stroke muncul?", "kasih aspirin dulu kalau ada gejala stroke", "obat apa yang diberikan sebelum ke rumah sakit",
  "Jangan. Sebelum CT scan, belum diketahui apakah stroke karena sumbatan atau perdarahan, dan aspirin bisa memperburuk perdarahan. Langsung bawa ke IGD tanpa memberi obat apa pun.", "darurat", 1)
A("Apakah obat antikoagulan perlu cek darah rutin?", "inr itu apa", "warfarin perlu cek apa",
  "Tergantung jenisnya. Warfarin memerlukan pemeriksaan INR berkala untuk mengatur dosis, sedangkan beberapa antikoagulan baru umumnya tidak. Ikuti jadwal yang diberikan dokter Anda.", "info", 1)
A("Bagaimana menyimpan obat dengan benar?", "tempat menyimpan obat di rumah", "obat kadaluarsa apa harus dibuang",
  "Simpan di tempat sejuk, kering, terhindar dari sinar matahari, dan jauh dari jangkauan anak. Periksa tanggal kedaluwarsa, jangan memindahkan obat ke wadah tanpa label, dan tanyakan apoteker cara membuang obat kedaluwarsa.")
A("Pasien menolak minum obat, bagaimana?", "ayah tidak mau minum obat", "ibu bosan minum obat terus",
  "Dengarkan alasannya (takut efek samping, bosan, lupa, biaya, merasa sudah sehat), lalu sampaikan ke dokter. Sering ada solusi seperti penyederhanaan jadwal atau penggantian obat. Jangan memaksa atau menyembunyikan obat di makanan tanpa sepengetahuan dokter.", "info", 1)

# ===================== 10. REHABILITASI =====================
C("Rehabilitasi & Latihan")
A("Kapan rehabilitasi stroke dimulai?", "kapan boleh mulai latihan setelah stroke", "rehabilitasi dimulai berapa hari setelah stroke",
  "Rehabilitasi dimulai sedini mungkin setelah kondisi pasien stabil menurut dokter, sering sejak di rumah sakit. Latihan dini dan konsisten memberi peluang pemulihan lebih baik.", "info", 1)
A("Berapa kali seminggu sebaiknya latihan?", "frekuensi latihan rehabilitasi", "target latihan per minggu",
  "Target bawaan aplikasi adalah 5 hari per minggu per pasien; sesuaikan dengan kemampuan dan arahan fisioterapis Anda. Lebih baik sering dan singkat daripada jarang tetapi terlalu berat.", "info", 0, "progress")
A("Apa itu ROM atau rentang gerak sendi?", "range of motion artinya apa", "arti sudut siku dan bahu di aplikasi",
  "ROM adalah seberapa jauh sendi dapat digerakkan, dinyatakan dalam derajat. Aplikasi mengukur sudut siku dan bahu dari kamera. Nilai normal acuan yang dipakai: siku sekitar 145 derajat dan bahu sekitar 180 derajat.")
A("Apakah latihan di rumah aman?", "boleh latihan sendiri di rumah", "perlu didampingi saat latihan tidak",
  "Aman bila sesuai izin dokter atau fisioterapis, dilakukan duduk di kursi bersandaran, dengan pendamping terutama pada awal. Hentikan bila ada nyeri tajam, pusing, sesak, nyeri dada, atau bengkak.", "info", 1)
A("Kapan latihan harus dihentikan?", "tanda harus berhenti olahraga", "latihan boleh diteruskan kalau pusing tidak",
  "Hentikan bila ada nyeri tajam, pusing berat, sesak napas, nyeri dada, jantung berdebar tidak wajar, pandangan gelap, bengkak mendadak, atau lemah yang memburuk. Istirahat dan hubungi tenaga kesehatan; bila gejala stroke baru muncul, segera ke IGD.", "waspada", 1)
A("Apakah tangan yang lemah bisa pulih dengan latihan?", "cara melatih tangan lumpuh", "latihan untuk tangan kaku setelah stroke",
  "Latihan yang berulang, terarah pada tugas nyata, dan bertahap dapat membantu otak membentuk jalur baru sehingga fungsi tangan membaik. Hasilnya berbeda tiap orang, dan latihan sebaiknya diarahkan fisioterapis atau terapis okupasi.")
A("Apa itu neuroplastisitas?", "otak bisa memperbaiki diri tidak", "kenapa latihan berulang membantu pemulihan",
  "Neuroplastisitas adalah kemampuan otak membentuk ulang hubungan antar sel saraf. Latihan yang berulang dan bermakna memperkuat jalur baru sehingga bagian otak yang sehat dapat mengambil alih sebagian fungsi.")
A("Apakah harus melatih sisi yang lemah saja?", "latihan sisi sehat perlu tidak", "tangan kanan lemah apakah tangan kiri juga dilatih",
  "Fokus utama pada sisi yang lemah, namun sisi yang sehat tetap dijaga kebugarannya dan dipakai sebagai penopang yang aman. Jangan memaksa sisi yang lemah melewati batas nyeri.")
A("Mengapa kemajuan latihan saya mendatar atau tidak naik?", "progress latihan stuck", "kenapa tidak ada peningkatan rom",
  "Mendatar (plateau) wajar terjadi. Coba tambah repetisi, naikkan target sedikit, variasikan gerakan, periksa kelelahan, nyeri, atau tidur, dan diskusikan dengan fisioterapis. Kemajuan bisa muncul lagi setelah penyesuaian.", "info", 1, "progress")
A("Berapa lama satu sesi latihan?", "durasi latihan yang pas", "latihan berapa menit sehari",
  "Mulai dari sesi pendek sekitar 15 sampai 30 menit dengan jeda istirahat, lalu tambah bertahap. Kelelahan setelah stroke itu umum, jadi sesuaikan dengan stamina dan arahan fisioterapis.")
A("Bagaimana posisi yang benar saat latihan dengan kamera?", "posisi duduk saat latihan di aplikasi", "jarak kamera saat latihan berapa",
  "Duduk tegak bersandar, bahu rileks, kamera setinggi dada dengan jarak 1,5 sampai 2 meter, cahaya dari depan, dan seluruh tubuh bagian atas terlihat. Pakaian yang kontras dengan latar membantu deteksi.")
A("Apa itu terapi okupasi?", "terapi okupasi untuk apa", "latihan aktivitas sehari hari setelah stroke",
  "Terapi okupasi melatih kemampuan beraktivitas sehari-hari seperti makan, berpakaian, mandi, dan menulis, serta menyesuaikan alat bantu dan lingkungan rumah.")
A("Apa itu terapi wicara?", "terapi wicara untuk afasia", "pasien sulit bicara perlu terapi apa",
  "Terapi wicara membantu latihan bicara, memahami bahasa, dan menelan. Terapis menilai kemampuan, memberi latihan, dan mengajarkan strategi komunikasi kepada keluarga.")
A("Apakah perlu alat bantu jalan?", "tongkat atau walker untuk stroke", "kapan pasien boleh berjalan sendiri",
  "Pilihan alat bantu (tongkat, walker, atau penyangga kaki) ditentukan fisioterapis setelah menilai keseimbangan dan kekuatan. Jangan berjalan sendiri sebelum dinilai aman, karena risiko jatuh tinggi.", "info", 1)
A("Apakah pijat membantu pemulihan stroke?", "boleh dipijat setelah stroke", "urut tradisional untuk tangan lumpuh aman tidak",
  "Pijat lembut dapat membantu rileks, tetapi urut keras atau menarik sendi yang lemah berisiko menimbulkan cedera bahu dan nyeri. Tanyakan fisioterapis cara yang aman, dan bila ada riwayat pembekuan darah, bicarakan dulu dengan dokter.", "waspada", 1)
A("Bagaimana mencegah sendi menjadi kaku (kontraktur)?", "agar tangan tidak mengkerut", "cegah kaku sendi pada pasien stroke",
  "Gerakkan sendi sisi lemah secara teratur dan lembut sesuai ajaran fisioterapis, atur posisi tidur dan duduk agar sendi tidak tertekuk lama, dan lakukan peregangan harian.", "info", 1)
A("Apakah pendamping boleh menarik lengan pasien yang lemah?", "cara membantu berdiri tanpa menarik tangan", "menarik tangan pasien bahaya tidak",
  "Jangan menarik lengan yang lemah karena bahu bisa bergeser dan nyeri. Bantu dengan menopang badan, memegang di bawah ketiak atau pinggang, dan minta fisioterapis mengajarkan teknik memindahkan pasien.", "waspada", 1)
A("Bagaimana mengatasi kelelahan saat berlatih?", "cepat capek saat latihan", "kelelahan pasca stroke normal tidak",
  "Kelelahan pasca stroke sangat umum. Bagi latihan menjadi sesi pendek, istirahat cukup, jaga tidur dan makan, dan latih pada jam tubuh terasa paling bugar. Bila kelelahan tiba-tiba memburuk, hubungi dokter.", "info", 1)
A("Apa itu rehab game di aplikasi ini?", "game rehabilitasi untuk apa", "mengapa latihan dibuat seperti permainan",
  "Rehab Game mengubah gerakan latihan (misalnya menjangkau bintang) menjadi permainan dengan level dan skor agar latihan lebih menyenangkan dan konsisten. Gerakannya tetap diukur oleh kamera.")

# ===================== 11. KOMPLIKASI PASCA STROKE =====================
C("Komplikasi Pasca Stroke")
A("Mengapa bahu terasa nyeri setelah stroke?", "nyeri bahu pada sisi yang lemah", "bahu sakit saat digerakkan setelah stroke",
  "Otot yang lemah membuat sendi bahu kurang tertopang sehingga mudah bergeser atau meradang, dan otot yang kaku bisa menarik sendi. Topang lengan pada bantal, jangan menarik lengan, hindari gerakan memaksa, dan konsultasikan ke fisioterapis atau dokter.", "waspada", 1)
A("Apa itu spastisitas atau otot kaku setelah stroke?", "kenapa otot kaku dan tegang", "tangan menggenggam terus dan sulit dibuka",
  "Spastisitas adalah otot yang kaku dan menegang berlebihan akibat gangguan sinyal saraf. Peregangan teratur, posisi yang baik, dan latihan dari fisioterapis dapat membantu; dokter dapat menambahkan obat atau terapi lain bila mengganggu.", "info", 1)
A("Bagaimana mengenali gangguan menelan?", "tanda disfagia", "kenapa batuk setiap kali minum",
  "Tandanya: batuk atau tersedak saat makan atau minum, suara basah setelah menelan, makanan tertahan di mulut, makan sangat lama, atau demam berulang. Gangguan ini dapat menyebabkan radang paru aspirasi, jadi perlu dinilai dokter atau terapis wicara.", "waspada", 1)
A("Bagaimana mencegah jatuh pada pasien stroke?", "pencegahan jatuh di rumah", "agar pasien tidak jatuh saat berjalan",
  "Pastikan lantai kering dan tidak licin, pencahayaan cukup, singkirkan karpet atau kabel, pasang pegangan di kamar mandi dan dekat toilet, gunakan alas kaki anti-selip, dan dampingi saat berdiri atau berjalan sampai fisioterapis menyatakan aman.", "info", 1)
A("Bagaimana mencegah luka tekan (dekubitus)?", "luka di punggung pasien yang berbaring lama", "cara merawat kulit pasien yang hanya berbaring",
  "Ubah posisi minimal setiap 2 jam, jaga kulit bersih dan kering, gunakan alas yang lembut, periksa area tulang menonjol (punggung bawah, tumit, pinggul), dan segera hubungi tenaga kesehatan bila kulit memerah menetap atau terluka.", "info", 1)
A("Apakah penurunan daya ingat normal setelah stroke?", "pasien jadi pelupa setelah stroke", "kenapa konsentrasi menurun setelah stroke",
  "Gangguan memori, perhatian, dan perencanaan cukup sering terjadi. Bantu dengan rutinitas tetap, catatan atau alarm, instruksi sederhana satu per satu, dan lingkungan yang tenang. Evaluasi dokter dapat menentukan terapi kognitif.", "info", 1)
A("Apakah kejang bisa terjadi setelah stroke?", "kejang pasca stroke", "pasien kejang beberapa bulan setelah stroke",
  "Bisa terjadi pada sebagian pasien. Kejang yang pertama kali atau berlangsung lama adalah darurat. Segera ke IGD, lalu konsultasikan dengan dokter saraf untuk evaluasi dan terapi.", "darurat", 1)
A("Bagaimana mengatasi sulit menahan buang air kecil?", "inkontinensia setelah stroke", "pasien stroke ngompol",
  "Gangguan ini umum dan sering membaik. Atur jadwal ke toilet (misalnya tiap 2 sampai 3 jam), batasi minum berlebih menjelang tidur, dan konsultasikan ke dokter untuk mencari penyebab seperti infeksi saluran kemih.", "info", 1)
A("Bengkak satu kaki atau tangan setelah stroke, apakah berbahaya?", "kaki bengkak sebelah dan nyeri", "tanda bekuan darah di kaki",
  "Bengkak satu tungkai disertai nyeri, hangat, atau kemerahan dapat menandakan bekuan darah (trombosis vena dalam) yang berbahaya. Segera periksa ke dokter atau IGD. Bengkak ringan pada sisi lemah sering karena kurang gerak, tetapi tetap laporkan.", "waspada", 1)
A("Bagaimana mengatasi gangguan tidur setelah stroke?", "susah tidur pasien stroke", "tidur tidak nyenyak setelah stroke",
  "Jaga jadwal tidur tetap, kurangi kafein sore hari, batasi tidur siang yang panjang, ciptakan kamar tenang dan nyaman. Jika mendengkur keras, sering terbangun, atau sangat mengantuk di siang hari, bicarakan dengan dokter untuk menyingkirkan henti napas saat tidur.", "info", 1)
A("Apa itu gangguan penglihatan separuh lapang pandang?", "tidak melihat sisi kanan atau kiri setelah stroke", "hemianopia itu apa",
  "Hemianopia adalah hilangnya penglihatan pada separuh lapang pandang di kedua mata akibat kerusakan jalur penglihatan otak. Pasien sering menabrak benda di satu sisi. Latih menoleh ke sisi itu dan periksakan ke dokter mata atau dokter saraf.", "info", 1)
A("Bolehkah mengemudi setelah stroke?", "kapan boleh menyetir lagi", "pasien stroke boleh bawa motor",
  "Jangan mengemudi sampai dokter menilai bahwa penglihatan, reaksi, kekuatan, dan konsentrasi Anda aman. Menyetir terlalu cepat berisiko bagi diri sendiri dan orang lain.", "waspada", 1)
A("Kapan penyintas stroke boleh kembali bekerja?", "kapan bisa bekerja lagi", "kembali ke kantor setelah stroke",
  "Bergantung pada jenis pekerjaan dan pemulihan. Umumnya dilakukan bertahap setelah dinilai dokter dan terapis okupasi, misalnya dengan jam kerja lebih pendek dan tugas yang disesuaikan.", "info", 1)
A("Apa itu foot drop atau kaki jatuh?", "ujung kaki terseret saat berjalan", "kenapa kaki tersandung terus",
  "Foot drop adalah kesulitan mengangkat ujung kaki sehingga kaki terseret dan mudah tersandung akibat otot pergelangan kaki yang lemah. Fisioterapis dapat memberi latihan dan penyangga kaki (ortosis) untuk mencegah jatuh.", "info", 1)

# ===================== 12. EMOSI & KESEHATAN JIWA =====================
C("Emosi & Kesehatan Jiwa")
A("Apakah depresi setelah stroke itu normal?", "kenapa saya sedih terus setelah stroke", "pasien stroke jadi murung apakah wajar",
  "Depresi cukup sering terjadi setelah stroke dan bukan tanda kelemahan. Penyebabnya gabungan perubahan otak dan beban emosional. Kondisi ini dapat diobati, jadi sampaikan ke dokter atau psikolog.", "waspada", 1)
A("Apa tanda depresi pasca stroke?", "ciri ciri depresi pada pasien stroke", "pasien tidak mau makan dan tidak semangat",
  "Sedih berkepanjangan, hilang minat, mudah menangis, tidur terlalu banyak atau sulit tidur, nafsu makan berubah, merasa tidak berguna, dan menolak latihan. Jika berlangsung lebih dari dua minggu atau mengganggu, segera konsultasikan ke dokter.", "waspada", 1)
A("Mengapa pasien stroke mudah menangis atau tertawa tanpa sebab?", "emosi tidak terkendali setelah stroke", "menangis tiba tiba tanpa alasan",
  "Kerusakan otak dapat menyebabkan emosi sulit dikendalikan, menangis atau tertawa berlebihan tidak sesuai perasaan. Kondisi ini bukan dibuat-buat. Beri pengertian, tetap tenang, dan konsultasikan ke dokter karena ada terapi yang dapat membantu.", "info", 1)
A("Saya takut terkena stroke lagi, apa yang harus dilakukan?", "cemas setelah stroke", "khawatir berlebihan stroke kambuh",
  "Rasa takut itu wajar. Cara membantu: pahami tanda stroke dan rencana darurat, patuhi pengobatan, pantau tekanan darah, latihan napas atau relaksasi, dan berbagi dengan keluarga atau kelompok penyintas. Jika kecemasan mengganggu tidur atau aktivitas, bicarakan dengan dokter.", "info", 1)
A("Bagaimana menghadapi pasien yang mudah marah?", "ayah jadi gampang marah setelah stroke", "pasien stroke mudah tersinggung",
  "Perubahan emosi dapat akibat kerusakan otak, frustrasi, atau nyeri. Tetap tenang, beri waktu dan pilihan sederhana, hindari berdebat, dan hargai usahanya. Bila perilaku makin berat, hubungi dokter.", "info", 1)
A("Saya merasa putus asa dan ingin menyerah, apa yang bisa dilakukan?", "saya merasa tidak berguna lagi", "capek dengan kondisi ini",
  "Perasaan itu berat, dan Anda tidak perlu menanggungnya sendirian. Ceritakan kepada keluarga atau orang yang dipercaya hari ini, dan hubungi dokter atau psikolog; bantuan untuk kondisi ini tersedia. Jika muncul keinginan menyakiti diri, segera hubungi 112 atau ke IGD terdekat.", "waspada", 1)
A("Bagaimana menjaga motivasi untuk terus berlatih?", "malas latihan rehabilitasi", "tips agar semangat latihan",
  "Tetapkan target kecil yang realistis, catat kemajuan (grafik progress di aplikasi), berlatih pada jam yang sama, ajak keluarga menemani, rayakan pencapaian, dan coba Rehab Game. Kemajuan sering lambat, tetapi tetap berarti.")
A("Apakah ada kelompok dukungan untuk penyintas stroke?", "komunitas stroke", "teman senasib untuk pasien stroke",
  "Banyak rumah sakit dan komunitas menyelenggarakan kelompok dukungan penyintas stroke. Tanyakan ke rumah sakit, puskesmas, atau fisioterapis Anda. Berbagi pengalaman membantu mengurangi rasa sendiri.")
A("Bagaimana berkomunikasi dengan pasien yang mengalami afasia?", "cara bicara dengan pasien afasia", "pasien sulit bicara bagaimana kita menanggapi",
  "Gunakan kalimat pendek dan jelas, bicara pelan tanpa berteriak, beri waktu menjawab, dan jangan memotong. Pakai isyarat, gambar, atau tulisan, ajukan pertanyaan ya atau tidak, dan perlakukan pasien sebagai orang dewasa yang cerdas.")
A("Keluarga merasa lelah merawat pasien, apa yang bisa dilakukan?", "caregiver kelelahan", "capek merawat orang tua yang stroke",
  "Kelelahan perawat itu nyata dan wajar. Bagi tugas dengan anggota keluarga, jadwalkan waktu istirahat, minta bantuan, jaga kesehatan sendiri, dan bicarakan perasaan Anda kepada tenaga kesehatan atau kelompok pendukung.", "info", 0)

# ===================== 13. PERAWATAN DI RUMAH =====================
C("Perawatan di Rumah")
A("Bagaimana menyiapkan rumah untuk pasien stroke?", "modifikasi rumah untuk pasien stroke", "kamar mandi apa yang perlu diubah",
  "Pastikan jalur bebas hambatan, lantai tidak licin, pencahayaan terang, pegangan di kamar mandi dan tangga, kursi mandi, toilet duduk yang cukup tinggi, dan tempat tidur setinggi lutut. Letakkan barang yang sering dipakai di jangkauan.")
A("Bagaimana cara memindahkan pasien dari tempat tidur ke kursi?", "cara memindahkan pasien stroke", "pindah dari kasur ke kursi roda bagaimana",
  "Minta fisioterapis atau perawat mengajarkan teknik yang aman. Prinsipnya: kunci rem kursi roda, dekatkan kursi di sisi yang kuat, minta pasien mendorong dengan sisi kuat, dan topang badan pasien, bukan menarik lengannya.", "info", 1)
A("Bagaimana cara membantu pasien berpakaian?", "tips berpakaian pasien stroke", "baju mana yang dipakai duluan",
  "Pakaikan lengan atau kaki sisi lemah terlebih dahulu, lalu sisi yang kuat; saat melepas, lakukan sebaliknya. Pilih pakaian longgar dengan kancing besar atau velcro, dan beri waktu agar pasien mencoba sendiri.")
A("Bagaimana posisi tidur dan duduk yang baik?", "posisi tidur pasien stroke", "bagaimana menopang lengan yang lemah",
  "Ubah posisi secara berkala, topang lengan yang lemah di atas bantal agar bahu tidak tertarik, jaga punggung tegak saat duduk, dan jangan membiarkan kaki terkulai. Fisioterapis dapat menunjukkan posisi yang paling sesuai.", "info", 1)
A("Bagaimana cara menyuapi pasien dengan aman?", "cara makan aman untuk pasien stroke", "pasien disuapi harus bagaimana",
  "Dudukkan tegak, jangan menyuapi sambil berbaring, beri suapan kecil, tunggu hingga pasien menelan, dan tetap tegak sekitar 30 menit setelah makan. Hentikan dan hubungi dokter bila sering batuk atau tersedak.", "waspada", 1)
A("Mengapa kebersihan mulut penting pada pasien stroke?", "perawatan gigi dan mulut pasien stroke", "sikat gigi pasien yang berbaring",
  "Mulut yang kotor meningkatkan kuman yang dapat terhirup dan menyebabkan radang paru, terutama pada pasien sulit menelan. Bantu menyikat gigi dua kali sehari dengan posisi duduk tegak atau kepala dimiringkan.")
A("Apa yang perlu dicatat keluarga setiap hari?", "catatan harian pasien stroke", "apa saja yang perlu dilaporkan ke dokter",
  "Catat tekanan darah, gula darah (bila diperiksa), obat yang diminum, makan dan minum, tidur, nyeri, gejala baru, dan latihan. Bawa catatan saat kontrol. Anda juga dapat memasukkan data kesehatan di halaman Risiko Stroke.")
A("Bagaimana menghubungkan akun keluarga dengan pasien?", "daftar akun pendamping", "keluarga bisa melihat data pasien bagaimana",
  "Saat mendaftar, pilih peran keluarga lalu masukkan email akun pasien yang sudah terdaftar. Setelah terhubung, keluarga dapat melihat progress, riwayat, galeri, dan mengisi data kesehatan pasien.")
A("Bagaimana menyusun jadwal harian pasien?", "contoh jadwal harian pasien stroke", "kapan waktu latihan dan istirahat",
  "Susun jadwal teratur: minum obat dan ukur tekanan darah pagi, sarapan, latihan sesi pendek, istirahat, makan siang, latihan kedua bila mampu, aktivitas ringan, makan malam, obat dan tensi malam, lalu tidur tepat waktu. Sesuaikan dengan arahan dokter.")

# ===================== 14. GAYA HIDUP =====================
C("Gaya Hidup")
A("Bagaimana cara berhenti merokok setelah stroke?", "tips berhenti merokok", "saya sulit berhenti merokok",
  "Tetapkan tanggal berhenti, buang rokok dan korek, hindari pemicu, minta dukungan keluarga, dan tanyakan dokter atau puskesmas tentang konseling dan terapi pengganti nikotin. Berhenti merokok menurunkan risiko stroke berulang secara bermakna.", "info", 1)
A("Berapa lama tidur yang dianjurkan?", "tidur yang cukup untuk pemulihan", "jam tidur pasien stroke",
  "Umumnya orang dewasa membutuhkan sekitar 7 sampai 8 jam tidur per malam. Tidur yang cukup membantu pemulihan dan mengendalikan tekanan darah. Jaga jam tidur tetap dan konsultasikan bila sulit tidur terus-menerus.")
A("Berapa berat badan ideal?", "cara menghitung imt", "imt berapa dikatakan gemuk",
  "IMT = berat badan (kg) dibagi tinggi (m) dikuadratkan. Menurut kriteria Asia-Pasifik: 18,5 sampai 22,9 normal, 23 sampai 24,9 berat badan lebih, 25 atau lebih obesitas. Tinggi dan berat badan dapat diisi di halaman Risiko Stroke untuk dihitung otomatis.")
A("Bagaimana mengelola stres setelah stroke?", "cara mengurangi stres", "relaksasi untuk pasien stroke",
  "Lakukan napas dalam pelan, ibadah atau meditasi, mendengarkan musik, berbincang dengan keluarga, aktivitas ringan yang disukai, dan jadwal yang teratur. Bila stres atau cemas mengganggu, konsultasikan ke dokter atau psikolog.")
A("Apakah boleh bepergian atau naik pesawat setelah stroke?", "traveling setelah stroke", "perjalanan jauh aman tidak",
  "Bergantung kondisi dan waktu sejak stroke, jadi tanyakan dokter terlebih dahulu. Selama perjalanan, bawa obat dan catatan medis, sering bergerak atau meregangkan kaki, minum cukup, dan jangan melewatkan obat.", "info", 1)
A("Berapa batas aman alkohol?", "boleh minum sedikit alkohol", "alkohol sesekali aman tidak",
  "Bagi penyintas stroke, pilihan paling aman adalah tidak minum alkohol. Alkohol dapat menaikkan tekanan darah, mengganggu obat, dan meningkatkan risiko jatuh. Bila ingin minum, tanyakan dokter terlebih dahulu.", "info", 1)
A("Apakah asap rokok orang lain berbahaya?", "perokok pasif dan stroke", "keluarga merokok di dalam rumah",
  "Ya. Asap rokok orang lain merusak pembuluh darah dan menaikkan risiko stroke. Rumah sebaiknya bebas asap rokok, dan keluarga yang merokok sebaiknya mulai berhenti.")
A("Bagaimana aktivitas fisik harian yang aman?", "jalan kaki aman untuk pasien stroke", "aktivitas ringan apa yang boleh dilakukan",
  "Aktivitas ringan seperti berjalan santai bila sudah diizinkan, bersepeda statis, peregangan, atau berkebun ringan dapat membantu. Mulai pelan, tambah bertahap, dan ikuti batas yang diberikan fisioterapis.", "info", 1)

# ===================== 15. PEMERIKSAAN & KONTROL =====================
C("Pemeriksaan & Kontrol")
A("Apa fungsi CT scan dan MRI otak?", "kenapa perlu ct scan", "bedanya ct scan dan mri pada stroke",
  "CT scan cepat dan membedakan stroke perdarahan dari sumbatan, sehingga biasanya dilakukan pertama kali. MRI lebih detail untuk melihat area kerusakan, terutama yang kecil. Dokter memilih sesuai kondisi.", "info", 1)
A("Mengapa perlu pemeriksaan EKG atau pemantauan jantung?", "ekg untuk stroke buat apa", "kenapa jantung diperiksa setelah stroke",
  "Beberapa stroke berasal dari jantung, misalnya akibat fibrilasi atrium. EKG atau pemantauan irama jantung lebih lama membantu mendeteksi gangguan irama sehingga pengobatan pencegahan dapat disesuaikan.", "info", 1)
A("Pemeriksaan laboratorium apa yang biasa dilakukan?", "tes darah apa saja setelah stroke", "cek lab untuk pasien stroke",
  "Umumnya gula darah dan HbA1c, profil lemak (kolesterol), fungsi ginjal dan elektrolit, darah lengkap, dan bila perlu pemeriksaan pembekuan darah. Dokter menentukan sesuai kondisi Anda.", "info", 1)
A("Apa itu USG Doppler karotis atau ekokardiografi?", "pemeriksaan pembuluh darah leher", "echo jantung untuk stroke",
  "Doppler karotis menilai penyempitan pembuluh darah leher yang mengalirkan darah ke otak. Ekokardiografi (USG jantung) menilai struktur dan fungsi jantung serta mencari kemungkinan sumber bekuan darah.", "info", 1)
A("Apa yang perlu dibawa saat kontrol ke dokter?", "persiapan kontrol stroke", "dokumen apa untuk kontrol",
  "Bawa semua obat atau daftar obat, catatan tekanan darah dan gula darah, hasil laboratorium atau pemeriksaan terakhir, dan daftar pertanyaan atau keluhan. Anda dapat mencetak atau menunjukkan grafik tren dari aplikasi.")
A("Bagaimana persiapan sebelum tes darah puasa?", "puasa sebelum cek gula dan kolesterol", "boleh minum obat saat puasa tes",
  "Puasa sekitar 8 sampai 12 jam, hanya boleh minum air putih. Tanyakan ke dokter atau laboratorium apakah obat pagi boleh diminum sebelum pengambilan darah, terutama obat diabetes.", "info", 1)

# ===================== 16. PENGGUNAAN APLIKASI =====================
C("Penggunaan Aplikasi")
A("Apa itu NeuroKinetix?", "aplikasi ini untuk apa", "fungsi sistem neurokinetix",
  "NeuroKinetix adalah alat bantu rehabilitasi pascastroke. Kamera dan MediaPipe BlazePose 3D membaca posisi sendi untuk menghitung sudut siku dan bahu, memberi koreksi postur, memperkirakan skor Fugl-Meyer, dan menyajikan progress untuk pasien, keluarga, dan fisioterapis. Ini alat bantu, bukan alat diagnosis.")
A("Bagaimana cara kerja deteksi gerakan?", "bagaimana aplikasi mengukur sudut", "teknologi apa yang dipakai kamera",
  "MediaPipe Pose (BlazePose) mendeteksi titik-titik tubuh dari gambar kamera, lalu sudut siku dan bahu dihitung dari posisi 3D titik tersebut di browser. Hasilnya dipakai untuk menghitung repetisi, akurasi postur, dan kompensasi.")
A("Apakah aplikasi ini bisa mendiagnosis stroke?", "bisa deteksi stroke dari kamera tidak", "apakah hasilnya pengganti dokter",
  "Tidak. Aplikasi hanya mengukur gerak sendi dan menghitung skor skrining risiko dari data yang Anda isi. Diagnosis stroke memerlukan pemeriksaan dokter dan CT scan atau MRI.", "info", 1)
A("Seberapa akurat pengukuran sudut dari kamera?", "apakah sudutnya sama dengan goniometer", "akurasi mediapipe di aplikasi",
  "Akurasi belum terbukti. Target selisih 3,5 derajat atau kurang terhadap goniometer harus dibuktikan lewat halaman Validasi dengan data subjek nyata. Sampai saat itu, anggap angka sebagai perkiraan dan bandingkan dengan penilaian fisioterapis.")
A("Bagaimana posisi kamera dan pencahayaan yang baik?", "jarak kamera aplikasi latihan", "kamera setinggi apa",
  "Kamera setinggi dada, jarak 1,5 sampai 2 meter, cahaya dari depan (bukan membelakangi jendela), seluruh tubuh bagian atas terlihat, dan latar belakang tidak ramai. Pakaian yang kontras dengan latar membantu deteksi.")
A("Kamera tidak menyala, apa yang harus dilakukan?", "izin kamera ditolak", "kenapa halaman latihan tidak bisa membuka kamera",
  "Izinkan akses kamera pada browser, pastikan membuka lewat localhost atau HTTPS, tutup aplikasi lain yang memakai kamera, lalu muat ulang halaman. Aplikasi juga memerlukan internet untuk memuat model MediaPipe.")
A("Apakah video dan foto saya disimpan?", "privasi kamera di aplikasi", "siapa yang bisa melihat foto latihan",
  "Pemrosesan pose berlangsung di browser dan aplikasi tidak merekam video terus-menerus. Foto hanya masuk ke galeri saat Anda menekan tombol ambil atau simpan foto, dan dapat dilihat oleh pasien, keluarga yang terhubung, dan fisioterapis.")
A("Apa itu estimasi skor Fugl-Meyer (FMA-UE)?", "arti skor fma di aplikasi", "fma 52 dari 66 artinya apa",
  "FMA-UE motorik adalah skala 0 sampai 66 untuk menilai fungsi lengan setelah stroke. Di aplikasi, skor diperkirakan dari rentang gerak kamera (heuristik 25 dan 75 persen ROM normal), bukan skor klinis resmi. Penilaian resmi tetap dilakukan fisioterapis.", "info", 1, "fma")
A("Bagaimana skor FMA saya?", "estimasi fma saya berapa", "fugl meyer saya sekarang",
  "Untuk melihat skor FMA Anda, saya merujuk pada data aplikasi.", "info", 0, "fma")
A("Apa itu skor risiko stroke di aplikasi ini?", "arti skor risiko 0 sampai 100", "bagaimana skor risiko dihitung",
  "Skor 0 sampai 100 adalah jumlah poin dari 12 faktor risiko (tekanan darah, gula darah, kolesterol, fibrilasi atrium, merokok, IMT, usia, kepatuhan obat, aktivitas, dan lainnya). Bobotnya heuristik tim dan belum divalidasi klinis, jadi hasilnya skrining, bukan diagnosis atau persentase peluang.", "info", 1, "risk")
A("Mengapa skor risiko saya tinggi?", "apa penyebab skor risiko tinggi", "faktor apa yang paling menaikkan skor saya",
  "Buka halaman Risiko Stroke dan lihat tabel Faktor risiko: kolom Poin menunjukkan kontribusi tiap faktor. Faktor dengan status tinggi dan poin terbesar, misalnya tekanan darah, gula darah, atau fibrilasi atrium, adalah prioritas pengendalian bersama dokter.", "info", 1, "risk")
A("Bagaimana menurunkan skor risiko?", "cara memperbaiki skor risiko stroke", "apa yang harus dilakukan agar risiko turun",
  "Kendalikan faktor yang bisa diubah: capai target tekanan darah, gula darah, dan kolesterol, minum obat teratur, berhenti merokok, aktif bergerak, dan jaga berat badan. Perbarui data pengukuran secara berkala agar skor mencerminkan kondisi terbaru.", "info", 1, "risk")
A("Seberapa sering saya harus memasukkan data kesehatan?", "kapan input tekanan darah ke aplikasi", "berapa kali isi data risiko",
  "Tekanan darah dan nadi sebaiknya rutin (misalnya sesuai anjuran dokter, bisa harian atau mingguan). Gula darah dan berat badan sesuai jadwal pemeriksaan, sedangkan HbA1c dan kolesterol biasanya setiap beberapa bulan sesuai hasil laboratorium.")
A("Apa itu kepatuhan latihan di aplikasi?", "arti kepatuhan persen", "bagaimana kepatuhan dihitung",
  "Kepatuhan adalah persentase hari latihan dalam 7 hari terakhir dibandingkan target hari per minggu yang ditetapkan fisioterapis. Misalnya berlatih 4 hari dari target 5 hari berarti 80 persen.", "info", 0, "progress")
A("Apa itu streak latihan?", "streak itu apa", "kenapa streak saya putus",
  "Streak adalah jumlah hari berturut-turut Anda berlatih. Streak putus bila ada satu hari tanpa latihan. Tidak apa-apa, mulai lagi hari ini.")
A("Apa itu gerak kompensasi?", "kompensasi di aplikasi artinya apa", "kenapa badan miring dihitung kompensasi",
  "Gerak kompensasi adalah gerakan 'curang' yang dilakukan tubuh agar tampak berhasil, misalnya badan miring atau bahu terangkat saat mengangkat lengan. Ini mengurangi manfaat latihan, jadi aplikasi memberi koreksi.")
A("Apa itu akurasi postur?", "akurasi postur persen artinya apa", "bagaimana skor akurasi dihitung",
  "Akurasi postur menunjukkan seberapa baik gerakan Anda sesuai bentuk yang benar (misalnya badan tegak dan bahu sejajar) selama latihan. Semakin tinggi semakin baik, dan nilai rendah biasanya berarti perlu memperlambat gerakan.")
A("Siapa yang dapat melihat data saya?", "keamanan data pasien", "fisioterapis bisa lihat riwayat saya tidak",
  "Pasien melihat datanya sendiri, keluarga yang terhubung melihat data pasien terkait, dan fisioterapis melihat data pasien yang dipantau. Data tersimpan di basis data aplikasi; gunakan kata sandi yang kuat dan HTTPS saat dipakai nyata.")
A("Apakah aplikasi bisa dipakai tanpa internet?", "perlu koneksi internet tidak", "offline bisa digunakan",
  "Perlu internet untuk memuat model MediaPipe, Chart.js, dan font dari CDN. Tanpa internet, deteksi gerakan dan grafik tidak dapat bekerja dengan normal.")
A("Apa itu analisis foto?", "fungsi menu analisis foto", "cara memakai analisis foto postur",
  "Halaman Analisis Foto menampilkan penanda anatomi, panjang segmen lengan, serta sudut fleksi siku dan elevasi bahu kanan-kiri dari satu foto, dengan skala dari tinggi badan yang Anda isi. Gunakan foto tubuh bagian atas yang jelas dan pencahayaan baik; hasilnya perkiraan, belum divalidasi goniometer.")
A("Apa itu AI Coach dan apakah bisa salah?", "ai coach itu apa", "seberapa bisa dipercaya jawaban ai",
  "AI Coach memberi analisis tren latihan dan menjawab pertanyaan dari kumpulan jawaban edukasi yang sudah disusun, bukan dari pemeriksaan medis. Jawabannya bisa kurang tepat untuk kondisi khusus, jadi gunakan sebagai panduan umum dan konfirmasikan ke dokter atau fisioterapis.", "info", 1)
A("Mengapa sudut siku terbaca saat tangan terlihat lurus?", "siku lurus tapi aplikasi bilang 26 derajat", "pengukuran sudut kok tidak nol",
  "Perkiraan 3D dari kamera 2D memiliki galat, apalagi pada pose atau sudut kamera tertentu. Hal ini yang menjadi alasan hasil perlu divalidasi dengan goniometer. Gunakan angka sebagai tren antar-sesi, bukan nilai mutlak.")
