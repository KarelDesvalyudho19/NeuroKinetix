"""Modul kalkulasi biomekanika: pemetaan ROM -> skor Fugl-Meyer (FMA-UE) dan AI Coach berbasis aturan.
CATATAN: pemetaan FMA bersifat heuristik; harus dikalibrasi dengan penilaian klinis sebelum dipakai klinis."""
NORMAL = {"elbow": 145.0, "sh_flex": 180.0, "sh_abd": 180.0}

def item_score(rom, normal):
    r = (rom or 0) / normal
    return 2 if r >= .75 else 1 if r >= .25 else 0      # 0=tidak bisa, 1=parsial, 2=penuh (skala FMA)

def estimate_fma(elbow, sh_flex, sh_abd):
    s = item_score(elbow, NORMAL["elbow"]) + item_score(sh_flex, NORMAL["sh_flex"]) + item_score(sh_abd, NORMAL["sh_abd"])
    return round(s / 6 * 66, 1)                          # skala FMA-UE motorik maks 66

def slope(y):
    n = len(y)
    if n < 2: return 0.0
    mx, my = (n - 1) / 2, sum(y) / n
    den = sum((i - mx) ** 2 for i in range(n))
    return sum((i - mx) * (v - my) for i, v in enumerate(y)) / den

def _series(S, key):
    return [s[key] for s in S if s.get(key)][-10:]

def coach(S, tpw, adherence):
    """S: sesi urut naik (lama -> baru)."""
    if len(S) < 3:
        return {"risk": "sedang", "insights": [{"k": "info", "t": "Data belum cukup", "d": "Selesaikan minimal 3 sesi latihan agar AI dapat menganalisis tren."}],
                "plan": {"rom": "-", "reps": 8, "freq": tpw}}
    ins, risk = [], "rendah"
    n = min(5, len(S))
    acc = sum(s["accuracy"] for s in S[-n:]) / n
    comp = sum(s["compensation"] for s in S[-n:]) / n
    if adherence >= 80: ins.append({"k": "ok", "t": "Kepatuhan sangat baik", "d": f"{adherence:.0f}% target latihan minggu ini tercapai."})
    elif adherence >= 50: ins.append({"k": "warn", "t": "Kepatuhan sedang", "d": "Tambah 1-2 hari latihan. Minta keluarga memasang pengingat."})
    else: ins.append({"k": "bad", "t": "Kepatuhan rendah", "d": "Latihan kurang dari separuh target. Fisioterapis perlu dihubungi."}); risk = "tinggi"
    if acc < 70:
        ins.append({"k": "warn", "t": "Postur perlu dikoreksi", "d": f"Akurasi postur rata-rata {acc:.0f}%. Perlambat gerakan dan ikuti koreksi suara."})
        risk = "sedang" if risk == "rendah" else risk
    if comp > 3: ins.append({"k": "warn", "t": "Banyak gerak kompensasi", "d": "Badan miring atau bahu terangkat berulang. Latihan sambil duduk bersandar membantu."})
    best = {}
    for key, name in (("max_elbow", "siku"), ("max_sh_flex", "fleksi bahu"), ("max_sh_abd", "abduksi bahu")):
        v = _series(S, key)
        if len(v) < 3: continue
        sl = slope(v); best[name] = max(v)
        if sl > 1: ins.append({"k": "ok", "t": f"ROM {name} membaik", "d": f"Naik ±{sl:.1f}° per sesi (terbaik {max(v):.0f}°)."})
        elif sl < -1.5: ins.append({"k": "bad", "t": f"ROM {name} menurun", "d": "Kemungkinan kelelahan atau nyeri. Istirahat dan konsultasikan ke fisioterapis."}); risk = "tinggi"
        else: ins.append({"k": "info", "t": f"ROM {name} plateau", "d": "Naikkan target 5° atau tambah repetisi."})
    tgt = f"{max(best.values()) + 5:.0f}°" if best else "-"
    return {"risk": risk, "insights": ins, "plan": {"rom": tgt, "reps": 12 if acc >= 70 else 8, "freq": max(tpw, 5) if adherence >= 80 else tpw}}

def ask(question, ctx):
    """Kompatibilitas: jawaban teks dari mesin tanya-jawab dataset (ai/qa_engine.py)."""
    from .qa_engine import answer
    return answer(question, ctx)["answer"]
