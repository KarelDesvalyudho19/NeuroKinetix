const NK={
 col:['#22d3ee','#3b82f6','#a78bfa','#fbbf24'],
 async api(u,o={}){const f=o.body instanceof FormData;const r=await fetch(u,{method:o.method||'GET',headers:f?{}:{'Content-Type':'application/json'},body:o.body&&!f?JSON.stringify(o.body):o.body});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||'Error '+r.status);return j},
 ang3(a,b,c){const u=[a.x-b.x,a.y-b.y,a.z-b.z],v=[c.x-b.x,c.y-b.y,c.z-b.z];const d=u[0]*v[0]+u[1]*v[1]+u[2]*v[2],n=Math.hypot(...u)*Math.hypot(...v);return Math.acos(Math.max(-1,Math.min(1,d/(n||1))))*180/Math.PI},
 d:s=>new Date(s.replace(' ','T')+'Z').toLocaleDateString('id-ID',{day:'2-digit',month:'short'}),
 dt:s=>new Date(s.replace(' ','T')+'Z').toLocaleString('id-ID',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}),
 ds(label,data,i){return{label,data:data.map(v=>v||null),borderColor:NK.col[i],backgroundColor:NK.col[i]+'33',tension:.3,spanGaps:true,pointRadius:3}},
 chart(id,type,labels,sets,opt={}){const t={ticks:{color:'#8fa8cc'},grid:{color:'#16305f'}};return new Chart(document.getElementById(id),{type,data:{labels,datasets:sets},options:{responsive:true,plugins:{legend:{labels:{color:'#8fa8cc'}}},scales:{x:t,y:t},...opt}})},
 exName:{elbow:'Fleksi–ekstensi siku',shflex:'Fleksi bahu',shabd:'Abduksi bahu',game:'Game'}
};
document.querySelectorAll('.nav nav a').forEach(a=>{if(a.pathname===location.pathname)a.classList.add('on')});
