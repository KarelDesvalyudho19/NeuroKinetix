/* NKPose: BlazePose 3D (MediaPipe Pose) -> sudut kinematika sendi real-time + koreksi postur */
class NKPose{
 constructor(o){Object.assign(this,{side:'right',alpha:.4},o);this.a={elbow:0,elev:0,shFlex:0,shAbd:0,tilt:0,hike:0,vis:0};this.max={elbow:0,shFlex:0,shAbd:0};this.frames=0;this.good=0;this.comp=0;this.inComp=false;this.fb=[]}
 async start(){
  const v=this.video;this.stream=await navigator.mediaDevices.getUserMedia({video:{width:640,height:480,facingMode:'user'},audio:false});
  v.srcObject=this.stream;await v.play();this.c=this.canvas;if(!this.fixed){this.c.width=v.videoWidth||640;this.c.height=v.videoHeight||480}this.ctx=this.c.getContext('2d');
  this.pose=new Pose({locateFile:f=>`https://cdn.jsdelivr.net/npm/@mediapipe/pose@0.5.1675469404/${f}`});
  this.pose.setOptions({modelComplexity:1,smoothLandmarks:true,minDetectionConfidence:.5,minTrackingConfidence:.5});
  this.pose.onResults(r=>this.onRes(r));this.running=true;
  const loop=async()=>{if(!this.running)return;if(v.readyState>=2)await this.pose.send({image:v});requestAnimationFrame(loop)};loop();
 }
 stop(){this.running=false;this.stream&&this.stream.getTracks().forEach(t=>t.stop())}
 onRes(r){
  const x=this.ctx,w=this.c.width,h=this.c.height;
  x.save();x.scale(-1,1);x.drawImage(r.image,-w,0,w,h);x.restore();            // tampilan cermin
  if(r.poseLandmarks&&r.poseWorldLandmarks){this.calc(r.poseLandmarks,r.poseWorldLandmarks);if(!this.noDraw)this.draw(r.poseLandmarks,w,h)}
  else this.fb=['Tampakkan tubuh bagian atas di depan kamera'];
  this.onDraw&&this.onDraw(x,w,h,this);this.onUpdate&&this.onUpdate(this);
 }
 calc(L,W){
  const [S,E,Wr,H,S2]=this.side==='right'?[12,14,16,24,11]:[11,13,15,23,12],p=i=>W[i],a=this.a,al=this.frames?this.alpha:1;
  const set=(k,v)=>a[k]+=(v-a[k])*al;
  const elbow=180-NK.ang3(p(S),p(E),p(Wr));                                  // fleksi siku (0° = lurus)
  const elev=NK.ang3(p(H),p(S),p(E));                                        // elevasi lengan terhadap batang tubuh
  const sag=Math.abs(p(E).z-p(S).z)>Math.abs(p(E).x-p(S).x);                 // bidang sagital -> fleksi; frontal -> abduksi
  set('elbow',elbow);set('elev',elev);set('shFlex',sag?elev:0);set('shAbd',sag?0:elev);
  const dd=(i,j)=>Math.hypot(p(i).x-p(j).x,p(i).y-p(j).y,p(i).z-p(j).z)*100;this.len={ua:dd(S,E),fa:dd(E,Wr)};
  a.vis=Math.min(L[S].visibility,L[E].visibility,L[Wr].visibility);
  const t=Math.abs(Math.atan2(L[11].y-L[12].y,L[11].x-L[12].x)*180/Math.PI);a.tilt=Math.min(t,180-t);
  a.hike=L[S2].y-L[S].y;
  const m=this.max;m.elbow=Math.max(m.elbow,a.elbow);m.shFlex=Math.max(m.shFlex,a.shFlex);m.shAbd=Math.max(m.shAbd,a.shAbd);
  const fb=[];if(a.vis<.5)fb.push('Tampakkan seluruh lengan ke kamera');
  const comp=a.tilt>10||a.hike>.05;if(a.tilt>10)fb.push('Badan miring, tegakkan punggung');if(a.hike>.05)fb.push('Bahu terangkat, turunkan bahu');
  if(comp&&!this.inComp)this.comp++;this.inComp=comp;this.fb=fb;this.L=L;this.S=S;this.E=E;this.Wr=Wr;this.H=H;this.S2=S2;
  if(a.vis>=.5){this.frames++;if(!fb.length)this.good++}
 }
 draw(L,w,h){
  const x=this.ctx,P=i=>[w-L[i].x*w,L[i].y*h],bad=this.inComp;x.lineWidth=4;x.lineCap='round';
  const ln=(i,j,c)=>{x.strokeStyle=c;x.beginPath();x.moveTo(...P(i));x.lineTo(...P(j));x.stroke()};
  ln(this.S,this.E,'#2dd4bf');ln(this.E,this.Wr,'#8b5cf6');ln(this.S,this.H,bad?'#f43f5e':'#9fb3c8');ln(11,12,bad?'#f43f5e':'#9fb3c8');
  [this.S,this.E,this.Wr].forEach(i=>{x.fillStyle='#fff';x.beginPath();x.arc(...P(i),6,0,7);x.fill()});
  x.fillStyle='#fff';x.font='bold 18px sans-serif';const [ex,ey]=P(this.E);x.fillText(Math.round(this.a.elbow)+'°',ex+10,ey);
  const [sx,sy]=P(this.S);x.fillText(Math.round(this.a.elev)+'°',sx+10,sy-10);
 }
 snapshot(){return new Promise(r=>this.c.toBlob(r,'image/jpeg',.9))}
 rec(){this.chunks=[];this.mr=new MediaRecorder(this.c.captureStream(24),{mimeType:'video/webm'});this.mr.ondataavailable=e=>e.data.size&&this.chunks.push(e.data);this.mr.start()}
 stopRec(){return new Promise(r=>{if(!this.mr||this.mr.state==='inactive')return r(null);this.mr.onstop=()=>r(new Blob(this.chunks,{type:'video/webm'}));this.mr.stop()})}
}
