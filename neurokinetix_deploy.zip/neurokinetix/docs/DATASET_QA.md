# Dataset tanya-jawab AI Coach (v5)

**Isi:** 220 pertanyaan utama di 16 kategori, masing-masing dengan 2 variasi kalimat (total 660 bentuk pertanyaan), jawaban edukasi, tingkat urgensi (info/waspada/darurat), penanda perlu-dokter, dan penanda personalisasi data pasien (32 entri menambahkan baris "Data Anda: ..." dari tensi, gula darah, kolesterol, skor risiko, kepatuhan, atau FMA).
**File:** `ai/dataset_src.py` (sumber, diedit tim) → `python tools/build_dataset.py` → `ai/dataset_qa.json` (dipakai aplikasi). Excel lengkap: `docs/Dataset_QA_NeuroKinetix.xlsx` (dibuat oleh `python tools/build_excel.py`).

## Cara kerja (`ai/qa_engine.py`)
Tanpa LLM dan tanpa pustaka tambahan. Urutan: (1) deteksi kalimat krisis jiwa → respons dukungan + arahan 112/IGD; (2) deteksi gejala darurat mendadak (mencong, pelo, lemah separuh badan, kejang, nyeri dada, dll.) → arahan 112/IGD; (3) pertanyaan tentang data sendiri ("tensi saya bagaimana") → jawaban dari data pasien; (4) pencarian dataset memakai TF-IDF unigram+bigram, kemiripan n-gram karakter, pemetaan sinonim sehari-hari, dan koreksi typo ringan; (5) bila skor rendah → 3 saran pertanyaan. Skor ≥0,50 dijawab langsung, 0,33–0,50 dijawab dengan penanda "jawaban terdekat", <0,33 ditolak dan ditawarkan saran.

## Hasil uji (`python tools/eval_qa.py`)
| Set uji | Jumlah | Benar | Catatan |
|---|---|---|---|
| Dev | 73 | 70 (95,9%) | Dipakai menyetel mesin, **terlalu optimis** |
| Hold-out 1 | 65 | 57 (87,7%) | Dipakai untuk perbaikan kedua |
| **Hold-out 2** | 68 | **53 (77,9%)** | Ditulis setelah penyetelan; pencarian dataset 43/58 (74,1%); jawaban benar muncul di jawaban atau 3 saran pada 52/58 (89,7%); keselamatan/data pribadi/di luar topik 10/10 |

Angka yang paling realistis untuk pertanyaan baru adalah **±75–78%**. Hold-out 2 pun tidak murni, karena setelah evaluasi dipakai memperbaiki deteksi krisis ("lebih baik saya mati saja" semula tidak terdeteksi) dan mengetatkan koreksi kata. Kegagalan umumnya karena pencocokan leksikal: paraphrase yang jauh dari kosakata dataset gagal ("lab yang diperiksa rutin"). Cara menaikkan akurasi: tambah variasi dari pertanyaan nyata pengguna (log), atau ganti retrieval dengan model embedding bahasa Indonesia.

## Batasan wajib dicantumkan
1. Jawaban ditulis tim sebagai edukasi umum dan **belum ditinjau dokter/fisioterapis**. Tinjau sebelum dipakai nyata.
2. Rujukan di Excel hanya nama pedoman umum (AHA/ASA, PERKENI, PERHI, PERKI, PERDOSSI, Kemenkes, WHO). Buka sumber asli dan cantumkan edisi/tahun.
3. Tanpa dosis atau resep obat; keputusan terapi diarahkan ke dokter.
4. Bukan diagnosis. Deteksi gejala darurat berbasis pola kata, bukan pemeriksaan klinis, dan dapat melewatkan kalimat yang tidak umum.
5. Set uji ditulis oleh pembuat dataset (bukan pasien nyata), sehingga akurasi di lapangan bisa berbeda.
