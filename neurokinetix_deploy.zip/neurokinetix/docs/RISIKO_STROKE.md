# Skrining risiko stroke berulang (modul `ai/stroke_risk.py`)

**Tujuan:** pasien sistem ini sudah pernah stroke, sehingga yang dinilai adalah *potensi stroke berulang* dari data kesehatan beberapa bulan terakhir.

## Cara kerja
Skor 0-100 = jumlah poin 12 faktor risiko. Nilai pengukuran memakai data **terbaru** (tekanan darah: rata-rata 3 pengukuran terakhir). Kategori: 0-24 rendah · 25-49 sedang · 50-74 tinggi · 75-100 sangat tinggi. "Berpotensi stroke berulang?" = **Ya** bila tinggi/sangat tinggi, **Waspada** bila sedang, **Tidak menonjol** bila rendah. Tanda bahaya (mis. tensi ≥180/120, gula darah <70 atau >300) otomatis menaikkan kategori minimal ke "tinggi".

| Faktor (maks poin) | Ambang dan poin |
|---|---|
| Tekanan darah (25) | <120/80: 0 · 120-129: 4 · 130-139 atau 80-89: 12 · ≥140 atau ≥90: 19 · ≥160 atau ≥100: 25 |
| Gula darah (18) | Ambil poin tertinggi dari HbA1c (<5,7: 0 · 5,7-6,4: 5 · 6,5-6,9: 9 · 7-7,9: 12 · 8-8,9: 15 · ≥9: 18), GDP (<100: 0 · 100-125: 5 · 126-139: 9 · 140-179: 12 · 180-249: 15 · ≥250: 18), GDS (<140: 0 · 140-199: 5 · ≥200: 12 · ≥300: 18) |
| Kolesterol (14) | LDL stroke iskemik: <70: 0 · 70-99: 4 · 100-129: 7 · 130-159: 9 · ≥160: 10 (stroke hemoragik memakai ambang 100/130/160/190). Tanpa LDL dipakai kolesterol total (<200: 0 · 200-239: 5 · ≥240: 9). HDL rendah (<40 pria, <50 wanita) +2, trigliserida ≥150 +2 |
| Fibrilasi atrium (12) | Ya tanpa antikoagulan: 12 · dengan antikoagulan: 6 |
| Merokok (8) | Aktif: 8 · mantan: 2 |
| IMT (5) | Kriteria Asia-Pasifik: <23: 0 · 23-24,9: 1 · 25-29,9: 3 · ≥30: 5 |
| Usia (5) | <55: 0 · 55-64: 2 · 65-74: 4 · ≥75: 5 |
| Kepatuhan obat (4) | Kadang lupa: 2 · jarang: 4 |
| Aktivitas fisik (3) | Sedang: 1 · jarang: 3 |
| Riwayat keluarga (2), alkohol berat (2), stroke/TIA sebelumnya (2) | Masing-masing 2 bila ada |

Selain skor, sistem menghitung **tren** (kemiringan regresi per bulan untuk sistolik, GDP, LDL; tren HbA1c), **persentase pengukuran yang mencapai target <130/80**, **variabilitas tekanan darah**, dan memberi tanda bila nadi dicatat tidak teratur padahal belum terdiagnosis fibrilasi atrium.

## Rujukan ambang (untuk daftar pustaka esai)
Ambang mengacu pada pedoman umum: AHA/ASA pencegahan stroke sekunder (target tekanan darah <130/80, LDL <70 mg/dL pada stroke iskemik), kategori tekanan darah AHA/ACC 2017, kriteria diagnosis diabetes PERKENI/ADA (GDP ≥126, HbA1c ≥6,5%), dan kategori IMT Asia-Pasifik WHO. **Tim wajib membuka sumber aslinya dan mencantumkan edisi/tahun yang dipakai**; jangan mengutip tanpa memeriksa ulang.

## Batasan (wajib dicantumkan di esai)
1. **Bobot poin adalah heuristik tim, bukan model prediksi tervalidasi.** Ambang berasal dari pedoman, tetapi penjumlahan poin dan bobot antar-faktor belum diuji terhadap kejadian stroke berulang sebenarnya.
2. Hasil adalah skrining edukasi, bukan diagnosis; keputusan terapi ada pada dokter.
3. Akurasi bergantung pada kebenaran data yang diinput manual (alat ukur rumahan, waktu pengukuran, puasa/tidak).
4. Data demo 6 bulan dibuat otomatis untuk peragaan, **bukan data pasien nyata**.
5. Faktor yang belum dimodelkan: penyakit ginjal, apnea tidur, stenosis karotis, obat spesifik, riwayat perdarahan, stres/depresi.

## Usulan validasi (bila waktu mengizinkan)
Bandingkan kategori skor dengan penilaian dokter saraf pada 20-30 kasus (tabel kesepakatan, Cohen's kappa), atau dengan skor baku yang sudah divalidasi untuk stroke berulang (mis. Essen Stroke Risk Score), lalu sesuaikan bobot.
