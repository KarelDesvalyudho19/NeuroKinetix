# Bukti uji awal MediaPipe Pose (BlazePose 3D)

**Apa yang diuji:** halaman `/analisis` (Analisis Foto) menjalankan MediaPipe Pose 0.5.1675469404 di Chromium (WebGL2) pada satu foto uji pose T.
**Hasil nyata:** 15 titik anatomi terdeteksi (visibility 98–100%), waktu inferensi ±10,8 detik termasuk memuat model di Chromium headless tanpa GPU (di perangkat nyata jauh lebih cepat).

| Parameter | Kanan subjek | Kiri subjek |
|---|---|---|
| Fleksi siku (3D) | 26,2° | 31,1° |
| Elevasi bahu (3D) | 80,6° | 79,1° |
| Panjang lengan atas | 21,6 cm | 20,6 cm |
| Panjang lengan bawah | 24,3 cm | 24,5 cm |

**Batasan (wajib dicantumkan di esai):**
1. Foto uji bukan anggota tim dan berasal dari tangkapan layar aplikasi lain, sehingga ada penanda warna dan teks yang tertanam di gambar.
2. Belum ada pembanding goniometer. Pada pose T lengan tampak hampir lurus, namun siku terukur 26–31°. Artinya target deviasi ≤3,5° **belum terbukti** dan perlu validasi di laboratorium (halaman `/validasi`).
3. Uji kamera live (`/latihan`) dengan orang belum dilakukan; hanya inisialisasi kamera dan MediaPipe yang terverifikasi.

**Protokol uji pada anggota tim (±10 menit):** buka `/analisis` di laptop/ponsel → ambil foto frontal pose T dan siku 90° → tangkap layar halaman → ukur sudut yang sama dengan goniometer → catat pasangan data di `/validasi`. Gunakan tangkapan layar itu sebagai Figure 7 asli.

**Usulan keterangan gambar:** "Figure 7. Uji awal MediaPipe Pose di browser: deteksi 15 titik anatomi dan estimasi sudut sendi dari satu foto uji. Belum divalidasi terhadap goniometer."
