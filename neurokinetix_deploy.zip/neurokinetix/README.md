# NeuroKinetix
Telerehabilitasi pascastrok: BlazePose 3D (MediaPipe) → sudut siku/bahu real-time → estimasi Fugl-Meyer (FMA-UE) → dasbor fisioterapis.

**Stack:** HTML/CSS/JavaScript · MediaPipe Pose · Chart.js · Python Flask · SQLite

## Menjalankan
```
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py        # buka http://localhost:5000
```
Kamera hanya bisa dipakai di `localhost` atau HTTPS. Butuh internet untuk memuat model MediaPipe, Chart.js, dan font dari CDN.
Akun demo (sandi `demo123`): pasien@demo.id, keluarga@demo.id, fisio@demo.id. Hapus `neurokinetix.db` untuk reset.

## 16 halaman
/ · /tentang · /auth · /dashboard · /latihan · /game · /progress · /riwayat · /fma · /ai · /galeri · /fisio · /fisio/pasien/<id> · /validasi · /keluarga · /risiko

## Struktur
app.py (API + routing) · schema.sql (9 tabel) · ai/biomechanics.py (FMA mapping + AI Coach) · ai/stroke_risk.py (skor risiko stroke berulang) · ai/qa_engine.py + ai/dataset_qa.json (AI Coach tanya-jawab) · tools/ (pembuat dataset, evaluasi, Excel) · static/js/pose.js (kalkulasi sudut) · templates/

## Catatan penting
- Pemetaan ROM→FMA (ambang 25%/75% ROM normal) adalah heuristik; kalibrasi dengan data klinis/goniometer di lab kampus.
- Target deviasi ≤3,5° harus dibuktikan lewat halaman Validasi dengan data subjek sehat.
- Ganti `SECRET_KEY` dan gunakan HTTPS saat deploy. Ini alat bantu, bukan alat diagnosis.

## Tampilan (v2)
Tema biru neon dengan sidebar. Halaman utama: Dasbor (banner, KPI, streak), Deteksi Gerakan (gauge siku/bahu, avatar 3D yang mengikuti sudut, confidence, titik anatomi, pengukuran langsung, REC), Rehab Game (karakter menjangkau bintang, level, nyawa, timer), Therapist Dashboard (KPI, tren ROM, daftar pasien).
Akun demo tambahan: budi@demo.id, siti@demo.id, harun@demo.id (sandi demo123).

## Analisis Foto (v3)
`/analisis`: unggah/ambil foto → 15 penanda anatomi + sudut 3D siku/bahu kanan-kiri + kalibrasi tinggi badan. Lihat `docs/BUKTI_UJI_AWAL.md`.

## Skrining Risiko Stroke Berulang (v4)
`/risiko`: input data kesehatan per tanggal (tensi, nadi, gula darah puasa/sewaktu, HbA1c, kolesterol total/LDL/HDL/trigliserida, berat badan) + profil faktor risiko (jenis stroke, fibrilasi atrium, merokok, aktivitas, kepatuhan obat, dll). Sistem menghitung skor 0-100, kategori (rendah/sedang/tinggi/sangat tinggi), jawaban "berpotensi stroke berulang atau tidak", analisis tren beberapa bulan, peringatan tanda bahaya, dan saran. Pasien, keluarga, dan fisioterapis dapat mengisi; fisioterapis melihat kolom risiko di Therapist Dashboard. AI Coach juga menjawab pertanyaan soal tensi/gula/kolesterol.
Data demo 6 bulan otomatis dibuat untuk 4 akun pasien demo (profil risiko berbeda). Rincian bobot dan batasan: `docs/RISIKO_STROKE.md`.
**Penting:** bobot skor adalah heuristik tim, belum divalidasi klinis. Ini skrining, bukan diagnosis.

## AI Coach tanya-jawab kesehatan (v5)
Pasien/keluarga dapat bertanya tentang stroke dan kesehatan terkait (tanda darurat, tensi, gula darah, kolesterol, makanan, obat, latihan, komplikasi, emosi, perawatan di rumah, cara memakai aplikasi). Dasarnya dataset 220 pertanyaan (660 bentuk kalimat) di 16 kategori; halaman AI Coach menampilkan saran pertanyaan yang bisa diklik dan penjelajah semua pertanyaan. Pertanyaan tentang data sendiri ("Bagaimana tekanan darah saya?") dijawab dari data pasien. Gejala darurat mendadak dan kalimat krisis jiwa mendapat respons khusus (112/IGD).
Akurasi pada pertanyaan baru sekitar 75-78% (lihat `docs/DATASET_QA.md` dan sheet *Uji Akurasi* di Excel). **Jawaban belum ditinjau dokter; tinjau sebelum dipakai nyata.** Excel dataset: `docs/Dataset_QA_NeuroKinetix.xlsx`.
