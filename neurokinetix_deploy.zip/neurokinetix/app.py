import os, sqlite3, json, uuid, csv, io, random
from datetime import datetime, timedelta
from functools import wraps
from markupsafe import Markup
from flask import Flask, g, request, session, redirect, jsonify, render_template, send_from_directory, Response
from werkzeug.security import generate_password_hash, check_password_hash
from ai.biomechanics import estimate_fma, coach
from ai import qa_engine
from ai.stroke_risk import assess

BASE = os.path.dirname(os.path.abspath(__file__))
DB, UP = os.path.join(BASE, "neurokinetix.db"), os.path.join(BASE, "uploads")
os.makedirs(UP, exist_ok=True)
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-neurokinetix-ganti-di-produksi")
app.config["MAX_CONTENT_LENGTH"] = 80 * 1024 * 1024

# ---------- database ----------
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB); g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def _close(e=None):
    d = g.pop("db", None)
    if d: d.close()

def q(sql, a=(), one=False):
    c = db().execute(sql, a); r = c.fetchall(); db().commit()
    return (r[0] if r else None) if one else r

def rows(sql, a=()): return [dict(r) for r in q(sql, a)]

def seed_patient(c, name, email, age, side, tpw, p_early, p_recent, skill, forced=0):
    pid = c.execute("insert into users(name,email,password,role,patient_id,age,affected_side,target_per_week) values(?,?,?,?,?,?,?,?)",
        (name, email, generate_password_hash("demo123"), "pasien", None, age, side, tpw)).lastrowid
    rnd = random.Random(pid * 13); now = datetime.utcnow()
    for off in range(41, -1, -1):
        pr = 1 if off < forced else (p_recent if off < 7 else p_early)
        if rnd.random() > pr: continue
        k = (41 - off) / 41; a = skill * (38 + 62 * k) + rnd.uniform(-5, 5); ex = rnd.choice(["elbow", "shflex", "shabd"])
        e, f, ab = (a + 22, 0, 0) if ex == "elbow" else (0, a + 18, 0) if ex == "shflex" else (0, 0, a + 14)
        acc = min(97, 52 + 38 * k * skill + rnd.uniform(-5, 5)); d = (now - timedelta(days=off)).replace(hour=rnd.randint(0, now.hour) if off == 0 else rnd.randint(6, 22), minute=0, second=0)
        c.execute("insert into sessions(user_id,exercise,side,reps,duration,max_elbow,max_sh_flex,max_sh_abd,accuracy,compensation,score,fma_est,created) values(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (pid, ex, "right", 8 + int(5 * k), rnd.randint(300, 600), e, f, ab, acc, max(0, int(6 - 5 * k * skill)), int(70 + acc / 2 + rnd.randint(0, 12)),
             round(14 + 36 * k * skill + rnd.uniform(-2, 2), 1), d.strftime("%Y-%m-%d %H:%M:%S")))
    return pid

def init_db():
    c = sqlite3.connect(DB); c.executescript(open(os.path.join(BASE, "schema.sql")).read())
    if not c.execute("select 1 from users").fetchone():
        h = generate_password_hash("demo123")
        c.execute("insert into users(name,email,password,role,age,affected_side,target_per_week) values(?,?,?,?,?,?,?)", ("dr. Rina Kusuma, Fisioterapis", "fisio@demo.id", h, "fisio", 34, "-", 5))
        p = seed_patient(c, "Linia Nur Aini", "pasien@demo.id", 52, "kanan", 5, .55, .8, 1.0, forced=6)
        c.execute("insert into users(name,email,password,role,patient_id,age,affected_side) values(?,?,?,?,?,?,?)", ("Rani (anak Linia)", "keluarga@demo.id", h, "keluarga", p, 22, "-"))
        seed_patient(c, "Budi Santoso", "budi@demo.id", 61, "kiri", 5, .6, .7, .9, forced=3)
        seed_patient(c, "Siti Rahma", "siti@demo.id", 57, "kanan", 5, .5, .6, .85, forced=2)
        seed_patient(c, "Harun Pratama", "harun@demo.id", 66, "kanan", 5, .35, 0, .7)
        c.execute("insert into notes(user_id,author_id,text) values(?,?,?)", (p, 1, "Bagus, pertahankan 5 hari/minggu. Fokus luruskan siku saat mengangkat bahu."))
    c.commit(); c.close()

# ---------- data kesehatan demo (6 bulan) ----------
HEALTH_DEMO = {
 "pasien@demo.id": dict(p=dict(sex="P", height=155, stroke_type="iskemik", sd=200, smoking="tidak", af=0, anticoag=0, alcohol="tidak", activity="sedang", family=1, prior=0, med="rutin", dm=1, ht=1),
   sbp=[158, 152, 148, 142, 138, 134], dbp=[96, 94, 92, 90, 88, 86], pulse=[78, 76, 76, 74, 74, 72], gdp=[142, 138, 134, 130, 128, 126], a1c=[7.8, None, 7.4, None, 7.1, None],
   ldl=[138, 126, 118, 110, 104, 98], hdl=[46, 46, 47, 47, 48, 48], tg=[190, 180, 175, 170, 165, 160], chol=[220, 208, 200, 192, 186, 180], wt=[63, 62.5, 62, 61.5, 61, 60.5]),
 "budi@demo.id": dict(p=dict(sex="L", height=165, stroke_type="iskemik", sd=150, smoking="mantan", af=1, anticoag=0, alcohol="ringan", activity="jarang", family=1, prior=1, med="kadang", dm=0, ht=1),
   sbp=[140, 144, 148, 150, 152, 154], dbp=[88, 90, 92, 92, 94, 96], pulse=[88, 90, 92, 90, 94, 96], gdp=[112, 118, 124, 126, 131, 128], a1c=[6.1, None, 6.5, None, 6.6, None],
   ldl=[128, 132, 136, 138, 142, 144], hdl=[38, 38, 37, 38, 38, 37], tg=[180, 190, 200, 205, 210, 215], chol=[210, 214, 220, 224, 228, 230], wt=[74, 75, 75.5, 76, 76.5, 77], irr=[0, 0, 1, 0, 1, 1]),
 "siti@demo.id": dict(p=dict(sex="P", height=158, stroke_type="iskemik", sd=300, smoking="tidak", af=0, anticoag=0, alcohol="tidak", activity="aktif", family=0, prior=0, med="rutin", dm=0, ht=1),
   sbp=[128, 126, 124, 122, 122, 120], dbp=[80, 78, 78, 76, 76, 74], pulse=[72, 72, 70, 70, 68, 70], gdp=[96, 94, 95, 92, 94, 93], a1c=[None] * 6,
   ldl=[92, 86, 80, 76, 72, 68], hdl=[55, 55, 56, 56, 57, 57], tg=[130, 125, 122, 120, 118, 118], chol=[180, 174, 168, 164, 160, 156], wt=[54, 54, 54, 53.5, 54, 54]),
 "harun@demo.id": dict(p=dict(sex="L", height=168, stroke_type="hemoragik", sd=120, smoking="aktif", af=0, anticoag=0, alcohol="tidak", activity="jarang", family=0, prior=0, med="jarang", dm=0, ht=1),
   sbp=[150, 156, 160, 164, 172, 182], dbp=[94, 96, 100, 102, 106, 110], pulse=[82, 84, 84, 86, 88, 90], gdp=[104, 108, 106, 112, 110, 114], a1c=[None] * 6,
   ldl=[None, 118, None, 124, None, 128], hdl=[None, 44, None, 43, None, 42], tg=[None, 150, None, 160, None, 170], chol=[None, 200, None, 208, None, 214], wt=[70, 70, 70.5, 71, 71, 71.5]),
}

def seed_health():
    c = sqlite3.connect(DB)
    if c.execute("select 1 from health_profile limit 1").fetchone(): c.close(); return
    today = datetime.now().date(); offs = [150, 120, 90, 60, 30, 2]
    for email, h in HEALTH_DEMO.items():
        u = c.execute("select id from users where email=?", (email,)).fetchone()
        if not u: continue
        p = h["p"]
        c.execute("insert into health_profile(user_id,sex,height,stroke_type,stroke_date,smoking,af,anticoag,alcohol,activity,family,prior_events,med_adherence,dx_diabetes,dx_hypertension) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (u[0], p["sex"], p["height"], p["stroke_type"], str(today - timedelta(days=p["sd"])), p["smoking"], p["af"], p["anticoag"], p["alcohol"], p["activity"], p["family"], p["prior"], p["med"], p["dm"], p["ht"]))
        for i, o in enumerate(offs):
            c.execute("insert into health_records(user_id,date,sbp,dbp,pulse,irregular,glucose_fasting,hba1c,chol_total,ldl,hdl,tg,weight) values(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (u[0], str(today - timedelta(days=o)), h["sbp"][i], h["dbp"][i], h["pulse"][i], (h.get("irr") or [0] * 6)[i], h["gdp"][i], h["a1c"][i], h["chol"][i], h["ldl"][i], h["hdl"][i], h["tg"][i], h["wt"][i]))
    c.commit(); c.close()

# ---------- auth & navigasi ----------
def cur():
    return q("select * from users where id=?", (session["uid"],), one=True) if "uid" in session else None

def target_pid():
    u = cur()
    if not u: return None
    if u["role"] == "pasien": return u["id"]
    if u["role"] == "keluarga": return u["patient_id"]
    pid = request.args.get("pid", type=int) or (request.view_args or {}).get("pid")
    if pid: return pid
    r = q("select id from users where role='pasien' order by id limit 1", one=True)
    return r["id"] if r else None

def need(*roles):
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            u = cur()
            if not u or (roles and u["role"] not in roles):
                return (jsonify(error="Tidak diizinkan"), 401) if request.path.startswith("/api") else redirect("/auth")
            return f(*a, **k)
        return w
    return deco

NAVS = {None: [("/", "Beranda"), ("/tentang", "Tentang"), ("/auth", "Masuk / Daftar")],
 "pasien": [("/dashboard", "Dasbor"), ("/latihan", "Latihan"), ("/analisis", "Analisis Foto"), ("/game", "Game"), ("/progress", "Progress"), ("/riwayat", "Riwayat"), ("/fma", "FMA"), ("/risiko", "Risiko Stroke"), ("/ai", "AI Coach"), ("/galeri", "Galeri")],
 "keluarga": [("/keluarga", "Pendamping"), ("/risiko", "Risiko Stroke"), ("/progress", "Progress"), ("/riwayat", "Riwayat"), ("/galeri", "Galeri"), ("/ai", "AI Coach")],
 "fisio": [("/fisio", "Pasien"), ("/analisis", "Analisis Foto"), ("/validasi", "Validasi"), ("/tentang", "Tentang")]}

I = {"home": '<path d="M3 11l9-8 9 8M5 10v10h14V10"/>', "cam": '<rect x="3" y="7" width="18" height="13" rx="2"/><circle cx="12" cy="13" r="3.5"/><path d="M8 7l1.5-3h5L16 7"/>',
 "game": '<rect x="2" y="8" width="20" height="10" rx="5"/><path d="M7 11v4M5 13h4"/><circle cx="16" cy="12" r="1"/><circle cx="18" cy="14.5" r="1"/>',
 "chart": '<path d="M3 20h18M7 16v-5M12 16V6M17 16v-8"/>', "hist": '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', "doc": '<path d="M6 3h9l4 4v14H6z"/><path d="M9 12h7M9 16h7"/>',
 "ai": '<rect x="5" y="7" width="14" height="11" rx="3"/><path d="M12 7V3M9 12h.01M15 12h.01"/>', "img": '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 16l5-5 4 4 3-3 6 6"/>',
 "users": '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-4 3-6 7-6s7 2 7 6M17 5a3.5 3.5 0 010 6"/>', "target": '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>',
 "info": '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5h.01"/>', "login": '<path d="M10 17l5-5-5-5M15 12H3M15 4h5v16h-5"/>',
 "heart": '<path d="M12 20s-7-4.500-7-10a4 4 0 017-2.500A4 4 0 0119 10c0 5.500-7 10-7 10z"/><path d="M8 12h2l1.500-2.500 2 4 1.500-1.500h1"/>'}
IC = {"/": "home", "/tentang": "info", "/auth": "login", "/dashboard": "home", "/latihan": "cam", "/game": "game", "/progress": "chart", "/riwayat": "hist", "/fma": "doc", "/ai": "ai", "/galeri": "img", "/fisio": "users", "/validasi": "target", "/analisis": "img", "/keluarga": "users", "/risiko": "heart"}

@app.context_processor
def ctx():
    u = cur()
    return dict(icon=lambda p: Markup(I[IC.get(p, "home")]), user=u, nav=NAVS[u["role"] if u else None], pid=target_pid() if u else None)

# ---------- 16 halaman ----------
PAGES = [("/", "index", None), ("/tentang", "tentang", None), ("/auth", "auth", None),
 ("/dashboard", "dashboard", ("pasien",)), ("/latihan", "latihan", ("pasien",)), ("/game", "game", ("pasien",)),
 ("/progress", "progress", ()), ("/riwayat", "riwayat", ()), ("/fma", "fma", ()), ("/ai", "ai", ()), ("/galeri", "galeri", ()),
 ("/fisio", "fisio", ("fisio",)), ("/fisio/pasien/<int:pid>", "fisio_detail", ("fisio",)),
 ("/validasi", "validasi", ("fisio", "pasien")), ("/analisis", "analisis", ("fisio", "pasien")), ("/keluarga", "keluarga", ("keluarga",)), ("/risiko", "risiko", ())]
for _path, _t, _roles in PAGES:
    def _mk(t):
        def f(**k): return render_template(t + ".html")
        f.__name__ = "page_" + t
        return f
    _f = _mk(_t)
    app.add_url_rule(_path, view_func=need(*_roles)(_f) if _roles is not None else _f)

@app.route("/logout")
def logout():
    session.clear(); return redirect("/")

# ---------- API auth ----------
HOME = {"pasien": "/dashboard", "keluarga": "/keluarga", "fisio": "/fisio"}

@app.post("/api/register")
def register():
    d = request.json or {}
    if not d.get("email") or not d.get("password") or not d.get("name"): return jsonify(error="Nama, email, dan kata sandi wajib diisi"), 400
    if q("select 1 from users where email=?", (d["email"],), one=True): return jsonify(error="Email sudah terdaftar"), 400
    role = d.get("role") if d.get("role") in HOME else "pasien"; link = None
    if role == "keluarga":
        p = q("select id from users where email=? and role='pasien'", (d.get("patient_email", ""),), one=True)
        if not p: return jsonify(error="Email pasien tidak ditemukan"), 400
        link = p["id"]
    c = db().execute("insert into users(name,email,password,role,patient_id,age,affected_side) values(?,?,?,?,?,?,?)",
        (d["name"], d["email"], generate_password_hash(d["password"]), role, link, d.get("age"), d.get("affected_side", "kanan")))
    db().commit(); session["uid"] = c.lastrowid
    return jsonify(next=HOME[role])

@app.post("/api/login")
def login():
    d = request.json or {}
    u = q("select * from users where email=?", (d.get("email", ""),), one=True)
    if not u or not check_password_hash(u["password"], d.get("password", "")): return jsonify(error="Email atau kata sandi salah"), 401
    session["uid"] = u["id"]; return jsonify(next=HOME[u["role"]])

# ---------- API sesi, progress, ringkasan ----------
def parse(s): return datetime.strptime(s, "%Y-%m-%d %H:%M:%S")

def summary(pid):
    u = q("select * from users where id=?", (pid,), one=True)
    if not u: return {}
    S = rows("select * from sessions where user_id=? order by created, id", (pid,))
    wk = {s["created"][:10] for s in S if parse(s["created"]) > datetime.utcnow() - timedelta(days=7)}
    tpw = u["target_per_week"] or 5
    last = S[-1] if S else None
    days_since = (datetime.utcnow() - parse(last["created"])).days if last else 99
    adh = min(100, round(100 * len(wk) / tpw))
    ds = {x["created"][:10] for x in S}; d0 = datetime.utcnow().date(); st = 0
    if str(d0) not in ds: d0 -= timedelta(days=1)
    while str(d0) in ds: st += 1; d0 -= timedelta(days=1)
    rec = S[-10:]
    return dict(streak=st, hours=round(sum(x["duration"] for x in S) / 3600, 1), avg_score=round(sum(x["score"] for x in rec) / len(rec)) if rec else 0,
        id=pid, name=u["name"], age=u["age"], side=u["affected_side"], tpw=tpw, days=len(wk), adherence=adh, total=len(S),
        fma=last["fma_est"] if last else 0, last=last, days_since=days_since,
        alert=("Tidak aktif" if days_since > 4 else "Kepatuhan rendah" if adh < 50 else ""))

@app.get("/api/summary")
@need()
def api_summary():
    pid = target_pid(); s = summary(pid)
    s["notes"] = rows("select n.text,n.created,u.name author from notes n left join users u on u.id=n.author_id where n.user_id=? order by n.created desc limit 5", (pid,))
    return jsonify(s)

@app.post("/api/session")
@need("pasien")
def save_session():
    d = request.json or {}; u = cur(); acc = float(d.get("accuracy", 0)); reps = int(d.get("reps", 0))
    c = db().execute("insert into sessions(user_id,exercise,side,reps,duration,max_elbow,max_sh_flex,max_sh_abd,accuracy,compensation,score) values(?,?,?,?,?,?,?,?,?,?,?)",
        (u["id"], d.get("exercise"), d.get("side"), reps, int(d.get("duration", 0)), d.get("max_elbow", 0), d.get("max_sh_flex", 0), d.get("max_sh_abd", 0),
         acc, int(d.get("compensation", 0)), int(d.get("score") or reps * 10 + acc / 2)))
    m = q("select max(max_elbow) e,max(max_sh_flex) f,max(max_sh_abd) a from sessions where user_id=? and created>=datetime('now','-7 days')", (u["id"],), one=True)
    fma = estimate_fma(m["e"], m["f"], m["a"])
    db().execute("update sessions set fma_est=? where id=?", (fma, c.lastrowid)); db().commit()
    return jsonify(id=c.lastrowid, fma_est=fma)

@app.get("/api/sessions")
@need()
def api_sessions():
    return jsonify(rows("select * from sessions where user_id=? order by created desc, id desc", (target_pid(),)))

@app.get("/api/sessions.csv")
@need()
def sessions_csv():
    S = rows("select * from sessions where user_id=? order by created, id", (target_pid(),))
    o = io.StringIO(); w = csv.writer(o); w.writerow(["tanggal", "latihan", "reps", "siku", "bahu_fleksi", "bahu_abduksi", "akurasi", "kompensasi", "fma_est"])
    for s in S: w.writerow([s["created"], s["exercise"], s["reps"], s["max_elbow"], s["max_sh_flex"], s["max_sh_abd"], s["accuracy"], s["compensation"], s["fma_est"]])
    return Response(o.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=riwayat.csv"})

@app.get("/api/progress")
@need()
def api_progress():
    pid = target_pid(); sm = summary(pid); tpw = sm.get("tpw", 5)
    S = rows("select * from sessions where user_id=? order by created, id", (pid,)); now = datetime.utcnow(); weekly = []
    for i in range(7, -1, -1):
        a, b = now - timedelta(days=7 * (i + 1)), now - timedelta(days=7 * i)
        n = len({x["created"][:10] for x in S if a < parse(x["created"]) <= b})
        weekly.append({"label": b.strftime("%d %b"), "days": n, "pct": min(100, round(100 * n / tpw))})
    return jsonify(sessions=S, weekly=weekly, summary=sm)

# ---------- data kesehatan & risiko stroke ----------
ENUMS = dict(sex=("L", "P"), stroke_type=("iskemik", "hemoragik"), smoking=("tidak", "mantan", "aktif"), alcohol=("tidak", "ringan", "berat"),
             activity=("aktif", "sedang", "jarang"), med_adherence=("rutin", "kadang", "jarang"))
DEFAULTS = dict(sex=None, stroke_type="iskemik", smoking="tidak", alcohol="tidak", activity="sedang", med_adherence="rutin")
FLAGS = ("af", "anticoag", "family", "dx_diabetes", "dx_hypertension")
RANGES = dict(sbp=(60, 300, "Sistolik"), dbp=(30, 200, "Diastolik"), pulse=(30, 220, "Nadi"), glucose_fasting=(30, 600, "Gula puasa"), glucose_random=(30, 800, "Gula sewaktu"),
              hba1c=(3, 18, "HbA1c"), chol_total=(80, 500, "Kolesterol total"), ldl=(20, 400, "LDL"), hdl=(10, 150, "HDL"), tg=(30, 1500, "Trigliserida"), weight=(20, 250, "Berat badan"))

def health_data(pid):
    p = q("select * from health_profile where user_id=?", (pid,), one=True)
    return (dict(p) if p else {}), rows("select * from health_records where user_id=? order by date, id", (pid,))

def risk_for(pid):
    u = q("select age from users where id=?", (pid,), one=True); prof, recs = health_data(pid)
    return assess(prof, recs, u["age"] if u else None)

def num(v):
    if v in (None, ""): return None
    return float(v)

@app.get("/api/health")
@need()
def api_health():
    pid = target_pid(); prof, recs = health_data(pid); u = q("select age from users where id=?", (pid,), one=True)
    return jsonify(profile=prof, records=recs[::-1], age=u["age"] if u else None)

@app.post("/api/health/profile")
@need()
def save_profile():
    d = request.json or {}; pid = target_pid(); v = {}
    for k, opts in ENUMS.items():
        x = d.get(k)
        if x in (None, ""): v[k] = DEFAULTS[k]
        elif x in opts: v[k] = x
        else: return jsonify(error="Nilai tidak valid: %s" % k), 400
    try: h = num(d.get("height"))
    except (TypeError, ValueError): return jsonify(error="Tinggi badan harus berupa angka"), 400
    if h is not None and not 100 <= h <= 230: return jsonify(error="Tinggi badan harus 100–230 cm"), 400
    sd = d.get("stroke_date") or None
    if sd:
        try: datetime.strptime(sd, "%Y-%m-%d")
        except ValueError: return jsonify(error="Format tanggal stroke tidak valid"), 400
    try: pe = max(0, min(5, int(d.get("prior_events") or 0)))
    except (TypeError, ValueError): return jsonify(error="Riwayat stroke/TIA tidak valid"), 400
    v.update(height=h, stroke_date=sd, prior_events=pe, **{k: 1 if d.get(k) else 0 for k in FLAGS})
    cols = list(v); db().execute("insert into health_profile(user_id,%s,updated) values(?,%s,datetime('now')) on conflict(user_id) do update set %s,updated=datetime('now')" %
        (",".join(cols), ",".join("?" * len(cols)), ",".join(c + "=excluded." + c for c in cols)), (pid, *[v[c] for c in cols])); db().commit()
    return jsonify(ok=True)

@app.post("/api/health/record")
@need()
def add_record():
    d = request.json or {}; pid = target_pid(); date = d.get("date") or datetime.now().strftime("%Y-%m-%d")
    try: dt = datetime.strptime(date, "%Y-%m-%d")
    except ValueError: return jsonify(error="Format tanggal tidak valid"), 400
    if dt.date() > datetime.now().date() + timedelta(days=1): return jsonify(error="Tanggal tidak boleh di masa depan"), 400
    v = {}
    for k, (lo, hi, label) in RANGES.items():
        try: x = num(d.get(k))
        except (TypeError, ValueError): return jsonify(error="%s harus berupa angka" % label), 400
        if x is not None and not lo <= x <= hi: return jsonify(error="%s di luar rentang wajar (%g–%g)" % (label, lo, hi)), 400
        v[k] = x
    if (v["sbp"] is None) != (v["dbp"] is None): return jsonify(error="Isi sistolik dan diastolik bersamaan"), 400
    if v["sbp"] is not None and v["sbp"] <= v["dbp"]: return jsonify(error="Sistolik harus lebih besar dari diastolik"), 400
    if all(x is None for x in v.values()): return jsonify(error="Isi minimal satu hasil pengukuran"), 400
    c = db().execute("insert into health_records(user_id,date,%s,irregular,author_id) values(?,?,%s,?,?)" % (",".join(v), ",".join("?" * len(v))),
        (pid, date, *v.values(), 1 if d.get("irregular") else 0, cur()["id"])); db().commit()
    return jsonify(ok=True, id=c.lastrowid)

@app.delete("/api/health/record/<int:rid>")
@need()
def del_record(rid):
    q("delete from health_records where id=? and user_id=?", (rid, target_pid())); return jsonify(ok=True)

@app.get("/api/risk")
@need()
def api_risk():
    pid = target_pid(); r = risk_for(pid); sm = summary(pid)
    if sm: r["insights"].append(dict(k="ok" if sm["adherence"] >= 80 else "info", t="Kepatuhan latihan rehabilitasi",
        d="%d%% target minggu ini. Aktivitas fisik teratur (sesuai izin fisioterapis) ikut menurunkan risiko stroke berulang." % sm["adherence"]))
    return jsonify(r)

# ---------- AI ----------
@app.get("/api/ai/coach")
@need()
def api_coach():
    pid = target_pid(); sm = summary(pid)
    return jsonify(coach(rows("select * from sessions where user_id=? and exercise!='game' order by created, id", (pid,)), sm["tpw"], sm["adherence"]))

@app.post("/api/ai/ask")
@need()
def api_ask():
    pid = target_pid(); sm = summary(pid)
    return jsonify(qa_engine.answer((request.json or {}).get("q", ""), dict(fma=sm["fma"], adh=sm["adherence"], tpw=sm["tpw"], risk=risk_for(pid))))

@app.get("/api/ai/topics")
@need()
def api_topics():
    return jsonify(qa_engine.topics())

# ---------- media foto/video ----------
@app.post("/api/media")
@need("pasien", "keluarga")
def upload():
    f = request.files.get("file")
    if not f: return jsonify(error="File kosong"), 400
    ext = (f.filename.rsplit(".", 1)[-1] if "." in f.filename else "bin").lower()
    if ext not in ("jpg", "jpeg", "png", "webp", "webm", "mp4", "mov"): return jsonify(error="Format tidak didukung"), 400
    name = uuid.uuid4().hex + "." + ext; f.save(os.path.join(UP, name))
    kind = "video" if ext in ("webm", "mp4", "mov") else "foto"
    q("insert into media(user_id,kind,filename,exercise) values(?,?,?,?)", (target_pid(), kind, name, request.form.get("exercise", "")))
    return jsonify(ok=True)

@app.get("/api/media")
@need()
def media_list():
    return jsonify(rows("select * from media where user_id=? order by created desc, id desc", (target_pid(),)))

@app.get("/media/<path:f>")
@need()
def media_file(f): return send_from_directory(UP, f)

# ---------- validasi goniometer ----------
@app.post("/api/validation")
@need("fisio", "pasien")
def add_val():
    d = request.json
    q("insert into validations(user_id,joint,camera_deg,gonio_deg) values(?,?,?,?)", (cur()["id"], d["joint"], d["camera"], d["gonio"]))
    return jsonify(ok=True)

@app.get("/api/validation")
@need("fisio", "pasien")
def get_val():
    V = rows("select * from validations order by created desc, id desc")
    err = [abs(v["camera_deg"] - v["gonio_deg"]) for v in V]; n = len(V)
    return jsonify(items=V, n=n, mae=round(sum(err) / n, 2) if n else 0,
        bias=round(sum(v["camera_deg"] - v["gonio_deg"] for v in V) / n, 2) if n else 0,
        within=round(100 * sum(e <= 3.5 for e in err) / n) if n else 0)

# ---------- fisioterapis ----------
@app.get("/api/physio/patients")
@need("fisio")
def physio_patients():
    out = []
    for p in q("select id from users where role='pasien'"):
        s, r = summary(p["id"]), risk_for(p["id"]); s.update(risk_score=r["score"], risk_level=r["level"], risk_flag=bool(r["red_flags"])); out.append(s)
    return jsonify(out)

@app.get("/api/physio/trend")
@need("fisio")
def trend():
    S = [x for x in rows("select * from sessions where exercise!='game'")]; now = datetime.utcnow(); out = []
    for i in range(3, -1, -1):
        a, b = now - timedelta(days=7 * (i + 1)), now - timedelta(days=7 * i); W = [x for x in S if a < parse(x["created"]) <= b]
        sh = [max(x["max_sh_flex"], x["max_sh_abd"]) for x in W if max(x["max_sh_flex"], x["max_sh_abd"]) > 0]; el = [x["max_elbow"] for x in W if x["max_elbow"] > 0]
        out.append({"label": "Minggu %d" % (4 - i), "shoulder": round(sum(sh) / len(sh)) if sh else 0, "elbow": round(sum(el) / len(el)) if el else 0, "sessions": len(W)})
    return jsonify(out)

@app.post("/api/physio/program")
@need("fisio")
def program():
    d = request.json; q("update users set target_per_week=? where id=?", (int(d["tpw"]), int(d["pid"]))); return jsonify(ok=True)

@app.post("/api/notes")
@need("fisio", "keluarga")
def add_note():
    q("insert into notes(user_id,author_id,text) values(?,?,?)", (target_pid() if cur()["role"] == "keluarga" else request.json["pid"], cur()["id"], request.json["text"]))
    return jsonify(ok=True)

@app.route("/api/fma", methods=["GET", "POST"])
@need()
def api_fma():
    pid = target_pid()
    if request.method == "POST":
        if cur()["role"] != "fisio": return jsonify(error="Hanya fisioterapis"), 401
        items = request.json["items"]; tot = sum(items)
        q("insert into fma(user_id,rater_id,items,total,scaled) values(?,?,?,?,?)", (pid, cur()["id"], json.dumps(items), tot, round(tot / (2 * len(items)) * 66, 1)))
        return jsonify(ok=True)
    return jsonify(rows("select * from fma where user_id=? order by created desc, id desc", (pid,)))

init_db(); seed_health()
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
