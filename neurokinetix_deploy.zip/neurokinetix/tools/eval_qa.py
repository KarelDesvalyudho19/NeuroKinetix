"""Menguji akurasi mesin QA pada kumpulan uji (pertanyaan baru). Jalankan: python tools/eval_qa.py"""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT)
from ai import qa_engine as E
from ai.stroke_risk import assess

def demo_ctx():
    prof = dict(sex="L", height=165, stroke_type="iskemik", smoking="mantan", af=1, anticoag=0, alcohol="ringan", activity="jarang", family=1, prior_events=1, med_adherence="kadang", dx_hypertension=1)
    recs = [dict(id=i, date=f"2026-0{m}-15", sbp=s, dbp=d, glucose_fasting=g, hba1c=None, ldl=l, hdl=38, tg=210, chol_total=228, weight=76, pulse=90, irregular=0)
            for i, (m, s, d, g, l) in enumerate([(7, 146, 90, 118, 132), (8, 150, 92, 126, 138), (9, 154, 96, 128, 144)])]
    return dict(risk=assess(prof, recs, 61, today=__import__("datetime").date(2026, 9, 20)), fma=47, adh=80, tpw=5)

def run(tests, ctx=None):
    rows = []
    for t in tests:
        q, x = t["q"], t["expect"]; r = E.answer(q, ctx)
        if x.startswith("@personal:"): ok = r["kind"] == "personal" and r["intent"] == x.split(":")[1]
        elif x.startswith("@"): ok = r["kind"] == x[1:]
        else: ok = r["kind"] in ("dataset", "mirip") and any(k.lower() in (r["matched"] or "").lower() for k in x.split("|"))
        hit3 = ok or (not x.startswith("@") and any(k.lower() in sg.lower() for sg in r["suggestions"] for k in x.split("|")))
        rows.append(dict(q=q, expect=x, kind=r["kind"], id=r["id"], matched=r["matched"], score=r["score"], ok=ok, hit3=hit3))
    return rows

def report(name, rows, verbose=True):
    n = len(rows); k = sum(r["ok"] for r in rows); ret = [r for r in rows if not r["expect"].startswith("@")]; oth = [r for r in rows if r["expect"].startswith("@")]
    if verbose:
        for r in rows:
            if not r["ok"]: print(f"SALAH  {r['q']!r}\n       harapan={r['expect']!r} dapat={r['kind']}:{r['matched']!r} skor={r['score']}")
    print(f"[{name}] {k}/{n} benar ({100 * k / n:.1f}%) | pencarian dataset {sum(r['ok'] for r in ret)}/{len(ret)} | keselamatan/pribadi/di luar topik {sum(r['ok'] for r in oth)}/{len(oth)} | jawaban benar muncul di jawaban atau 3 saran: {sum(r['hit3'] for r in ret)}/{len(ret)}")

if __name__ == "__main__":
    ctx = demo_ctx()
    for name, f in (("dev (dipakai menyetel)", "dataset_test.json"), ("hold-out 1 (dipakai perbaikan)", "dataset_holdout.json"), ("hold-out 2 (final)", "dataset_holdout2.json")):
        report(name, run(json.load(open(os.path.join(ROOT, "ai", f), encoding="utf-8")), ctx)); print()
