"""Membuat ai/dataset_qa.json dan ai/dataset_test.json dari ai/dataset_src.py dan ai/dataset_test_src.py.
Jalankan dari folder proyek: python tools/build_dataset.py"""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT)
from ai.dataset_src import DATA, REF
from ai.dataset_test_src import TESTS
from ai.dataset_holdout_src import HOLDOUT
from ai.dataset_holdout2_src import HOLDOUT2

def build():
    qs = [e["q"] for e in DATA]; assert len(set(qs)) == len(qs), "pertanyaan utama harus unik"
    out = [dict(id="Q%03d" % (i + 1), **e) for i, e in enumerate(DATA)]
    for e in out:
        assert e["urgensi"] in ("info", "waspada", "darurat") and len(e["v"]) == 2 and e["a"].strip()
    json.dump(dict(version=1, ref=REF, data=out), open(os.path.join(ROOT, "ai", "dataset_qa.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump([dict(q=q, expect=x) for q, x in TESTS], open(os.path.join(ROOT, "ai", "dataset_test.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump([dict(q=q, expect=x) for q, x in HOLDOUT], open(os.path.join(ROOT, "ai", "dataset_holdout.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump([dict(q=q, expect=x) for q, x in HOLDOUT2], open(os.path.join(ROOT, "ai", "dataset_holdout2.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"{len(out)} entri, {sum(1 + len(e['v']) for e in out)} bentuk pertanyaan, {len(TESTS)} uji")

if __name__ == "__main__": build()
