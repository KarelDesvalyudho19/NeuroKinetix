"""Membuat Excel dataset QA (docs/Dataset_QA_NeuroKinetix.xlsx). Jalankan: python tools/build_dataset.py && python tools/build_excel.py"""
import json, os, sys
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter as L
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); sys.path.insert(0, os.path.join(ROOT, "tools"))
import eval_qa as V

OUT = os.path.join(ROOT, "docs", "Dataset_QA_NeuroKinetix.xlsx")
F = lambda **k: Font(name="Arial", size=k.pop("size", 10), **k)
HDR_FILL, HDR_FONT = PatternFill("solid", fgColor="1F3864"), F(bold=True, color="FFFFFF")
URG = {"darurat": PatternFill("solid", fgColor="F8CBAD"), "waspada": PatternFill("solid", fgColor="FFE699"), "info": None}
thin = Side(style="thin", color="BFBFBF"); BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
WRAP = Alignment(wrap_text=True, vertical="top"); CENTER = Alignment(horizontal="center", vertical="top", wrap_text=True)
PERS = {"": "Tidak", "bp": "Tekanan darah", "glucose": "Gula darah", "lipid": "Kolesterol", "risk": "Skor risiko stroke", "progress": "Kepatuhan latihan", "fma": "Estimasi FMA-UE"}
KIND = {"dataset": "Jawaban langsung", "mirip": "Jawaban terdekat", "fallback": "Saran pertanyaan lain", "darurat": "Peringatan darurat", "krisis": "Respons krisis jiwa", "personal": "Data pribadi pasien", "smalltalk": "Sapaan", "kosong": "Kosong"}

def header(ws, row, cols, widths=None):
    for j, c in enumerate(cols, 1):
        x = ws.cell(row, j, c); x.font, x.fill, x.alignment, x.border = HDR_FONT, HDR_FILL, Alignment(horizontal="center", vertical="center", wrap_text=True), BORDER
        if widths: ws.column_dimensions[L(j)].width = widths[j - 1]
    ws.row_dimensions[row].height = 32

def body(c, align=WRAP, **k):
    c.font = F(**k); c.alignment = align; c.border = BORDER

def build():
    data = json.load(open(os.path.join(ROOT, "ai", "dataset_qa.json"), encoding="utf-8")); ref = data["ref"]; D = data["data"]; n = len(D)
    cats = list(dict.fromkeys(e["kategori"] for e in D)); wb = Workbook()

    # ---------- Panduan & Rujukan ----------
    pg = wb.active; pg.title = "Panduan & Rujukan"
    pg.column_dimensions["A"].width = 34; pg.column_dimensions["B"].width = 110
    pg["A1"] = "Dataset Tanya-Jawab AI Coach NeuroKinetix"; pg["A1"].font = F(bold=True, size=14, color="1F3864")
    pg["A2"] = "Markerless 3D Biomechanical Pose Estimation for Gamified Post-Stroke Motor Rehabilitation"; pg["A2"].font = F(italic=True, color="595959")
    info = [("Tujuan", "Kumpulan pertanyaan yang dapat diajukan pasien/keluarga kepada AI Coach tentang stroke dan kesehatan terkait, beserta jawaban edukasi yang sudah disusun. Dipakai langsung oleh aplikasi (ai/dataset_qa.json)."),
            ("Cara kerja mesin", "Pertanyaan pengguna dicocokkan ke Pertanyaan Utama dan 2 Variasi tiap entri memakai TF-IDF (unigram+bigram) dan kemiripan n-gram karakter, tanpa LLM. Jawaban hanya berasal dari teks di sheet 'Dataset QA'. Urutan: deteksi krisis jiwa, deteksi gejala darurat, pertanyaan tentang data pribadi, pencarian dataset, saran pertanyaan."),
            ("Kolom Dataset QA", "ID unik; Kategori; Pertanyaan Utama; Variasi 1 dan 2 (gaya bahasa pasien); Jawaban; Urgensi (info/waspada/darurat); Perlu Konsultasi Dokter; Personalisasi (data pasien yang ditambahkan di akhir jawaban); Jumlah Kata (rumus); Rujukan (rumus pencarian ke tabel di bawah)."),
            ("Urgensi", "info = informasi umum. waspada = perlu perhatian atau konsultasi dokter. darurat = jawaban diawali tanda peringatan dan menyuruh segera ke IGD/112."),
            ("Personalisasi", "Entri bertanda personalisasi menambahkan baris 'Data Anda: ...' dari data pasien yang tersimpan (tekanan darah, gula darah, kolesterol, skor risiko, kepatuhan, FMA) bila datanya ada."),
            ("Prinsip keselamatan", "Tanpa dosis atau nama obat spesifik untuk dikonsumsi; selalu mengarahkan keputusan terapi ke dokter; gejala darurat mengarah ke 112/IGD; kalimat krisis jiwa dijawab dengan dukungan dan arahan mencari bantuan; tidak memberi diagnosis."),
            ("BATASAN PENTING", "1) Jawaban adalah edukasi umum yang ditulis tim dan BELUM ditinjau dokter/fisioterapis; wajib ditinjau sebelum dipakai klinis. 2) Rujukan di bawah hanya nama pedoman umum, bukan kutipan; tim harus membuka sumber asli dan mencantumkan edisi/tahun. 3) Pencocokan bersifat leksikal sehingga paraphrase yang jauh dari kosakata dataset bisa gagal (lihat sheet Uji Akurasi). 4) Nilai ambang (mis. target tekanan darah, LDL, HbA1c) mengikuti pedoman umum dan dapat berbeda untuk tiap pasien."),
            ("Cara menambah entri", "Edit ai/dataset_src.py (satu panggilan A(...) per entri: pertanyaan, 2 variasi, jawaban, urgensi, perlu dokter, personalisasi), lalu jalankan: python tools/build_dataset.py, python tools/eval_qa.py, python tools/build_excel.py. Cara terbaik menaikkan akurasi: tambahkan variasi dari pertanyaan nyata pengguna.")]
    for i, (a, b) in enumerate(info, 4):
        pg.cell(i, 1, a).font = F(bold=True); pg.cell(i, 2, b).font = F(); pg.cell(i, 1).alignment = pg.cell(i, 2).alignment = WRAP
    r0 = 4 + len(info) + 2; pg.cell(r0 - 1, 1, "Tabel rujukan umum per kategori (verifikasi edisi/tahun sebelum dikutip)").font = F(bold=True, color="1F3864")
    header(pg, r0, ["Kategori", "Rujukan umum (nama pedoman)"])
    for i, c in enumerate(cats, r0 + 1):
        body(pg.cell(i, 1, c)); body(pg.cell(i, 2, ref[c]))
    REF_RNG_A, REF_RNG_B = f"'Panduan & Rujukan'!$A${r0 + 1}:$A${r0 + len(cats)}", f"'Panduan & Rujukan'!$B${r0 + 1}:$B${r0 + len(cats)}"

    # ---------- Dataset QA ----------
    ws = wb.create_sheet("Dataset QA", 0)
    cols = ["ID", "Kategori", "Pertanyaan Utama", "Variasi 1", "Variasi 2", "Jawaban", "Urgensi", "Perlu Konsultasi Dokter", "Personalisasi Data Pasien", "Jumlah Kata Jawaban", "Rujukan Umum"]
    header(ws, 1, cols, [8, 24, 42, 36, 36, 90, 11, 14, 18, 12, 40])
    for i, e in enumerate(D, 2):
        vals = [e["id"], e["kategori"], e["q"], e["v"][0], e["v"][1], e["a"], e["urgensi"], "Ya" if e["dokter"] else "Tidak", PERS[e["pers"]]]
        for j, v in enumerate(vals, 1): body(ws.cell(i, j, v), CENTER if j in (1, 7, 8) else WRAP)
        body(ws.cell(i, 10, f'=LEN(F{i})-LEN(SUBSTITUTE(F{i}," ",""))+1'), CENTER); ws.cell(i, 10).number_format = "0"
        body(ws.cell(i, 11, f"=INDEX({REF_RNG_B},MATCH(B{i},{REF_RNG_A},0))"))
        if URG[e["urgensi"]]: ws.cell(i, 7).fill = URG[e["urgensi"]]
    ws.freeze_panes = "D2"; ws.auto_filter.ref = f"A1:{L(len(cols))}{n + 1}"
    last = n + 1

    # ---------- Variasi Pertanyaan ----------
    wv = wb.create_sheet("Variasi Pertanyaan", 1); header(wv, 1, ["ID", "Jenis", "Teks Pertanyaan", "Kategori"], [8, 16, 80, 28]); r = 2
    for e in D:
        for jenis, t in (("Utama", e["q"]), ("Variasi 1", e["v"][0]), ("Variasi 2", e["v"][1])):
            body(wv.cell(r, 1, e["id"]), CENTER); body(wv.cell(r, 2, jenis), CENTER); body(wv.cell(r, 3, t))
            body(wv.cell(r, 4, f"=INDEX('Dataset QA'!$B$2:$B${last},MATCH(A{r},'Dataset QA'!$A$2:$A${last},0))")); r += 1
    wv.freeze_panes = "A2"; wv.auto_filter.ref = f"A1:D{r - 1}"; vlast = r - 1

    # ---------- Ringkasan ----------
    sm = wb.create_sheet("Ringkasan", 2); sm["A1"] = "Ringkasan dataset (semua angka dihitung dengan rumus dari sheet Dataset QA)"; sm["A1"].font = F(bold=True, size=12, color="1F3864")
    header(sm, 3, ["Kategori", "Jumlah Pertanyaan", "Bentuk Pertanyaan (utama + variasi)", "Urgensi Darurat", "Urgensi Waspada", "Urgensi Info", "Perlu Konsultasi Dokter", "Rata-rata Kata Jawaban"], [32, 14, 20, 12, 12, 12, 16, 16])
    rng = lambda c: f"'Dataset QA'!${c}$2:${c}${last}"
    for i, c in enumerate(cats, 4):
        body(sm.cell(i, 1, c))
        for j, f in enumerate([f"=COUNTIF({rng('B')},A{i})", f"=COUNTIF('Variasi Pertanyaan'!$D$2:$D${vlast},A{i})", f'=COUNTIFS({rng("B")},A{i},{rng("G")},"darurat")', f'=COUNTIFS({rng("B")},A{i},{rng("G")},"waspada")',
                               f'=COUNTIFS({rng("B")},A{i},{rng("G")},"info")', f'=COUNTIFS({rng("B")},A{i},{rng("H")},"Ya")', f"=AVERAGEIF({rng('B')},A{i},{rng('J')})"], 2):
            body(sm.cell(i, j, f), CENTER); sm.cell(i, j).number_format = "0.0" if j == 8 else "0"
    t = 4 + len(cats); body(sm.cell(t, 1, "TOTAL"), bold=True)
    for j in range(2, 8): body(sm.cell(t, j, f"=SUM({L(j)}4:{L(j)}{t - 1})"), CENTER, bold=True); sm.cell(t, j).number_format = "0"
    body(sm.cell(t, 8, f"=AVERAGE({rng('J')})"), CENTER, bold=True); sm.cell(t, 8).number_format = "0.0"
    sm.cell(t + 2, 1, "Pemeriksaan: total pertanyaan = jumlah baris Dataset QA?").font = F(); sm.cell(t + 2, 2, f'=IF(B{t}=COUNTA({rng("A")}),"OK","TIDAK SESUAI")').font = F(bold=True)
    sm.cell(t + 3, 1, "Entri dengan personalisasi data pasien").font = F(); sm.cell(t + 3, 2, f'=COUNTIF({rng("I")},"<>Tidak")').font = F(bold=True)

    # ---------- Uji Akurasi ----------
    ctx = V.demo_ctx(); sets = [("Dev (dipakai menyetel mesin)", "dataset_test.json"), ("Hold-out 1 (dipakai perbaikan)", "dataset_holdout.json"), ("Hold-out 2 (final)", "dataset_holdout2.json")]
    wu = wb.create_sheet("Uji Akurasi", 3); wu["A1"] = "Uji akurasi mesin pada pertanyaan BARU (tidak ada di dataset)"; wu["A1"].font = F(bold=True, size=12, color="1F3864")
    wu["A2"] = ("Dev dipakai menyetel mesin, jadi angkanya terlalu optimis. Hold-out 1 dipakai untuk perbaikan kedua. Hold-out 2 ditulis setelah penyetelan, tetapi setelah dievaluasi juga dipakai untuk memperbaiki deteksi krisis jiwa dan pengetatan koreksi kata, "
                "sehingga bukan uji murni. Angka yang paling realistis untuk pertanyaan baru adalah Hold-out 2 (sekitar 3 dari 4 dijawab tepat; sisanya biasanya masih muncul sebagai salah satu dari 3 saran pertanyaan). Kolom Benar dihitung skrip (logika pencocokan teks), bukan rumus.")
    wu["A2"].font = F(italic=True, color="595959"); wu["A2"].alignment = WRAP; wu.merge_cells("A2:H2"); wu.row_dimensions[2].height = 62
    header(wu, 4, ["Set Uji", "Jumlah Uji", "Benar", "Akurasi", "Uji Pencarian Dataset", "Pencarian Benar", "Akurasi Pencarian", "Jawaban benar di jawaban atau 3 saran"], [34, 12, 10, 10, 18, 16, 16, 22])
    hdr_row = 4 + len(sets) + 3; header(wu, hdr_row, ["Set Uji", "Pertanyaan Uji", "Harapan", "Hasil Sistem", "Pertanyaan Dataset Terpilih", "Skor", "Benar?", "Jawaban benar di 3 saran?"], [34, 52, 40, 24, 56, 10, 12, 22])
    r = hdr_row + 1; first = r
    for name, f in sets:
        for x in V.run(json.load(open(os.path.join(ROOT, "ai", f), encoding="utf-8")), ctx):
            for j, v in enumerate([name, x["q"], x["expect"], KIND[x["kind"]], x["matched"] or "–", x["score"], "Ya" if x["ok"] else "Tidak", "Ya" if x["hit3"] else "Tidak"], 1):
                body(wu.cell(r, j, v), CENTER if j in (6, 7, 8) else WRAP)
            wu.cell(r, 6).number_format = "0.00"; wu.cell(r, 7).fill = PatternFill("solid", fgColor="C6E0B4" if x["ok"] else "F8CBAD"); r += 1
    ul = r - 1; A, B, Cc, Dd, Hh = [f"$%s${first}:$%s${ul}" % (c, c) for c in "ABCDH"]; G_ = f"$G${first}:$G${ul}"
    for i, (name, f) in enumerate(sets, 5):
        body(wu.cell(i, 1, name))
        body(wu.cell(i, 2, f'=COUNTIF({A},A{i})'), CENTER); body(wu.cell(i, 3, f'=COUNTIFS({A},A{i},{G_},"Ya")'), CENTER)
        body(wu.cell(i, 4, f"=IF(B{i}=0,0,C{i}/B{i})"), CENTER); wu.cell(i, 4).number_format = "0.0%"
        body(wu.cell(i, 5, f'=COUNTIFS({A},A{i},{Cc},"<>@*")'), CENTER); body(wu.cell(i, 6, f'=COUNTIFS({A},A{i},{Cc},"<>@*",{G_},"Ya")'), CENTER)
        body(wu.cell(i, 7, f"=IF(E{i}=0,0,F{i}/E{i})"), CENTER); wu.cell(i, 7).number_format = "0.0%"
        body(wu.cell(i, 8, f'=COUNTIFS({A},A{i},{Cc},"<>@*",{Hh},"Ya")/IF(E{i}=0,1,E{i})'), CENTER); wu.cell(i, 8).number_format = "0.0%"
    wu.cell(4 + len(sets) + 1, 1, "Harapan berawalan @ = uji perilaku (darurat, krisis, di luar topik, sapaan, data pribadi), bukan pencarian dataset.").font = F(italic=True, color="595959")
    wu.freeze_panes = f"A{hdr_row + 1}"; wu.auto_filter.ref = f"A{hdr_row}:H{ul}"
    for w in wb.worksheets: w.sheet_view.zoomScale = 90
    wb.save(OUT); print("tersimpan:", OUT)

if __name__ == "__main__": build()
